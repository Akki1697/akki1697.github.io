


<!DOCTYPE html>
<html lang="en" class="">
  <head prefix="og: http://ogp.me/ns# fb: http://ogp.me/ns/fb# object: http://ogp.me/ns/object# article: http://ogp.me/ns/article# profile: http://ogp.me/ns/profile#">
    <meta charset='utf-8'>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Language" content="en">
    
    
    <title>coolwanglu/vim.js · GitHub</title>
    <link rel="search" type="application/opensearchdescription+xml" href="/opensearch.xml" title="GitHub">
    <link rel="fluid-icon" href="https://github.com/fluidicon.png" title="GitHub">
    <link rel="apple-touch-icon" sizes="57x57" href="/apple-touch-icon-114.png">
    <link rel="apple-touch-icon" sizes="114x114" href="/apple-touch-icon-114.png">
    <link rel="apple-touch-icon" sizes="72x72" href="/apple-touch-icon-144.png">
    <link rel="apple-touch-icon" sizes="144x144" href="/apple-touch-icon-144.png">
    <meta property="fb:app_id" content="1401488693436528">

      <meta content="@github" name="twitter:site" /><meta content="summary" name="twitter:card" /><meta content="coolwanglu/vim.js" name="twitter:title" /><meta content="JavaScript port of Vim. Contribute to vim.js development by creating an account on GitHub." name="twitter:description" /><meta content="https://avatars1.githubusercontent.com/u/734614?v=3&amp;s=400" name="twitter:image:src" />
      <meta content="GitHub" property="og:site_name" /><meta content="object" property="og:type" /><meta content="https://avatars1.githubusercontent.com/u/734614?v=3&amp;s=400" property="og:image" /><meta content="coolwanglu/vim.js" property="og:title" /><meta content="https://github.com/coolwanglu/vim.js" property="og:url" /><meta content="JavaScript port of Vim. Contribute to vim.js development by creating an account on GitHub." property="og:description" />
      <meta name="browser-stats-url" content="https://api.github.com/_private/browser/stats">
    <meta name="browser-errors-url" content="https://api.github.com/_private/browser/errors">
    <link rel="assets" href="https://assets-cdn.github.com/">
    
    <meta name="pjax-timeout" content="1000">
    

    <meta name="msapplication-TileImage" content="/windows-tile.png">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="selected-link" value="repo_source" data-pjax-transient>
      <meta name="google-analytics" content="UA-3769691-2">

    <meta content="collector.githubapp.com" name="octolytics-host" /><meta content="collector-cdn.github.com" name="octolytics-script-host" /><meta content="github" name="octolytics-app-id" /><meta content="783D1521:06C2:142162F:5571AB3D" name="octolytics-dimension-request_id" />
    
    <meta content="Rails, view, files#disambiguate" name="analytics-event" />
    <meta class="js-ga-set" name="dimension1" content="Logged Out">
    <meta class="js-ga-set" name="dimension2" content="Header v3">
    <meta name="is-dotcom" content="true">
      <meta name="hostname" content="github.com">
    <meta name="user-login" content="">

    
    <link rel="icon" type="image/x-icon" href="https://assets-cdn.github.com/favicon.ico">


    <meta content="authenticity_token" name="csrf-param" />
<meta content="X8U0G+z+voVfblpIwXELvvaBtbyAkCb8VRdj2Pr0jmMwRhs7b2IkmGVktdXjh4dBULrcrYP0dUH2VA5ZNNAd6Q==" name="csrf-token" />

    <link crossorigin="anonymous" href="https://assets-cdn.github.com/assets/github/index-6967b378b26829cc5a2ea2ad4209ff0af50f2a65057962219dc9dcf8942683f0.css" media="all" rel="stylesheet" />
    <link crossorigin="anonymous" href="https://assets-cdn.github.com/assets/github2/index-73bfe123ff406f4bf8959a28667410beaac1485e71c92d4725a3d7afc45fc4c5.css" media="all" rel="stylesheet" />
    
    


    <meta http-equiv="x-pjax-version" content="b2ca4753a2f40f3bd3d3d6fd0fe8b32e">

      
  <meta name="description" content="JavaScript port of Vim. Contribute to vim.js development by creating an account on GitHub.">
  <meta name="go-import" content="github.com/coolwanglu/vim.js git https://github.com/coolwanglu/vim.js.git">

  <meta content="734614" name="octolytics-dimension-user_id" /><meta content="coolwanglu" name="octolytics-dimension-user_login" /><meta content="14816993" name="octolytics-dimension-repository_id" /><meta content="coolwanglu/vim.js" name="octolytics-dimension-repository_nwo" /><meta content="true" name="octolytics-dimension-repository_public" /><meta content="false" name="octolytics-dimension-repository_is_fork" /><meta content="14816993" name="octolytics-dimension-repository_network_root_id" /><meta content="coolwanglu/vim.js" name="octolytics-dimension-repository_network_root_nwo" />
  <link href="https://github.com/coolwanglu/vim.js/commits/master.atom" rel="alternate" title="Recent Commits to vim.js:master" type="application/atom+xml">

  </head>


  <body class="logged_out  env-production  vis-public">
    <a href="#start-of-content" tabindex="1" class="accessibility-aid js-skip-to-content">Skip to content</a>
    <div class="wrapper">
      
      
      


        
        <div class="header header-logged-out" role="banner">
  <div class="container clearfix">

    <a class="header-logo-wordmark" href="https://github.com/" data-ga-click="(Logged out) Header, go to homepage, icon:logo-wordmark">
      <span class="mega-octicon octicon-logo-github"></span>
    </a>

    <div class="header-actions" role="navigation">
        <a class="btn btn-primary" href="/join" data-ga-click="(Logged out) Header, clicked Sign up, text:sign-up">Sign up</a>
      <a class="btn" href="/login?return_to=%2Fcoolwanglu%2Fvim.js" data-ga-click="(Logged out) Header, clicked Sign in, text:sign-in">Sign in</a>
    </div>

    <div class="site-search repo-scope js-site-search" role="search">
      <form accept-charset="UTF-8" action="/coolwanglu/vim.js/search" class="js-site-search-form" data-global-search-url="/search" data-repo-search-url="/coolwanglu/vim.js/search" method="get"><div style="margin:0;padding:0;display:inline"><input name="utf8" type="hidden" value="&#x2713;" /></div>
  <label class="js-chromeless-input-container form-control">
    <div class="scope-badge">This repository</div>
    <input type="text"
      class="js-site-search-focus js-site-search-field is-clearable chromeless-input"
      data-hotkey="s"
      name="q"
      placeholder="Search"
      data-global-scope-placeholder="Search GitHub"
      data-repo-scope-placeholder="Search"
      tabindex="1"
      autocapitalize="off">
  </label>
</form>
    </div>

      <ul class="header-nav left" role="navigation">
          <li class="header-nav-item">
            <a class="header-nav-link" href="/explore" data-ga-click="(Logged out) Header, go to explore, text:explore">Explore</a>
          </li>
          <li class="header-nav-item">
            <a class="header-nav-link" href="/features" data-ga-click="(Logged out) Header, go to features, text:features">Features</a>
          </li>
          <li class="header-nav-item">
            <a class="header-nav-link" href="https://enterprise.github.com/" data-ga-click="(Logged out) Header, go to enterprise, text:enterprise">Enterprise</a>
          </li>
          <li class="header-nav-item">
            <a class="header-nav-link" href="/blog" data-ga-click="(Logged out) Header, go to blog, text:blog">Blog</a>
          </li>
      </ul>

  </div>
</div>



      <div id="start-of-content" class="accessibility-aid"></div>
          <div class="site" itemscope itemtype="http://schema.org/WebPage">
    <div id="js-flash-container">
      
    </div>
    <div class="pagehead repohead instapaper_ignore readability-menu">
      <div class="container">

        
<ul class="pagehead-actions">

  <li>
      <a href="/login?return_to=%2Fcoolwanglu%2Fvim.js"
    class="btn btn-sm btn-with-count tooltipped tooltipped-n"
    aria-label="You must be signed in to watch a repository" rel="nofollow">
    <span class="octicon octicon-eye"></span>
    Watch
  </a>
  <a class="social-count" href="/coolwanglu/vim.js/watchers">
    146
  </a>

  </li>

  <li>
      <a href="/login?return_to=%2Fcoolwanglu%2Fvim.js"
    class="btn btn-sm btn-with-count tooltipped tooltipped-n"
    aria-label="You must be signed in to star a repository" rel="nofollow">
    <span class="octicon octicon-star"></span>
    Star
  </a>

    <a class="social-count js-social-count" href="/coolwanglu/vim.js/stargazers">
      3,355
    </a>

  </li>

    <li>
      <a href="/login?return_to=%2Fcoolwanglu%2Fvim.js"
        class="btn btn-sm btn-with-count tooltipped tooltipped-n"
        aria-label="You must be signed in to fork a repository" rel="nofollow">
        <span class="octicon octicon-repo-forked"></span>
        Fork
      </a>
      <a href="/coolwanglu/vim.js/network" class="social-count">
        195
      </a>
    </li>
</ul>

        <h1 itemscope itemtype="http://data-vocabulary.org/Breadcrumb" class="entry-title public">
          <span class="mega-octicon octicon-repo"></span>
          <span class="author"><a href="/coolwanglu" class="url fn" itemprop="url" rel="author"><span itemprop="title">coolwanglu</span></a></span><!--
       --><span class="path-divider">/</span><!--
       --><strong><a href="/coolwanglu/vim.js" data-pjax="#js-repo-pjax-container">vim.js</a></strong>

          <span class="page-context-loader">
            <img alt="" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </span>

        </h1>
      </div><!-- /.container -->
    </div><!-- /.repohead -->

    <div class="container">
      <div class="repository-with-sidebar repo-container new-discussion-timeline with-full-navigation ">
        <div class="repository-sidebar clearfix">
            
<nav class="sunken-menu repo-nav js-repo-nav js-sidenav-container-pjax js-octicon-loaders"
     role="navigation"
     data-pjax="#js-repo-pjax-container"
     data-issue-count-url="/coolwanglu/vim.js/issues/counts">
  <ul class="sunken-menu-group">
    <li class="tooltipped tooltipped-w" aria-label="Code">
      <a href="/coolwanglu/vim.js" aria-label="Code" class="selected js-selected-navigation-item sunken-menu-item" data-hotkey="g c" data-selected-links="repo_source repo_downloads repo_commits repo_releases repo_tags repo_branches /coolwanglu/vim.js">
        <span class="octicon octicon-code"></span> <span class="full-word">Code</span>
        <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>    </li>

      <li class="tooltipped tooltipped-w" aria-label="Issues">
        <a href="/coolwanglu/vim.js/issues" aria-label="Issues" class="js-selected-navigation-item sunken-menu-item" data-hotkey="g i" data-selected-links="repo_issues repo_labels repo_milestones /coolwanglu/vim.js/issues">
          <span class="octicon octicon-issue-opened"></span> <span class="full-word">Issues</span>
          <span class="js-issue-replace-counter"></span>
          <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>      </li>

    <li class="tooltipped tooltipped-w" aria-label="Pull requests">
      <a href="/coolwanglu/vim.js/pulls" aria-label="Pull requests" class="js-selected-navigation-item sunken-menu-item" data-hotkey="g p" data-selected-links="repo_pulls /coolwanglu/vim.js/pulls">
          <span class="octicon octicon-git-pull-request"></span> <span class="full-word">Pull requests</span>
          <span class="js-pull-replace-counter"></span>
          <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>    </li>

      <li class="tooltipped tooltipped-w" aria-label="Wiki">
        <a href="/coolwanglu/vim.js/wiki" aria-label="Wiki" class="js-selected-navigation-item sunken-menu-item" data-hotkey="g w" data-selected-links="repo_wiki /coolwanglu/vim.js/wiki">
          <span class="octicon octicon-book"></span> <span class="full-word">Wiki</span>
          <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>      </li>
  </ul>
  <div class="sunken-menu-separator"></div>
  <ul class="sunken-menu-group">

    <li class="tooltipped tooltipped-w" aria-label="Pulse">
      <a href="/coolwanglu/vim.js/pulse" aria-label="Pulse" class="js-selected-navigation-item sunken-menu-item" data-selected-links="pulse /coolwanglu/vim.js/pulse">
        <span class="octicon octicon-pulse"></span> <span class="full-word">Pulse</span>
        <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>    </li>

    <li class="tooltipped tooltipped-w" aria-label="Graphs">
      <a href="/coolwanglu/vim.js/graphs" aria-label="Graphs" class="js-selected-navigation-item sunken-menu-item" data-selected-links="repo_graphs repo_contributors /coolwanglu/vim.js/graphs">
        <span class="octicon octicon-graph"></span> <span class="full-word">Graphs</span>
        <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>    </li>
  </ul>


</nav>

              <div class="only-with-full-nav">
                  
<div class="js-clone-url clone-url open"
  data-protocol-type="http">
  <h3><span class="text-emphasized">HTTPS</span> clone URL</h3>
  <div class="input-group js-zeroclipboard-container">
    <input type="text" class="input-mini input-monospace js-url-field js-zeroclipboard-target"
           value="https://github.com/coolwanglu/vim.js.git" readonly="readonly">
    <span class="input-group-button">
      <button aria-label="Copy to clipboard" class="js-zeroclipboard btn btn-sm zeroclipboard-button tooltipped tooltipped-s" data-copied-hint="Copied!" type="button"><span class="octicon octicon-clippy"></span></button>
    </span>
  </div>
</div>

  
<div class="js-clone-url clone-url "
  data-protocol-type="subversion">
  <h3><span class="text-emphasized">Subversion</span> checkout URL</h3>
  <div class="input-group js-zeroclipboard-container">
    <input type="text" class="input-mini input-monospace js-url-field js-zeroclipboard-target"
           value="https://github.com/coolwanglu/vim.js" readonly="readonly">
    <span class="input-group-button">
      <button aria-label="Copy to clipboard" class="js-zeroclipboard btn btn-sm zeroclipboard-button tooltipped tooltipped-s" data-copied-hint="Copied!" type="button"><span class="octicon octicon-clippy"></span></button>
    </span>
  </div>
</div>



<div class="clone-options">You can clone with
  <form accept-charset="UTF-8" action="/users/set_protocol?protocol_selector=http&amp;protocol_type=clone" class="inline-form js-clone-selector-form " data-remote="true" method="post"><div style="margin:0;padding:0;display:inline"><input name="utf8" type="hidden" value="&#x2713;" /><input name="authenticity_token" type="hidden" value="jgBsdUM5JhUQvRtM+mJM+JsZ3xHT37mgcl9+EpkCGEM0Km0cKldPYVehuPhQGVR/b9fuhxM7HchHZDz2nSbaVg==" /></div><button class="btn-link js-clone-selector" data-protocol="http" type="submit">HTTPS</button></form> or <form accept-charset="UTF-8" action="/users/set_protocol?protocol_selector=subversion&amp;protocol_type=clone" class="inline-form js-clone-selector-form " data-remote="true" method="post"><div style="margin:0;padding:0;display:inline"><input name="utf8" type="hidden" value="&#x2713;" /><input name="authenticity_token" type="hidden" value="r33MvrhAgbFuRWW8EZ1L5ufI/Yqbn5j5Wz0evSwconvOMlmS10IBSxy4EXMrYfy5I24cclCQKs8MWIy/o4tqXQ==" /></div><button class="btn-link js-clone-selector" data-protocol="subversion" type="submit">Subversion</button></form>.
  <a href="https://help.github.com/articles/which-remote-url-should-i-use" class="help tooltipped tooltipped-n" aria-label="Get help on which URL is right for you.">
    <span class="octicon octicon-question"></span>
  </a>
</div>




                <a href="/coolwanglu/vim.js/archive/master.zip"
                   class="btn btn-sm sidebar-button"
                   aria-label="Download the contents of coolwanglu/vim.js as a zip file"
                   title="Download the contents of coolwanglu/vim.js as a zip file"
                   rel="nofollow">
                  <span class="octicon octicon-cloud-download"></span>
                  Download ZIP
                </a>
              </div>
        </div><!-- /.repository-sidebar -->

        <div id="js-repo-pjax-container" class="repository-content context-loader-container" data-pjax-container>

          
<span id="js-show-full-navigation"></span>

<div class="repository-meta js-details-container ">
    <div class="repository-description">
      JavaScript port of Vim
    </div>

    <div class="repository-website">
      <p><a href="http://coolwanglu.github.io/vim.js/emterpreter/vim.html" rel="nofollow">http://coolwanglu.github.io/vim.js/emterpreter/vim.html</a></p>
    </div>


</div>

<div class="overall-summary overall-summary-bottomless">

  <div class="stats-switcher-viewport js-stats-switcher-viewport">
    <div class="stats-switcher-wrapper">
    <ul class="numbers-summary">
      <li class="commits">
        <a data-pjax href="/coolwanglu/vim.js/commits/master">
            <span class="octicon octicon-history"></span>
            <span class="num text-emphasized">
              219
            </span>
            commits
        </a>
      </li>
      <li>
        <a data-pjax href="/coolwanglu/vim.js/branches">
          <span class="octicon octicon-git-branch"></span>
          <span class="num text-emphasized">
            8
          </span>
          branches
        </a>
      </li>

      <li>
        <a data-pjax href="/coolwanglu/vim.js/releases">
          <span class="octicon octicon-tag"></span>
          <span class="num text-emphasized">
            1
          </span>
          release
        </a>
      </li>

      <li>
        
  <a href="/coolwanglu/vim.js/graphs/contributors">
    <span class="octicon octicon-organization"></span>
    <span class="num text-emphasized">
      2
    </span>
    contributors
  </a>
      </li>
    </ul>

      <div class="repository-lang-stats">
        <ol class="repository-lang-stats-numbers">
          <li>
              <a href="/coolwanglu/vim.js/search?l=c">
                <span class="color-block language-color" style="background-color:#555555;"></span>
                <span class="lang">C</span>
                <span class="percent">51.7%</span>
              </a>
          </li>
          <li>
              <a href="/coolwanglu/vim.js/search?l=vim">
                <span class="color-block language-color" style="background-color:#199f4b;"></span>
                <span class="lang">VimL</span>
                <span class="percent">43.3%</span>
              </a>
          </li>
          <li>
              <a href="/coolwanglu/vim.js/search?l=makefile">
                <span class="color-block language-color" style="background-color:#427819;"></span>
                <span class="lang">Makefile</span>
                <span class="percent">1.7%</span>
              </a>
          </li>
          <li>
              <a href="/coolwanglu/vim.js/search?l=prolog">
                <span class="color-block language-color" style="background-color:#74283c;"></span>
                <span class="lang">Prolog</span>
                <span class="percent">0.7%</span>
              </a>
          </li>
          <li>
              <a href="/coolwanglu/vim.js/search?l=cpp">
                <span class="color-block language-color" style="background-color:#f34b7d;"></span>
                <span class="lang">C++</span>
                <span class="percent">0.6%</span>
              </a>
          </li>
          <li>
              <a href="/coolwanglu/vim.js/search?l=postscript">
                <span class="color-block language-color" style="background-color:#ccc;"></span>
                <span class="lang">PostScript</span>
                <span class="percent">0.3%</span>
              </a>
          </li>
          <li>
              <span class="other">
                <span class="color-block language-color" style="background-color:#ededed;"></span>
                <span class="lang">Other</span>
                <span class="percent">1.7%</span>
              </span>
          </li>
        </ol>
      </div>
    </div>
  </div>

</div>

  <div class="repository-lang-stats-graph js-toggle-lang-stats" title="Click for language details">
    <span class="language-color" aria-label="C 51.7%" style="width:51.7%; background-color:#555555;" itemprop="keywords">C</span>
    <span class="language-color" aria-label="VimL 43.3%" style="width:43.3%; background-color:#199f4b;" itemprop="keywords">VimL</span>
    <span class="language-color" aria-label="Makefile 1.7%" style="width:1.7%; background-color:#427819;" itemprop="keywords">Makefile</span>
    <span class="language-color" aria-label="Prolog 0.7%" style="width:0.7%; background-color:#74283c;" itemprop="keywords">Prolog</span>
    <span class="language-color" aria-label="C++ 0.6%" style="width:0.6%; background-color:#f34b7d;" itemprop="keywords">C++</span>
    <span class="language-color" aria-label="PostScript 0.3%" style="width:0.3%; background-color:#ccc;" itemprop="keywords">PostScript</span>
    <span class="language-color" aria-label="Other 1.7%" style="width:1.7%; background-color:#ededed;" itemprop="keywords">Other</span>
  </div>

<include-fragment src="/coolwanglu/vim.js/show_partial?partial=tree%2Frecently_touched_branches_list"></include-fragment>

<div class="file-navigation in-mid-page">
  <a href="/coolwanglu/vim.js/find/master"
        class="js-show-file-finder btn btn-sm empty-icon tooltipped tooltipped-s right"
        data-pjax
        data-hotkey="t"
        aria-label="Quickly jump between files">
    <span class="octicon octicon-list-unordered"></span>
  </a>
    <a href="/coolwanglu/vim.js/compare" aria-label="Compare, review, create a pull request" class="btn btn-sm btn-primary tooltipped tooltipped-se left compare-button" aria-label="Compare &amp; review" data-pjax data-ga-click="Repository, go to compare view, location:repo overview; icon:git-compare">
      <span class="octicon octicon-git-compare"></span>
    </a>

  
<div class="select-menu js-menu-container js-select-menu left">
  <span class="btn btn-sm select-menu-button js-menu-target css-truncate" data-hotkey="w"
    data-ref="master"
    title="master"
    role="button" aria-label="Switch branches or tags" tabindex="0" aria-haspopup="true">
    <span class="octicon octicon-git-branch"></span>
    <i>branch:</i>
    <span class="js-select-button css-truncate-target">master</span>
  </span>

  <div class="select-menu-modal-holder js-menu-content js-navigation-container" data-pjax aria-hidden="true">

    <div class="select-menu-modal">
      <div class="select-menu-header">
        <span class="select-menu-title">Switch branches/tags</span>
        <span class="octicon octicon-x js-menu-close" role="button" aria-label="Close"></span>
      </div>

      <div class="select-menu-filters">
        <div class="select-menu-text-filter">
          <input type="text" aria-label="Filter branches/tags" id="context-commitish-filter-field" class="js-filterable-field js-navigation-enable" placeholder="Filter branches/tags">
        </div>
        <div class="select-menu-tabs">
          <ul>
            <li class="select-menu-tab">
              <a href="#" data-tab-filter="branches" data-filter-placeholder="Filter branches/tags" class="js-select-menu-tab">Branches</a>
            </li>
            <li class="select-menu-tab">
              <a href="#" data-tab-filter="tags" data-filter-placeholder="Find a tag…" class="js-select-menu-tab">Tags</a>
            </li>
          </ul>
        </div>
      </div>

      <div class="select-menu-list select-menu-tab-bucket js-select-menu-tab-bucket" data-tab-filter="branches">

        <div data-filterable-for="context-commitish-filter-field" data-filterable-type="substring">


            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/coolwanglu/vim.js/tree/gh-pages"
               data-name="gh-pages"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="gh-pages">
                gh-pages
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open selected"
               href="/coolwanglu/vim.js/tree/master"
               data-name="master"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="master">
                master
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/coolwanglu/vim.js/tree/old_auto_transform"
               data-name="old_auto_transform"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="old_auto_transform">
                old_auto_transform
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/coolwanglu/vim.js/tree/old_early_attempt"
               data-name="old_early_attempt"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="old_early_attempt">
                old_early_attempt
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/coolwanglu/vim.js/tree/old_interpret"
               data-name="old_interpret"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="old_interpret">
                old_interpret
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/coolwanglu/vim.js/tree/old_streamline1"
               data-name="old_streamline1"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="old_streamline1">
                old_streamline1
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/coolwanglu/vim.js/tree/old_streamline2"
               data-name="old_streamline2"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="old_streamline2">
                old_streamline2
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/coolwanglu/vim.js/tree/streamlinejs"
               data-name="streamlinejs"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="streamlinejs">
                streamlinejs
              </span>
            </a>
        </div>

          <div class="select-menu-no-results">Nothing to show</div>
      </div>

      <div class="select-menu-list select-menu-tab-bucket js-select-menu-tab-bucket" data-tab-filter="tags">
        <div data-filterable-for="context-commitish-filter-field" data-filterable-type="substring">


            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/coolwanglu/vim.js/tree/initial"
                 data-name="initial"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="initial">initial</a>
            </div>
        </div>

        <div class="select-menu-no-results">Nothing to show</div>
      </div>

    </div>
  </div>
</div>



  <div class="breadcrumb"><span class="repo-root js-repo-root"><span itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb"><a href="/coolwanglu/vim.js" class="" data-branch="master" data-pjax="true" itemscope="url"><span itemprop="title">vim.js</span></a></span></span><span class="separator">/</span>
    <a class="btn-link disabled tooltipped tooltipped-e" href="#" aria-label="You must be signed in to make or propose changes">
      <span class="octicon octicon-plus"></span>
    </a>
</div>
</div>



  
  <div class="commit commit-tease js-details-container" >
    <p class="commit-title ">
        <a href="/coolwanglu/vim.js/commit/58414fb7faa8d2ad196ec8ae71f3b6660f00189a" class="message" data-pjax="true" title="enabled emterpreter; keep options for asyncify">enabled emterpreter; keep options for asyncify</a>
        
    </p>
    <div class="commit-meta">
      <button aria-label="Copy SHA" class="js-zeroclipboard zeroclipboard-link tooltipped tooltipped-s" data-clipboard-text="58414fb7faa8d2ad196ec8ae71f3b6660f00189a" data-copied-hint="Copied!" type="button"><span class="octicon octicon-clippy"></span></button>
      <a href="/coolwanglu/vim.js/commit/58414fb7faa8d2ad196ec8ae71f3b6660f00189a" class="sha-block" data-pjax>latest commit <span class="sha">58414fb7fa</span></a>

      <div class="authorship">
        <img alt="@coolwanglu" class="avatar" data-user="734614" height="20" src="https://avatars1.githubusercontent.com/u/734614?v=3&amp;s=40" width="20" />
        <span class="author-name"><a href="/coolwanglu" rel="author">coolwanglu</a></span>
        authored <time class="updated" datetime="2015-03-05T09:51:01Z" is="relative-time">Mar 5, 2015</time>

      </div>
    </div>
  </div>

  
<div class="file-wrap">
  <a href="/coolwanglu/vim.js/tree/58414fb7faa8d2ad196ec8ae71f3b6660f00189a" class="hidden js-permalink-shortcut" data-hotkey="y">Permalink</a>

  <table class="files" data-pjax>


    <tbody>
      <tr class="warning include-fragment-error">
        <td class="icon"><span class="octicon octicon-alert"></span></td>
        <td class="content" colspan="3">Failed to load latest commit information.</td>
      </tr>

        <tr>
          <td class="icon">
            <span class="octicon octicon-file-directory"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/coolwanglu/vim.js/tree/master/NW.js" class="js-directory-link" id="68dc92986a0f410b69c04ca4b88a3485-33fa30e6d170e451139bac9f1e67c9a2a8b966c8" title="NW.js">NW.js</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/coolwanglu/vim.js/commit/0a1b28f3d1b03b1500b0bf4aba26b1f619a42b10" class="message" data-pjax="true" title="update compiled vim.js">update compiled vim.js</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2015-01-28T12:51:14Z" is="time-ago">Jan 28, 2015</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-directory"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/coolwanglu/vim.js/tree/master/farsi" class="js-directory-link" id="cf9c3064d2a01299570c9ad8f4d26f2d-363c402c7ae78f2607fefdf0f52ba15a83133589" title="farsi">farsi</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/coolwanglu/vim.js/commit/580455274d2dcef3e0d04f4c2e5d2f908ecf42d3" class="message" data-pjax="true" title="initial">initial</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2013-11-27T19:19:35Z" is="time-ago">Nov 28, 2013</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-directory"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/coolwanglu/vim.js/tree/master/libs" class="js-directory-link" id="cb4cb2401e6e43cf74a54523b8da5f02-a6281054515b63946266c337f4275ec3e5cb69ee" title="libs">libs</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/coolwanglu/vim.js/commit/580455274d2dcef3e0d04f4c2e5d2f908ecf42d3" class="message" data-pjax="true" title="initial">initial</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2013-11-27T19:19:35Z" is="time-ago">Nov 27, 2013</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-directory"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/coolwanglu/vim.js/tree/master/nsis" class="js-directory-link" id="a053267ec5e3aa9cd204fa657a094ce9-f1049df56354f67d20b948ff209a71c8028e69cf" title="nsis">nsis</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/coolwanglu/vim.js/commit/580455274d2dcef3e0d04f4c2e5d2f908ecf42d3" class="message" data-pjax="true" title="initial">initial</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2013-11-27T19:19:35Z" is="time-ago">Nov 27, 2013</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-directory"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/coolwanglu/vim.js/tree/master/pixmaps" class="js-directory-link" id="23325f4cc2037d959c9f175163a378f6-953e24ec84211234aefa7774995bf3bb872d4854" title="pixmaps">pixmaps</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/coolwanglu/vim.js/commit/580455274d2dcef3e0d04f4c2e5d2f908ecf42d3" class="message" data-pjax="true" title="initial">initial</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2013-11-27T19:19:35Z" is="time-ago">Nov 27, 2013</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-directory"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/coolwanglu/vim.js/tree/master/runtime" class="js-directory-link" id="b4a619251c5c397f26d05c9b0e7bf97a-fe71dd0197791996f80f07b2b9bcda9da4ed6339" title="runtime">runtime</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/coolwanglu/vim.js/commit/580455274d2dcef3e0d04f4c2e5d2f908ecf42d3" class="message" data-pjax="true" title="initial">initial</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2013-11-27T19:19:35Z" is="time-ago">Nov 27, 2013</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-directory"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/coolwanglu/vim.js/tree/master/src" class="js-directory-link" id="25d902c24283ab8cfbac54dfa101ad31-4abf6d00693fbb8da265187b5f34a8090471507d" title="src">src</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/coolwanglu/vim.js/commit/954c99710ebfedb9f01d0373c5f7cae4a8736ca0" class="message" data-pjax="true" title="Revert &quot;inline recordTarget and shorten ignoreKeys&quot;. Accidentally committed everything.

This reverts commit 1eadf1604d150765486e1e80b4d382ceef0b614c.">Revert "inline recordTarget and shorten ignoreKeys". Accidentally com…</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2015-01-30T12:46:09Z" is="time-ago">Jan 30, 2015</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-directory"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/coolwanglu/vim.js/tree/master/web" class="js-directory-link" id="2567a5ec9705eb7ac2c984033e06189d-6b82fd4546c8430089103c07364972578b6c7350" title="web">web</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/coolwanglu/vim.js/commit/3a86820871f4ff230314f93a5f1a1a0c0cd58814" class="message" data-pjax="true" title="inline recordTarget and shorten ignoreKeys">inline recordTarget and shorten ignoreKeys</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2015-01-30T12:51:45Z" is="time-ago">Jan 30, 2015</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/coolwanglu/vim.js/blob/master/.gitattributes" class="js-directory-link" id="fc723d30b02a4cca7a534518111c1a66-1adf221c6ee7c6d473a5b2b1d346352c1488fb15" title=".gitattributes">.gitattributes</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/coolwanglu/vim.js/commit/696e8d20ea0096ef2cdd3d2e9e4b74521ee25cf8" class="message" data-pjax="true" title="add vim.js* for node-webkit">add vim.js* for node-webkit</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2015-01-26T09:33:10Z" is="time-ago">Jan 26, 2015</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/coolwanglu/vim.js/blob/master/AUTHORS" class="js-directory-link" id="3d350169560e75d0cf9fc8e3574a3639-18088abae4b7125e98a26b1553018e142da1f333" title="AUTHORS">AUTHORS</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/coolwanglu/vim.js/commit/7d809b828a08f98de1c6619c44e8a2cc5bb951ff" class="message" data-pjax="true" title="..">..</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2013-12-14T09:20:04Z" is="time-ago">Dec 14, 2013</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/coolwanglu/vim.js/blob/master/Contents" class="js-directory-link" id="c1df1da7a1ce305a3b60af9d5733ac1d-e34ae25600fc5d6a28ec4d813291c6f5f9f2edc1" title="Contents">Contents</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/coolwanglu/vim.js/commit/580455274d2dcef3e0d04f4c2e5d2f908ecf42d3" class="message" data-pjax="true" title="initial">initial</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2013-11-27T19:19:35Z" is="time-ago">Nov 27, 2013</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/coolwanglu/vim.js/blob/master/Contents.info" class="js-directory-link" id="b7275680d02907330f6ccce4e61b552d-9e855c7e985538013037a50559046912fb9b3a23" title="Contents.info">Contents.info</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/coolwanglu/vim.js/commit/580455274d2dcef3e0d04f4c2e5d2f908ecf42d3" class="message" data-pjax="true" title="initial">initial</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2013-11-27T19:19:35Z" is="time-ago">Nov 27, 2013</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/coolwanglu/vim.js/blob/master/Filelist" class="js-directory-link" id="2325c36a3293cb238c0e27d8252956a0-b32493337ad1df37211c4b9ed9d9c775bec68696" title="Filelist">Filelist</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/coolwanglu/vim.js/commit/580455274d2dcef3e0d04f4c2e5d2f908ecf42d3" class="message" data-pjax="true" title="initial">initial</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2013-11-27T19:19:35Z" is="time-ago">Nov 27, 2013</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/coolwanglu/vim.js/blob/master/LICENSE" class="js-directory-link" id="9879d6db96fd29134fc802214163b95a-e773de8e350ffd3cbdb5e305d1d4488451417b3c" title="LICENSE">LICENSE</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/coolwanglu/vim.js/commit/099cb9835ab8956a472de588c4431d2b1c580428" class="message" data-pjax="true" title="better support for guifont">better support for guifont</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2013-12-13T11:46:11Z" is="time-ago">Dec 13, 2013</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/coolwanglu/vim.js/blob/master/LICENSE.gplv2" class="js-directory-link" id="c9604b9f3d14738cbd62cfacd103e9c7-1f963da0d1ca40ea60730c03befcbbc6771740c3" title="LICENSE.gplv2">LICENSE.gplv2</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/coolwanglu/vim.js/commit/3a4a08722cc9c587ed71b26aa54656627ea49394" class="message" data-pjax="true" title="license stuff; beep">license stuff; beep</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2013-12-12T14:58:06Z" is="time-ago">Dec 12, 2013</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/coolwanglu/vim.js/blob/master/Makefile" class="js-directory-link" id="b67911656ef5d18c4ae36cb6741b7965-3565357d8a9a30d3bf22500f885187ccd4d18cea" title="Makefile">Makefile</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/coolwanglu/vim.js/commit/580455274d2dcef3e0d04f4c2e5d2f908ecf42d3" class="message" data-pjax="true" title="initial">initial</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2013-11-27T19:19:35Z" is="time-ago">Nov 27, 2013</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/coolwanglu/vim.js/blob/master/README.md" class="js-directory-link" id="04c6e90faac2675aa89e2176d2eec7d8-14b4dad08e128eaa806528b34123920647b246b8" title="README.md">README.md</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/coolwanglu/vim.js/commit/a2444a5e097b45e04ea9b49640998bea2a0d0f11" class="message" data-pjax="true" title="add firefox extension">add firefox extension</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2015-03-05T08:30:18Z" is="time-ago">Mar 5, 2015</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/coolwanglu/vim.js/blob/master/README.txt" class="js-directory-link" id="26fd799ea07494916e9da9b91b2aac64-c2fc2a955a8600b535c20147da0cfe187f965d96" title="README.txt">README.txt</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/coolwanglu/vim.js/commit/580455274d2dcef3e0d04f4c2e5d2f908ecf42d3" class="message" data-pjax="true" title="initial">initial</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2013-11-27T19:19:35Z" is="time-ago">Nov 27, 2013</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/coolwanglu/vim.js/blob/master/README.txt.info" class="js-directory-link" id="355f12a0f9e8e81dad39162dee0ba830-e7fa114944bddd6e0c2855070df4aa04d7e020d3" title="README.txt.info">README.txt.info</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/coolwanglu/vim.js/commit/580455274d2dcef3e0d04f4c2e5d2f908ecf42d3" class="message" data-pjax="true" title="initial">initial</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2013-11-27T19:19:35Z" is="time-ago">Nov 27, 2013</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/coolwanglu/vim.js/blob/master/README_ami.txt" class="js-directory-link" id="75fc6abcc643a393f86122cb708079e3-03cb6e24abfb528494f63f8b73a3f91ca83e703d" title="README_ami.txt">README_ami.txt</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/coolwanglu/vim.js/commit/580455274d2dcef3e0d04f4c2e5d2f908ecf42d3" class="message" data-pjax="true" title="initial">initial</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2013-11-27T19:19:35Z" is="time-ago">Nov 27, 2013</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/coolwanglu/vim.js/blob/master/README_ami.txt.info" class="js-directory-link" id="6c85c7aca536974ba19830f250df51fb-912436d6a4305f9995d2ca90691af27202a6fc83" title="README_ami.txt.info">README_ami.txt.info</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/coolwanglu/vim.js/commit/580455274d2dcef3e0d04f4c2e5d2f908ecf42d3" class="message" data-pjax="true" title="initial">initial</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2013-11-27T19:19:35Z" is="time-ago">Nov 27, 2013</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/coolwanglu/vim.js/blob/master/README_amibin.txt" class="js-directory-link" id="40ef8577dcc0130182a21b07092c470a-fbf5ba4c4dd8547d51ce8cb53397cbdc74cac5cf" title="README_amibin.txt">README_amibin.txt</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/coolwanglu/vim.js/commit/580455274d2dcef3e0d04f4c2e5d2f908ecf42d3" class="message" data-pjax="true" title="initial">initial</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2013-11-27T19:19:35Z" is="time-ago">Nov 27, 2013</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/coolwanglu/vim.js/blob/master/README_amibin.txt.info" class="js-directory-link" id="5b2794ab2a10d61fb899298e67edff8d-bdc3f028e2d518c5e86d6880d116b875a0685245" title="README_amibin.txt.info">README_amibin.txt.info</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/coolwanglu/vim.js/commit/580455274d2dcef3e0d04f4c2e5d2f908ecf42d3" class="message" data-pjax="true" title="initial">initial</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2013-11-27T19:19:35Z" is="time-ago">Nov 27, 2013</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/coolwanglu/vim.js/blob/master/README_amisrc.txt" class="js-directory-link" id="a90515fa3fc5f3f3f82498f3802be4d3-ddc58be95ffbf2e59149b1dd8cbfd6599aa52514" title="README_amisrc.txt">README_amisrc.txt</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/coolwanglu/vim.js/commit/580455274d2dcef3e0d04f4c2e5d2f908ecf42d3" class="message" data-pjax="true" title="initial">initial</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2013-11-27T19:19:35Z" is="time-ago">Nov 27, 2013</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/coolwanglu/vim.js/blob/master/README_amisrc.txt.info" class="js-directory-link" id="01545da715980e8b18d5b82abc1c0af5-476af9ac02f637cd652286d8a335468a58d51bb9" title="README_amisrc.txt.info">README_amisrc.txt.info</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/coolwanglu/vim.js/commit/580455274d2dcef3e0d04f4c2e5d2f908ecf42d3" class="message" data-pjax="true" title="initial">initial</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2013-11-27T19:19:35Z" is="time-ago">Nov 27, 2013</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/coolwanglu/vim.js/blob/master/README_bindos.txt" class="js-directory-link" id="5bbcbf5e7f84ceb456743d1ee741cec8-03c7c19ecf27222cf35ea6a054109f2ef4343a14" title="README_bindos.txt">README_bindos.txt</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/coolwanglu/vim.js/commit/580455274d2dcef3e0d04f4c2e5d2f908ecf42d3" class="message" data-pjax="true" title="initial">initial</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2013-11-27T19:19:35Z" is="time-ago">Nov 27, 2013</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/coolwanglu/vim.js/blob/master/README_dos.txt" class="js-directory-link" id="38492a40f1b072da7db90ef7ced03fab-662a7e785be2932ff13c680ca0fe3dd5e456896d" title="README_dos.txt">README_dos.txt</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/coolwanglu/vim.js/commit/580455274d2dcef3e0d04f4c2e5d2f908ecf42d3" class="message" data-pjax="true" title="initial">initial</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2013-11-27T19:19:35Z" is="time-ago">Nov 27, 2013</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/coolwanglu/vim.js/blob/master/README_extra.txt" class="js-directory-link" id="b8a8b89f0f78cc6d87ebf8dd062ef33d-e496912dc8a7b47ce2447af9f54104db4903599f" title="README_extra.txt">README_extra.txt</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/coolwanglu/vim.js/commit/580455274d2dcef3e0d04f4c2e5d2f908ecf42d3" class="message" data-pjax="true" title="initial">initial</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2013-11-27T19:19:35Z" is="time-ago">Nov 27, 2013</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/coolwanglu/vim.js/blob/master/README_mac.txt" class="js-directory-link" id="c73605339f586be4fdd4c681f0a86dd1-08888d9bb8747a47421ded96abfec7abb030b301" title="README_mac.txt">README_mac.txt</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/coolwanglu/vim.js/commit/580455274d2dcef3e0d04f4c2e5d2f908ecf42d3" class="message" data-pjax="true" title="initial">initial</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2013-11-27T19:19:35Z" is="time-ago">Nov 27, 2013</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/coolwanglu/vim.js/blob/master/README_ole.txt" class="js-directory-link" id="e6dd16275022f793bb35dea4ed8b84ee-233c0532f4a7fb309009b8f28926452c08b59600" title="README_ole.txt">README_ole.txt</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/coolwanglu/vim.js/commit/580455274d2dcef3e0d04f4c2e5d2f908ecf42d3" class="message" data-pjax="true" title="initial">initial</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2013-11-27T19:19:35Z" is="time-ago">Nov 27, 2013</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/coolwanglu/vim.js/blob/master/README_os2.txt" class="js-directory-link" id="ddbca7dc92b1392edbb47eed511fb13b-5602706e7173cb29fc9f2ccc2b451417d4841896" title="README_os2.txt">README_os2.txt</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/coolwanglu/vim.js/commit/580455274d2dcef3e0d04f4c2e5d2f908ecf42d3" class="message" data-pjax="true" title="initial">initial</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2013-11-27T19:19:35Z" is="time-ago">Nov 27, 2013</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/coolwanglu/vim.js/blob/master/README_os390.txt" class="js-directory-link" id="9eecd74bd811f1bebe7e27f8c71bb677-502b6f8b17aa0203a45ab190bae5eea347e751ae" title="README_os390.txt">README_os390.txt</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/coolwanglu/vim.js/commit/580455274d2dcef3e0d04f4c2e5d2f908ecf42d3" class="message" data-pjax="true" title="initial">initial</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2013-11-27T19:19:35Z" is="time-ago">Nov 27, 2013</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/coolwanglu/vim.js/blob/master/README_src.txt" class="js-directory-link" id="3b636376a8c629b4553f7b9c0b328e0a-3af95f23c74f7848f28edd070afafd8b32ffee8a" title="README_src.txt">README_src.txt</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/coolwanglu/vim.js/commit/580455274d2dcef3e0d04f4c2e5d2f908ecf42d3" class="message" data-pjax="true" title="initial">initial</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2013-11-27T19:19:35Z" is="time-ago">Nov 27, 2013</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/coolwanglu/vim.js/blob/master/README_srcdos.txt" class="js-directory-link" id="c62ecfeaeb5e0311b126a3559dc21a69-1b7cbcf5cba869f3d8ebcc66c5033e2e76d62cb1" title="README_srcdos.txt">README_srcdos.txt</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/coolwanglu/vim.js/commit/580455274d2dcef3e0d04f4c2e5d2f908ecf42d3" class="message" data-pjax="true" title="initial">initial</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2013-11-27T19:19:35Z" is="time-ago">Nov 27, 2013</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/coolwanglu/vim.js/blob/master/README_unix.txt" class="js-directory-link" id="39de2e4bef5b197240f4da4a8874deba-7aff642c6c4ecc297e4dd3c4454154005ae6ea5b" title="README_unix.txt">README_unix.txt</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/coolwanglu/vim.js/commit/580455274d2dcef3e0d04f4c2e5d2f908ecf42d3" class="message" data-pjax="true" title="initial">initial</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2013-11-27T19:19:35Z" is="time-ago">Nov 27, 2013</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/coolwanglu/vim.js/blob/master/README_vms.txt" class="js-directory-link" id="bfd27c6e00e0568568963ab278f78355-53364a127ee47133c91c6434df3eeb57987544d2" title="README_vms.txt">README_vms.txt</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/coolwanglu/vim.js/commit/580455274d2dcef3e0d04f4c2e5d2f908ecf42d3" class="message" data-pjax="true" title="initial">initial</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2013-11-27T19:19:35Z" is="time-ago">Nov 27, 2013</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/coolwanglu/vim.js/blob/master/README_w32s.txt" class="js-directory-link" id="ea73f56a6ab8cced35b8ee97b3462d3a-0b5d1aee01ad811f2045d678fcd028e3b8321c35" title="README_w32s.txt">README_w32s.txt</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/coolwanglu/vim.js/commit/580455274d2dcef3e0d04f4c2e5d2f908ecf42d3" class="message" data-pjax="true" title="initial">initial</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2013-11-27T19:19:35Z" is="time-ago">Nov 27, 2013</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/coolwanglu/vim.js/blob/master/TODO" class="js-directory-link" id="b7b1e314614cf326c6e2b6eba1540682-a420a82d827d1c0342ec2dc66879275210029b23" title="TODO">TODO</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/coolwanglu/vim.js/commit/20e3228d5dbd3ffc1698b452cd254de421a47cf8" class="message" data-pjax="true" title="dialog of ^w">dialog of ^w</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2013-12-31T08:38:51Z" is="time-ago">Dec 31, 2013</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/coolwanglu/vim.js/blob/master/Vim.info" class="js-directory-link" id="2c9011da0f4e8c3c6c15a5c7cca5de53-5c465ffab394d442dfdd993dfe5f013d3b5e9b5e" title="Vim.info">Vim.info</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/coolwanglu/vim.js/commit/580455274d2dcef3e0d04f4c2e5d2f908ecf42d3" class="message" data-pjax="true" title="initial">initial</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2013-11-27T19:19:35Z" is="time-ago">Nov 27, 2013</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/coolwanglu/vim.js/blob/master/Xxd.info" class="js-directory-link" id="d4539fa1f20159baf0ee97373b5453f0-7ae7643b25e69ee613c1d72818a484f66f1d5e10" title="Xxd.info">Xxd.info</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/coolwanglu/vim.js/commit/580455274d2dcef3e0d04f4c2e5d2f908ecf42d3" class="message" data-pjax="true" title="initial">initial</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2013-11-27T19:19:35Z" is="time-ago">Nov 27, 2013</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/coolwanglu/vim.js/blob/master/build.sh" class="js-directory-link" id="0b83f9dedf40d7356e5ca147a077acb4-ca3c93e798e0de0af7050569f20166e3ca1b4292" title="build.sh">build.sh</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/coolwanglu/vim.js/commit/58414fb7faa8d2ad196ec8ae71f3b6660f00189a" class="message" data-pjax="true" title="enabled emterpreter; keep options for asyncify">enabled emterpreter; keep options for asyncify</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2015-03-05T09:51:01Z" is="time-ago">Mar 5, 2015</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/coolwanglu/vim.js/blob/master/configure" class="js-directory-link" id="e2d5a00791bce9a01f99bc6fd613a39d-1d0c5b2ece5f8abb1ec76751085a5244e2fb2af0" title="configure">configure</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/coolwanglu/vim.js/commit/580455274d2dcef3e0d04f4c2e5d2f908ecf42d3" class="message" data-pjax="true" title="initial">initial</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2013-11-27T19:19:35Z" is="time-ago">Nov 27, 2013</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/coolwanglu/vim.js/blob/master/csdpmi4b.zip" class="js-directory-link" id="02aae5f5e0e39d2c37175bbe88e77ced-211396fae186cfe39de7a9b8121925b6cad1a2a3" title="csdpmi4b.zip">csdpmi4b.zip</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/coolwanglu/vim.js/commit/580455274d2dcef3e0d04f4c2e5d2f908ecf42d3" class="message" data-pjax="true" title="initial">initial</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2013-11-27T19:19:35Z" is="time-ago">Nov 27, 2013</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/coolwanglu/vim.js/blob/master/runtime.info" class="js-directory-link" id="832f3d22778910fb9d2340767c9ce701-6ff0468eab38e1b66da2e7983855f7a7b24cc0af" title="runtime.info">runtime.info</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/coolwanglu/vim.js/commit/580455274d2dcef3e0d04f4c2e5d2f908ecf42d3" class="message" data-pjax="true" title="initial">initial</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2013-11-27T19:19:35Z" is="time-ago">Nov 27, 2013</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/coolwanglu/vim.js/blob/master/src.info" class="js-directory-link" id="6caf26cf4c3b8cf8f394c7999966e2ae-1ab7c6cb1014a6d8f86280586c15f45faf7d23d5" title="src.info">src.info</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/coolwanglu/vim.js/commit/580455274d2dcef3e0d04f4c2e5d2f908ecf42d3" class="message" data-pjax="true" title="initial">initial</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2013-11-27T19:19:35Z" is="time-ago">Nov 27, 2013</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/coolwanglu/vim.js/blob/master/uninstal.txt" class="js-directory-link" id="0a1617ade413327f83d71790875a1433-9d0801026a31750f0476d07c6cc30b8518ed0e2b" title="uninstal.txt">uninstal.txt</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/coolwanglu/vim.js/commit/580455274d2dcef3e0d04f4c2e5d2f908ecf42d3" class="message" data-pjax="true" title="initial">initial</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2013-11-27T19:19:35Z" is="time-ago">Nov 27, 2013</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/coolwanglu/vim.js/blob/master/vimdir.info" class="js-directory-link" id="ba7f6dac55ae94b71d3cb598eb267c2a-ddb2a14626501d11864c939a5e95ce6b31a9eea7" title="vimdir.info">vimdir.info</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/coolwanglu/vim.js/commit/580455274d2dcef3e0d04f4c2e5d2f908ecf42d3" class="message" data-pjax="true" title="initial">initial</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2013-11-27T19:19:35Z" is="time-ago">Nov 27, 2013</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/coolwanglu/vim.js/blob/master/vimtutor.bat" class="js-directory-link" id="3d0e53bb67dadc7da6353c54e4dabc52-b147a8c44f392b591fc2f9d726271120be19f30d" title="vimtutor.bat">vimtutor.bat</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/coolwanglu/vim.js/commit/580455274d2dcef3e0d04f4c2e5d2f908ecf42d3" class="message" data-pjax="true" title="initial">initial</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2013-11-27T19:19:35Z" is="time-ago">Nov 27, 2013</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/coolwanglu/vim.js/blob/master/vimtutor.com" class="js-directory-link" id="67f030fb40bdba9775495d4c6cd7a563-71fdba427a647bd11542f297f418a6bf96659796" title="vimtutor.com">vimtutor.com</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/coolwanglu/vim.js/commit/580455274d2dcef3e0d04f4c2e5d2f908ecf42d3" class="message" data-pjax="true" title="initial">initial</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2013-11-27T19:19:35Z" is="time-ago">Nov 27, 2013</time></span>
          </td>
        </tr>
    </tbody>
  </table>

</div>


  <div id="readme" class="boxed-group flush clearfix announce instapaper_body md">
    <h3>
      <span class="octicon octicon-book"></span>
      README.md
    </h3>

    <article class="markdown-body entry-content" itemprop="mainContentOfPage"><h3><a id="user-content-vimjs--javascript-port-of-vim" class="anchor" href="#vimjs--javascript-port-of-vim" aria-hidden="true"><span class="octicon octicon-link"></span></a>Vim.js : JavaScript port of Vim</h3>

<p>A Tool/Toy for Non-Beginners</p>

<p>by Lu Wang</p>

<h3><a id="user-content-try-it-online" class="anchor" href="#try-it-online" aria-hidden="true"><span class="octicon octicon-link"></span></a><a href="http://coolwanglu.github.io/vim.js/emterpreter/vim.html">Try it online</a></h3>

<h3><a id="user-content-variations" class="anchor" href="#variations" aria-hidden="true"><span class="octicon octicon-link"></span></a>Variations</h3>

<ul>
<li><a href="https://github.com/coolwanglu/vim.js/tree/master/NW.js">NW.js</a></li>
<li><a href="https://addons.mozilla.org/en-US/firefox/addon/vimjs-extension/">Firefox extension</a></li>
<li><a href="http://coolwanglu.github.io/vim.js/asyncify/vim.html">Asyncify</a></li>
<li><a href="http://coolwanglu.github.io/vim.js/streamlinejs/vim.html">Streamline.js</a></li>
</ul>

<p>Recommended browsers: Firefox, Chrome, IE</p>

<h3><a id="user-content-vimjs-features" class="anchor" href="#vimjs-features" aria-hidden="true"><span class="octicon octicon-link"></span></a>Vim.js Features</h3>

<ul>
<li>ASM.js enabled</li>
<li>Persistent <code>~/.vimrc</code></li>
<li>Execute JavaScript from Vim.js </li>
<li>Read local files </li>
<li>Read files from Dropbox</li>
</ul>

<p>Run <code>:e $VIM/vimrc</code> for more detail.</p>

<h3><a id="user-content-vim-features" class="anchor" href="#vim-features" aria-hidden="true"><span class="octicon octicon-link"></span></a>Vim Features</h3>

<p>The online demo is built with the small feature set (<code>--with-features=small</code>), 
with also a few from the normal set.
Run <code>:version</code> to check details. 
(<code>--with-features=normal</code> is too large and too slow for online usage.)</p>

<p>Some features can be requested via pull requests, some are not intended to be included. 
Please discuss with me first before you work on a PR.</p>

<h3><a id="user-content-tips-for-hackers" class="anchor" href="#tips-for-hackers" aria-hidden="true"><span class="octicon octicon-link"></span></a>Tips for hackers</h3>

<ul>
<li>Need emscripten with ASYNCIFY enabled</li>
<li>Need GCC &amp; cproto (maybe) — Sometimes you need to run <code>make proto</code> when you see errors about 'undeclared variables/functions/structs' or '***.pro' file not found</li>
<li>Read <code>build.sh</code></li>
<li>The building process might take lots of memory</li>
</ul>

<h3><a id="user-content-contact" class="anchor" href="#contact" aria-hidden="true"><span class="octicon octicon-link"></span></a>Contact</h3>

<p>Lu Wang coolwanglu(a)gmail.com — please do not expect a prompt response.</p>

<h3><a id="user-content-license" class="anchor" href="#license" aria-hidden="true"><span class="octicon octicon-link"></span></a>License</h3>

<p>Read <code>LICENSE</code></p>
</article>
  </div>


        </div>

      </div><!-- /.repo-container -->
      <div class="modal-backdrop"></div>
    </div><!-- /.container -->
  </div><!-- /.site -->


    </div><!-- /.wrapper -->

      <div class="container">
  <div class="site-footer" role="contentinfo">
    <ul class="site-footer-links right">
        <li><a href="https://status.github.com/" data-ga-click="Footer, go to status, text:status">Status</a></li>
      <li><a href="https://developer.github.com" data-ga-click="Footer, go to api, text:api">API</a></li>
      <li><a href="https://training.github.com" data-ga-click="Footer, go to training, text:training">Training</a></li>
      <li><a href="https://shop.github.com" data-ga-click="Footer, go to shop, text:shop">Shop</a></li>
        <li><a href="https://github.com/blog" data-ga-click="Footer, go to blog, text:blog">Blog</a></li>
        <li><a href="https://github.com/about" data-ga-click="Footer, go to about, text:about">About</a></li>

    </ul>

    <a href="https://github.com" aria-label="Homepage">
      <span class="mega-octicon octicon-mark-github" title="GitHub"></span>
</a>
    <ul class="site-footer-links">
      <li>&copy; 2015 <span title="0.05365s from github-fe121-cp1-prd.iad.github.net">GitHub</span>, Inc.</li>
        <li><a href="https://github.com/site/terms" data-ga-click="Footer, go to terms, text:terms">Terms</a></li>
        <li><a href="https://github.com/site/privacy" data-ga-click="Footer, go to privacy, text:privacy">Privacy</a></li>
        <li><a href="https://github.com/security" data-ga-click="Footer, go to security, text:security">Security</a></li>
        <li><a href="https://github.com/contact" data-ga-click="Footer, go to contact, text:contact">Contact</a></li>
    </ul>
  </div>
</div>


    <div class="fullscreen-overlay js-fullscreen-overlay" id="fullscreen_overlay">
  <div class="fullscreen-container js-suggester-container">
    <div class="textarea-wrap">
      <textarea name="fullscreen-contents" id="fullscreen-contents" class="fullscreen-contents js-fullscreen-contents" placeholder=""></textarea>
      <div class="suggester-container">
        <div class="suggester fullscreen-suggester js-suggester js-navigation-container"></div>
      </div>
    </div>
  </div>
  <div class="fullscreen-sidebar">
    <a href="#" class="exit-fullscreen js-exit-fullscreen tooltipped tooltipped-w" aria-label="Exit Zen Mode">
      <span class="mega-octicon octicon-screen-normal"></span>
    </a>
    <a href="#" class="theme-switcher js-theme-switcher tooltipped tooltipped-w"
      aria-label="Switch themes">
      <span class="octicon octicon-color-mode"></span>
    </a>
  </div>
</div>



    

    <div id="ajax-error-message" class="flash flash-error">
      <span class="octicon octicon-alert"></span>
      <a href="#" class="octicon octicon-x flash-close js-ajax-error-dismiss" aria-label="Dismiss error"></a>
      Something went wrong with that request. Please try again.
    </div>


      <script crossorigin="anonymous" src="https://assets-cdn.github.com/assets/frameworks-447ce66a36506ebddc8e84b4e32a77f6062f3d3482e77dd21a77a01f0643ad98.js"></script>
      <script async="async" crossorigin="anonymous" src="https://assets-cdn.github.com/assets/github/index-273626d05f0daba1adb856ea6f9d82ff151f8b9f23a21044a761d2e2f843b354.js"></script>
      
      
  </body>
</html>

