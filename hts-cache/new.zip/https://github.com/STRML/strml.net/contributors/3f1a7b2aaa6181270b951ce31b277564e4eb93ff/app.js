

  <div class="commit file-history-tease">
    <div class="file-history-tease-header">
        <img alt="@STRML" class="avatar" height="24" src="https://avatars3.githubusercontent.com/u/1197375?v=3&amp;s=48" width="24" />
        <span class="author"><a href="/STRML" rel="author">STRML</a></span>
        <time datetime="2015-05-11T04:25:59Z" is="relative-time">May 10, 2015</time>
        <div class="commit-title">
            <a href="/STRML/strml.net/commit/3f1a7b2aaa6181270b951ce31b277564e4eb93ff" class="message" data-pjax="true" title="Allow skipping animation, and add header (really footer) bar.">Allow skipping animation, and add header (really footer) bar.</a>
        </div>
    </div>

    <div class="participation">
      <p class="quickstat">
        <a href="#blob_contributors_box" rel="facebox">
          <strong>1</strong>
           contributor
        </a>
      </p>
      
    </div>
    <div id="blob_contributors_box" style="display:none">
      <h2 class="facebox-header">Users who have contributed to this file</h2>
      <ul class="facebox-user-list">
          <li class="facebox-user-list-item">
            <img alt="@STRML" height="24" src="https://avatars3.githubusercontent.com/u/1197375?v=3&amp;s=48" width="24" />
            <a href="/STRML">STRML</a>
          </li>
      </ul>
    </div>
  </div>
