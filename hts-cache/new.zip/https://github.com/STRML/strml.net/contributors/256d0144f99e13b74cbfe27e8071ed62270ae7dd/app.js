

  <div class="commit file-history-tease">
    <div class="file-history-tease-header">
        <img alt="@STRML" class="avatar" height="24" src="https://avatars3.githubusercontent.com/u/1197375?v=3&amp;s=48" width="24" />
        <span class="author"><a href="/STRML" rel="author">STRML</a></span>
        <time datetime="2015-04-04T01:22:42Z" is="relative-time">Apr 3, 2015</time>
        <div class="commit-title">
            <a href="/STRML/strml.net/commit/256d0144f99e13b74cbfe27e8071ed62270ae7dd" class="message" data-pjax="true" title="Autoreplace urls in data.txt and some text tweaks">Autoreplace urls in data.txt and some text tweaks</a>
        </div>
    </div>

    <div class="participation">
      <p class="quickstat">
        <a href="#blob_contributors_box" rel="facebox">
          <strong>1</strong>
           contributor
        </a>
      </p>
      
    </div>
    <div id="blob_contributors_box" style="display:none">
      <h2 class="facebox-header">Users who have contributed to this file</h2>
      <ul class="facebox-user-list">
          <li class="facebox-user-list-item">
            <img alt="@STRML" height="24" src="https://avatars3.githubusercontent.com/u/1197375?v=3&amp;s=48" width="24" />
            <a href="/STRML">STRML</a>
          </li>
      </ul>
    </div>
  </div>
