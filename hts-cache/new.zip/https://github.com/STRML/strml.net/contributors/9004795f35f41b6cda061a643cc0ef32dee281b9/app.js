

  <div class="commit file-history-tease">
    <div class="file-history-tease-header">
        <img alt="@STRML" class="avatar" height="24" src="https://avatars3.githubusercontent.com/u/1197375?v=3&amp;s=48" width="24" />
        <span class="author"><a href="/STRML" rel="author">STRML</a></span>
        <time datetime="2015-05-15T22:52:53Z" is="relative-time">May 15, 2015</time>
        <div class="commit-title">
            <a href="/STRML/strml.net/commit/9004795f35f41b6cda061a643cc0ef32dee281b9" class="message" data-pjax="true" title="Don&#39;t goof if the browser isn&#39;t IE/FF/Webkit">Don't goof if the browser isn't IE/FF/Webkit</a>
        </div>
    </div>

    <div class="participation">
      <p class="quickstat">
        <a href="#blob_contributors_box" rel="facebox">
          <strong>1</strong>
           contributor
        </a>
      </p>
      
    </div>
    <div id="blob_contributors_box" style="display:none">
      <h2 class="facebox-header">Users who have contributed to this file</h2>
      <ul class="facebox-user-list">
          <li class="facebox-user-list-item">
            <img alt="@STRML" height="24" src="https://avatars3.githubusercontent.com/u/1197375?v=3&amp;s=48" width="24" />
            <a href="/STRML">STRML</a>
          </li>
      </ul>
    </div>
  </div>
