


<!DOCTYPE html>
<html lang="en" class="">
  <head prefix="og: http://ogp.me/ns# fb: http://ogp.me/ns/fb# object: http://ogp.me/ns/object# article: http://ogp.me/ns/article# profile: http://ogp.me/ns/profile#">
    <meta charset='utf-8'>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Language" content="en">
    
    
    <title>strml.net/app.js at 5aae00b4c56baa8021580f896c2ca292cd28d867 · STRML/strml.net · GitHub</title>
    <link rel="search" type="application/opensearchdescription+xml" href="/opensearch.xml" title="GitHub">
    <link rel="fluid-icon" href="https://github.com/fluidicon.png" title="GitHub">
    <link rel="apple-touch-icon" sizes="57x57" href="/apple-touch-icon-114.png">
    <link rel="apple-touch-icon" sizes="114x114" href="/apple-touch-icon-114.png">
    <link rel="apple-touch-icon" sizes="72x72" href="/apple-touch-icon-144.png">
    <link rel="apple-touch-icon" sizes="144x144" href="/apple-touch-icon-144.png">
    <meta property="fb:app_id" content="1401488693436528">

      <meta content="@github" name="twitter:site" /><meta content="summary" name="twitter:card" /><meta content="STRML/strml.net" name="twitter:title" /><meta content="STRML: Projects &amp;amp; Work. Contribute to strml.net development by creating an account on GitHub." name="twitter:description" /><meta content="https://avatars1.githubusercontent.com/u/1197375?v=3&amp;s=400" name="twitter:image:src" />
      <meta content="GitHub" property="og:site_name" /><meta content="object" property="og:type" /><meta content="https://avatars1.githubusercontent.com/u/1197375?v=3&amp;s=400" property="og:image" /><meta content="STRML/strml.net" property="og:title" /><meta content="https://github.com/STRML/strml.net" property="og:url" /><meta content="STRML: Projects &amp; Work. Contribute to strml.net development by creating an account on GitHub." property="og:description" />
      <meta name="browser-stats-url" content="https://api.github.com/_private/browser/stats">
    <meta name="browser-errors-url" content="https://api.github.com/_private/browser/errors">
    <link rel="assets" href="https://assets-cdn.github.com/">
    
    <meta name="pjax-timeout" content="1000">
    

    <meta name="msapplication-TileImage" content="/windows-tile.png">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="selected-link" value="repo_source" data-pjax-transient>
      <meta name="google-analytics" content="UA-3769691-2">

    <meta content="collector.githubapp.com" name="octolytics-host" /><meta content="collector-cdn.github.com" name="octolytics-script-host" /><meta content="github" name="octolytics-app-id" /><meta content="783D1521:06C1:10A3F42:5571A8C8" name="octolytics-dimension-request_id" />
    
    <meta content="Rails, view, blob#blame" name="analytics-event" />
    <meta class="js-ga-set" name="dimension1" content="Logged Out">
    <meta class="js-ga-set" name="dimension2" content="Header v3">
    <meta name="is-dotcom" content="true">
      <meta name="hostname" content="github.com">
    <meta name="user-login" content="">

    
    <link rel="icon" type="image/x-icon" href="https://assets-cdn.github.com/favicon.ico">


    <meta content="authenticity_token" name="csrf-param" />
<meta content="UlSkS0e1CiapyivGhqUZ9hRoj9I3J1HvpF0nr5upH/K1RP6MtoCMyrBuzmmWOEXmkROJAUmNU12IjLVEvBielw==" name="csrf-token" />

    <link crossorigin="anonymous" href="https://assets-cdn.github.com/assets/github/index-6967b378b26829cc5a2ea2ad4209ff0af50f2a65057962219dc9dcf8942683f0.css" media="all" rel="stylesheet" />
    <link crossorigin="anonymous" href="https://assets-cdn.github.com/assets/github2/index-73bfe123ff406f4bf8959a28667410beaac1485e71c92d4725a3d7afc45fc4c5.css" media="all" rel="stylesheet" />
    
    


    <meta http-equiv="x-pjax-version" content="b2ca4753a2f40f3bd3d3d6fd0fe8b32e">

            <meta content="noindex, nofollow" name="robots" />

  <meta name="description" content="STRML: Projects &amp; Work. Contribute to strml.net development by creating an account on GitHub.">
  <meta name="go-import" content="github.com/STRML/strml.net git https://github.com/STRML/strml.net.git">

  <meta content="1197375" name="octolytics-dimension-user_id" /><meta content="STRML" name="octolytics-dimension-user_login" /><meta content="33389442" name="octolytics-dimension-repository_id" /><meta content="STRML/strml.net" name="octolytics-dimension-repository_nwo" /><meta content="true" name="octolytics-dimension-repository_public" /><meta content="false" name="octolytics-dimension-repository_is_fork" /><meta content="33389442" name="octolytics-dimension-repository_network_root_id" /><meta content="STRML/strml.net" name="octolytics-dimension-repository_network_root_nwo" />
  <link href="https://github.com/STRML/strml.net/commits/5aae00b4c56baa8021580f896c2ca292cd28d867.atom" rel="alternate" title="Recent Commits to strml.net:5aae00b4c56baa8021580f896c2ca292cd28d867" type="application/atom+xml">

  </head>


  <body class="logged_out  env-production  vis-public">
    <a href="#start-of-content" tabindex="1" class="accessibility-aid js-skip-to-content">Skip to content</a>
    <div class="wrapper">
      
      
      


        
        <div class="header header-logged-out" role="banner">
  <div class="container clearfix">

    <a class="header-logo-wordmark" href="https://github.com/" data-ga-click="(Logged out) Header, go to homepage, icon:logo-wordmark">
      <span class="mega-octicon octicon-logo-github"></span>
    </a>

    <div class="header-actions" role="navigation">
        <a class="btn btn-primary" href="/join" data-ga-click="(Logged out) Header, clicked Sign up, text:sign-up">Sign up</a>
      <a class="btn" href="/login?return_to=%2FSTRML%2Fstrml.net%2Fblame%2F5aae00b4c56baa8021580f896c2ca292cd28d867%2Fapp.js" data-ga-click="(Logged out) Header, clicked Sign in, text:sign-in">Sign in</a>
    </div>

    <div class="site-search repo-scope js-site-search" role="search">
      <form accept-charset="UTF-8" action="/STRML/strml.net/search" class="js-site-search-form" data-global-search-url="/search" data-repo-search-url="/STRML/strml.net/search" method="get"><div style="margin:0;padding:0;display:inline"><input name="utf8" type="hidden" value="&#x2713;" /></div>
  <label class="js-chromeless-input-container form-control">
    <div class="scope-badge">This repository</div>
    <input type="text"
      class="js-site-search-focus js-site-search-field is-clearable chromeless-input"
      data-hotkey="s"
      name="q"
      placeholder="Search"
      data-global-scope-placeholder="Search GitHub"
      data-repo-scope-placeholder="Search"
      tabindex="1"
      autocapitalize="off">
  </label>
</form>
    </div>

      <ul class="header-nav left" role="navigation">
          <li class="header-nav-item">
            <a class="header-nav-link" href="/explore" data-ga-click="(Logged out) Header, go to explore, text:explore">Explore</a>
          </li>
          <li class="header-nav-item">
            <a class="header-nav-link" href="/features" data-ga-click="(Logged out) Header, go to features, text:features">Features</a>
          </li>
          <li class="header-nav-item">
            <a class="header-nav-link" href="https://enterprise.github.com/" data-ga-click="(Logged out) Header, go to enterprise, text:enterprise">Enterprise</a>
          </li>
          <li class="header-nav-item">
            <a class="header-nav-link" href="/blog" data-ga-click="(Logged out) Header, go to blog, text:blog">Blog</a>
          </li>
      </ul>

  </div>
</div>



      <div id="start-of-content" class="accessibility-aid"></div>
          <div class="site" itemscope itemtype="http://schema.org/WebPage">
    <div id="js-flash-container">
      
    </div>
    <div class="pagehead repohead instapaper_ignore readability-menu">
      <div class="container">

        
<ul class="pagehead-actions">

  <li>
      <a href="/login?return_to=%2FSTRML%2Fstrml.net"
    class="btn btn-sm btn-with-count tooltipped tooltipped-n"
    aria-label="You must be signed in to watch a repository" rel="nofollow">
    <span class="octicon octicon-eye"></span>
    Watch
  </a>
  <a class="social-count" href="/STRML/strml.net/watchers">
    8
  </a>

  </li>

  <li>
      <a href="/login?return_to=%2FSTRML%2Fstrml.net"
    class="btn btn-sm btn-with-count tooltipped tooltipped-n"
    aria-label="You must be signed in to star a repository" rel="nofollow">
    <span class="octicon octicon-star"></span>
    Star
  </a>

    <a class="social-count js-social-count" href="/STRML/strml.net/stargazers">
      160
    </a>

  </li>

    <li>
      <a href="/login?return_to=%2FSTRML%2Fstrml.net"
        class="btn btn-sm btn-with-count tooltipped tooltipped-n"
        aria-label="You must be signed in to fork a repository" rel="nofollow">
        <span class="octicon octicon-repo-forked"></span>
        Fork
      </a>
      <a href="/STRML/strml.net/network" class="social-count">
        43
      </a>
    </li>
</ul>

        <h1 itemscope itemtype="http://data-vocabulary.org/Breadcrumb" class="entry-title public">
          <span class="mega-octicon octicon-repo"></span>
          <span class="author"><a href="/STRML" class="url fn" itemprop="url" rel="author"><span itemprop="title">STRML</span></a></span><!--
       --><span class="path-divider">/</span><!--
       --><strong><a href="/STRML/strml.net" data-pjax="#js-repo-pjax-container">strml.net</a></strong>

          <span class="page-context-loader">
            <img alt="" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </span>

        </h1>
      </div><!-- /.container -->
    </div><!-- /.repohead -->

    <div class="container">
      <div class="repository-with-sidebar repo-container new-discussion-timeline  ">
        <div class="repository-sidebar clearfix">
            
<nav class="sunken-menu repo-nav js-repo-nav js-sidenav-container-pjax js-octicon-loaders"
     role="navigation"
     data-pjax="#js-repo-pjax-container"
     data-issue-count-url="/STRML/strml.net/issues/counts">
  <ul class="sunken-menu-group">
    <li class="tooltipped tooltipped-w" aria-label="Code">
      <a href="/STRML/strml.net" aria-label="Code" class="selected js-selected-navigation-item sunken-menu-item" data-hotkey="g c" data-selected-links="repo_source repo_downloads repo_commits repo_releases repo_tags repo_branches /STRML/strml.net">
        <span class="octicon octicon-code"></span> <span class="full-word">Code</span>
        <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>    </li>

      <li class="tooltipped tooltipped-w" aria-label="Issues">
        <a href="/STRML/strml.net/issues" aria-label="Issues" class="js-selected-navigation-item sunken-menu-item" data-hotkey="g i" data-selected-links="repo_issues repo_labels repo_milestones /STRML/strml.net/issues">
          <span class="octicon octicon-issue-opened"></span> <span class="full-word">Issues</span>
          <span class="js-issue-replace-counter"></span>
          <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>      </li>

    <li class="tooltipped tooltipped-w" aria-label="Pull requests">
      <a href="/STRML/strml.net/pulls" aria-label="Pull requests" class="js-selected-navigation-item sunken-menu-item" data-hotkey="g p" data-selected-links="repo_pulls /STRML/strml.net/pulls">
          <span class="octicon octicon-git-pull-request"></span> <span class="full-word">Pull requests</span>
          <span class="js-pull-replace-counter"></span>
          <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>    </li>

  </ul>
  <div class="sunken-menu-separator"></div>
  <ul class="sunken-menu-group">

    <li class="tooltipped tooltipped-w" aria-label="Pulse">
      <a href="/STRML/strml.net/pulse" aria-label="Pulse" class="js-selected-navigation-item sunken-menu-item" data-selected-links="pulse /STRML/strml.net/pulse">
        <span class="octicon octicon-pulse"></span> <span class="full-word">Pulse</span>
        <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>    </li>

    <li class="tooltipped tooltipped-w" aria-label="Graphs">
      <a href="/STRML/strml.net/graphs" aria-label="Graphs" class="js-selected-navigation-item sunken-menu-item" data-selected-links="repo_graphs repo_contributors /STRML/strml.net/graphs">
        <span class="octicon octicon-graph"></span> <span class="full-word">Graphs</span>
        <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>    </li>
  </ul>


</nav>

              <div class="only-with-full-nav">
                  
<div class="js-clone-url clone-url open"
  data-protocol-type="http">
  <h3><span class="text-emphasized">HTTPS</span> clone URL</h3>
  <div class="input-group js-zeroclipboard-container">
    <input type="text" class="input-mini input-monospace js-url-field js-zeroclipboard-target"
           value="https://github.com/STRML/strml.net.git" readonly="readonly">
    <span class="input-group-button">
      <button aria-label="Copy to clipboard" class="js-zeroclipboard btn btn-sm zeroclipboard-button tooltipped tooltipped-s" data-copied-hint="Copied!" type="button"><span class="octicon octicon-clippy"></span></button>
    </span>
  </div>
</div>

  
<div class="js-clone-url clone-url "
  data-protocol-type="subversion">
  <h3><span class="text-emphasized">Subversion</span> checkout URL</h3>
  <div class="input-group js-zeroclipboard-container">
    <input type="text" class="input-mini input-monospace js-url-field js-zeroclipboard-target"
           value="https://github.com/STRML/strml.net" readonly="readonly">
    <span class="input-group-button">
      <button aria-label="Copy to clipboard" class="js-zeroclipboard btn btn-sm zeroclipboard-button tooltipped tooltipped-s" data-copied-hint="Copied!" type="button"><span class="octicon octicon-clippy"></span></button>
    </span>
  </div>
</div>



<div class="clone-options">You can clone with
  <form accept-charset="UTF-8" action="/users/set_protocol?protocol_selector=http&amp;protocol_type=clone" class="inline-form js-clone-selector-form " data-remote="true" method="post"><div style="margin:0;padding:0;display:inline"><input name="utf8" type="hidden" value="&#x2713;" /><input name="authenticity_token" type="hidden" value="AIe/PWzA1bF1dMOLdUOClpKqejjJPM1T2z8Uz0Tqk4/GuRuwq9kkaMEyDbaGFpiLY57TSvXbwbGInw6OXbXdYg==" /></div><button class="btn-link js-clone-selector" data-protocol="http" type="submit">HTTPS</button></form> or <form accept-charset="UTF-8" action="/users/set_protocol?protocol_selector=subversion&amp;protocol_type=clone" class="inline-form js-clone-selector-form " data-remote="true" method="post"><div style="margin:0;padding:0;display:inline"><input name="utf8" type="hidden" value="&#x2713;" /><input name="authenticity_token" type="hidden" value="6CtIXmlNJyRSn5KFk28/N90WmNTAS7EH+6wsQATYv/WdSOIXkLhgK9jtUsCl3GL1BJbvRZkFkxS8FzylqVI3MQ==" /></div><button class="btn-link js-clone-selector" data-protocol="subversion" type="submit">Subversion</button></form>.
  <a href="https://help.github.com/articles/which-remote-url-should-i-use" class="help tooltipped tooltipped-n" aria-label="Get help on which URL is right for you.">
    <span class="octicon octicon-question"></span>
  </a>
</div>




                <a href="/STRML/strml.net/archive/5aae00b4c56baa8021580f896c2ca292cd28d867.zip"
                   class="btn btn-sm sidebar-button"
                   aria-label="Download the contents of STRML/strml.net as a zip file"
                   title="Download the contents of STRML/strml.net as a zip file"
                   rel="nofollow">
                  <span class="octicon octicon-cloud-download"></span>
                  Download ZIP
                </a>
              </div>
        </div><!-- /.repository-sidebar -->

        <div id="js-repo-pjax-container" class="repository-content context-loader-container" data-pjax-container>

          
<a href="/STRML/strml.net/blame/5aae00b4c56baa8021580f896c2ca292cd28d867/app.js" class="hidden js-permalink-shortcut" data-hotkey="y">Permalink</a>

<div class="breadcrumb css-truncate blame-breadcrumb js-zeroclipboard-container">
  <span class="css-truncate-target js-zeroclipboard-target"><span class="repo-root js-repo-root"><span itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb"><a href="/STRML/strml.net/tree/5aae00b4c56baa8021580f896c2ca292cd28d867" class="" data-branch="5aae00b4c56baa8021580f896c2ca292cd28d867" data-pjax="true" itemscope="url" rel="nofollow"><span itemprop="title">strml.net</span></a></span></span><span class="separator">/</span><strong class="final-path">app.js</strong></span>
  <button aria-label="Copy file path to clipboard" class="js-zeroclipboard btn btn-sm zeroclipboard-button tooltipped tooltipped-s" data-copied-hint="Copied!" type="button"><span class="octicon octicon-clippy"></span></button>
</div>

<div class="line-age-legend">
  <span>Newer</span>
  <ol>
      <li class="heat1"></li>
      <li class="heat2"></li>
      <li class="heat3"></li>
      <li class="heat4"></li>
      <li class="heat5"></li>
      <li class="heat6"></li>
      <li class="heat7"></li>
      <li class="heat8"></li>
      <li class="heat9"></li>
      <li class="heat10"></li>
  </ol>
  <span>Older</span>
</div>

<div class="file">
  <div class="file-header">
    <div class="file-actions">
      <div class="btn-group">
        <a href="/STRML/strml.net/raw/5aae00b4c56baa8021580f896c2ca292cd28d867/app.js" class="btn btn-sm" id="raw-url">Raw</a>
        <a href="/STRML/strml.net/blob/5aae00b4c56baa8021580f896c2ca292cd28d867/app.js" class="btn btn-sm js-update-url-with-hash">Normal view</a>
        <a href="/STRML/strml.net/commits/5aae00b4c56baa8021580f896c2ca292cd28d867/app.js" class="btn btn-sm" rel="nofollow">History</a>
      </div>
    </div>



    <div class="file-info">
      <span class="octicon octicon-file-text"></span>
      <span class="file-mode" title="File Mode">100644</span>
      <span class="file-info-divider"></span>
        102 lines (87 sloc)
        <span class="file-info-divider"></span>
      3.313 kB
    </div>
  </div>

  <div class="blob-wrapper">
    <table class="blame-container highlight data js-file-line-container">
        <tr class="blame-commit">
          <td class="blame-commit-info" rowspan="102">
            <a href="/STRML/strml.net/commit/5aae00b4c56baa8021580f896c2ca292cd28d867" class="blame-sha">5aae00b</a>
            <img alt="@STRML" class="avatar blame-commit-avatar" height="32" src="https://avatars2.githubusercontent.com/u/1197375?v=3&amp;s=64" width="32" />
            <a href="/STRML/strml.net/commit/5aae00b4c56baa8021580f896c2ca292cd28d867" class="blame-commit-title" title="Initial commit.">Initial commit.</a>
            <div class="blame-commit-meta">
              <a href="/STRML" class="muted-link" rel="author">STRML</a> authored
              <time datetime="2015-04-04T00:50:45Z" is="relative-time">Apr 3, 2015</time>
            </div>
          </td>
        </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1">1</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1"><span class="pl-s"><span class="pl-pds">&#39;</span>use strict<span class="pl-pds">&#39;</span></span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L2">2</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC2"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L3">3</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC3"><span class="pl-k">var</span> dataText <span class="pl-k">=</span> <span class="pl-c1">require</span>(<span class="pl-s"><span class="pl-pds">&#39;</span>raw!./data.txt<span class="pl-pds">&#39;</span></span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L4">4</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC4"><span class="pl-k">var</span> pgpText <span class="pl-k">=</span> <span class="pl-c1">require</span>(<span class="pl-s"><span class="pl-pds">&#39;</span>raw!./pgp.txt<span class="pl-pds">&#39;</span></span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L5">5</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC5"><span class="pl-k">var</span> styleText <span class="pl-k">=</span> <span class="pl-c1">require</span>(<span class="pl-s"><span class="pl-pds">&#39;</span>raw!./styles.css<span class="pl-pds">&#39;</span></span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L6">6</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC6"><span class="pl-k">var</span> prefix <span class="pl-k">=</span> <span class="pl-c1">require</span>(<span class="pl-s"><span class="pl-pds">&#39;</span>./lib/getPrefix<span class="pl-pds">&#39;</span></span>)();</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L7">7</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC7">styleText <span class="pl-k">=</span> styleText.<span class="pl-c1">replace</span>(<span class="pl-sr"><span class="pl-pds">/</span>-webkit-<span class="pl-pds">/</span>g</span>, prefix);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L8">8</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC8"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L9">9</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC9"><span class="pl-c1">document</span>.addEventListener(<span class="pl-s"><span class="pl-pds">&quot;</span>DOMContentLoaded<span class="pl-pds">&quot;</span></span>, doWork);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L10">10</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC10"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L11">11</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC11"><span class="pl-k">var</span> openComment <span class="pl-k">=</span> <span class="pl-c1">false</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L12">12</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC12"><span class="pl-k">var</span> isDev <span class="pl-k">=</span> <span class="pl-c1">window</span>.<span class="pl-c1">location</span>.<span class="pl-c1">hostname</span> <span class="pl-k">===</span> <span class="pl-s"><span class="pl-pds">&#39;</span>localhost<span class="pl-pds">&#39;</span></span> <span class="pl-k">&amp;&amp;</span> <span class="pl-c1">false</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L13">13</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC13"><span class="pl-k">var</span> speed <span class="pl-k">=</span> isDev <span class="pl-k">?</span> <span class="pl-c1">4</span> <span class="pl-k">:</span> <span class="pl-c1">16</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L14">14</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC14"><span class="pl-k">var</span> style, styleEl, dataEl, pgpEl;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L15">15</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC15"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L16">16</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC16"><span class="pl-k">function</span> <span class="pl-en">doWork</span>(){</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L17">17</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC17">  style <span class="pl-k">=</span> <span class="pl-c1">document</span>.<span class="pl-c1">getElementById</span>(<span class="pl-s"><span class="pl-pds">&#39;</span>style-tag<span class="pl-pds">&#39;</span></span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L18">18</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC18">  styleEl <span class="pl-k">=</span> <span class="pl-c1">document</span>.<span class="pl-c1">getElementById</span>(<span class="pl-s"><span class="pl-pds">&#39;</span>style-text<span class="pl-pds">&#39;</span></span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L19">19</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC19">  dataEl <span class="pl-k">=</span> <span class="pl-c1">document</span>.<span class="pl-c1">getElementById</span>(<span class="pl-s"><span class="pl-pds">&#39;</span>data-text<span class="pl-pds">&#39;</span></span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L20">20</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC20">  pgpEl <span class="pl-k">=</span> <span class="pl-c1">document</span>.<span class="pl-c1">getElementById</span>(<span class="pl-s"><span class="pl-pds">&#39;</span>pgp-text<span class="pl-pds">&#39;</span></span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L21">21</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC21"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L22">22</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC22">  styleEl.addEventListener(<span class="pl-s"><span class="pl-pds">&#39;</span>input<span class="pl-pds">&#39;</span></span>, onStyleElChange);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L23">23</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC23"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L24">24</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC24">  <span class="pl-c">// starting it off</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L25">25</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC25">  writeTo(styleEl, styleText, <span class="pl-c1">0</span>, speed, <span class="pl-c1">true</span>, <span class="pl-c1">1</span>, <span class="pl-k">function</span>() {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L26">26</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC26">    writeTo(dataEl, dataText, <span class="pl-c1">0</span>, speed, <span class="pl-c1">false</span>, <span class="pl-c1">1</span>, <span class="pl-k">function</span>() {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L27">27</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC27">      writeTo(pgpEl, pgpText, <span class="pl-c1">0</span>, speed, <span class="pl-c1">false</span>, <span class="pl-c1">16</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L28">28</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC28">    });</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L29">29</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC29">  });</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L30">30</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC30">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L31">31</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC31"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L32">32</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC32"><span class="pl-k">var</span> styleBuffer <span class="pl-k">=</span> <span class="pl-s"><span class="pl-pds">&#39;</span><span class="pl-pds">&#39;</span></span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L33">33</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC33"><span class="pl-k">function</span> <span class="pl-en">writeChar</span>(<span class="pl-smi">el</span>, <span class="pl-smi">char</span>){</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L34">34</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC34">  <span class="pl-k">var</span> fullText <span class="pl-k">=</span> el.innerHTML;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L35">35</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC35">  <span class="pl-k">if</span> (char <span class="pl-k">===</span> <span class="pl-s"><span class="pl-pds">&#39;</span>/<span class="pl-pds">&#39;</span></span> <span class="pl-k">&amp;&amp;</span> openComment <span class="pl-k">===</span> <span class="pl-c1">false</span>) {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L36">36</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC36">    openComment <span class="pl-k">=</span> <span class="pl-c1">true</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L37">37</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC37">    fullText <span class="pl-k">+=</span> char;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L38">38</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC38">  } <span class="pl-k">else</span> <span class="pl-k">if</span> (char <span class="pl-k">===</span> <span class="pl-s"><span class="pl-pds">&#39;</span>/<span class="pl-pds">&#39;</span></span> <span class="pl-k">&amp;&amp;</span> fullText.<span class="pl-c1">slice</span>(<span class="pl-k">-</span><span class="pl-c1">1</span>) <span class="pl-k">===</span> <span class="pl-s"><span class="pl-pds">&#39;</span>*<span class="pl-pds">&#39;</span></span> <span class="pl-k">&amp;&amp;</span> openComment <span class="pl-k">===</span> <span class="pl-c1">true</span>) {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L39">39</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC39">    openComment <span class="pl-k">=</span> <span class="pl-c1">false</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L40">40</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC40">    <span class="pl-c">// Unfortunately we can&#39;t just open a span and close it, because the browser will helpfully</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L41">41</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC41">    <span class="pl-c">// &#39;fix&#39; it for us, and we&#39;ll end up with a single-character span and an empty closing tag.</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L42">42</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC42">    fullText <span class="pl-k">=</span> fullText.<span class="pl-c1">replace</span>(<span class="pl-sr"><span class="pl-pds">/</span>(<span class="pl-cce">\/\*</span>(?:<span class="pl-c1">[<span class="pl-k">^</span>]</span>(?!<span class="pl-cce">\/\*</span>))<span class="pl-k">*</span><span class="pl-cce">\*</span>)<span class="pl-k">$</span><span class="pl-pds">/</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>&lt;span class=&quot;comment&quot;&gt;$1/&lt;/span&gt;<span class="pl-pds">&#39;</span></span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L43">43</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC43">  } <span class="pl-k">else</span> <span class="pl-k">if</span> (char <span class="pl-k">===</span> <span class="pl-s"><span class="pl-pds">&#39;</span>:<span class="pl-pds">&#39;</span></span>) {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L44">44</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC44">    fullText <span class="pl-k">=</span> fullText.<span class="pl-c1">replace</span>(<span class="pl-sr"><span class="pl-pds">/</span>(<span class="pl-c1">[<span class="pl-c1">a-zA-Z</span>- ^<span class="pl-cce">\n</span>]</span><span class="pl-k">*</span>)<span class="pl-k">$</span><span class="pl-pds">/</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>&lt;span class=&quot;key&quot;&gt;$1&lt;/span&gt;:<span class="pl-pds">&#39;</span></span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L45">45</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC45">  } <span class="pl-k">else</span> <span class="pl-k">if</span> (char <span class="pl-k">===</span> <span class="pl-s"><span class="pl-pds">&#39;</span>;<span class="pl-pds">&#39;</span></span>) {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L46">46</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC46">    fullText <span class="pl-k">=</span> fullText.<span class="pl-c1">replace</span>(<span class="pl-sr"><span class="pl-pds">/</span>(<span class="pl-c1">[<span class="pl-k">^</span>:]</span><span class="pl-k">*</span>)<span class="pl-k">$</span><span class="pl-pds">/</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>&lt;span class=&quot;value&quot;&gt;$1&lt;/span&gt;;<span class="pl-pds">&#39;</span></span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L47">47</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC47">  } <span class="pl-k">else</span> <span class="pl-k">if</span> (char <span class="pl-k">===</span> <span class="pl-s"><span class="pl-pds">&#39;</span>{<span class="pl-pds">&#39;</span></span>) {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L48">48</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC48">    fullText <span class="pl-k">=</span> fullText.<span class="pl-c1">replace</span>(<span class="pl-sr"><span class="pl-pds">/</span>(<span class="pl-c1">.</span><span class="pl-k">*</span>)<span class="pl-k">$</span><span class="pl-pds">/</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>&lt;span class=&quot;selector&quot;&gt;$1&lt;/span&gt;{<span class="pl-pds">&#39;</span></span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L49">49</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC49">  } <span class="pl-k">else</span> <span class="pl-k">if</span> (char <span class="pl-k">===</span> <span class="pl-s"><span class="pl-pds">&#39;</span>x<span class="pl-pds">&#39;</span></span> <span class="pl-k">&amp;&amp;</span><span class="pl-sr"> <span class="pl-pds">/</span><span class="pl-c1">\d</span>p<span class="pl-pds">/</span></span>.<span class="pl-c1">test</span>(fullText.<span class="pl-c1">slice</span>(<span class="pl-k">-</span><span class="pl-c1">2</span>))) {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L50">50</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC50">    fullText <span class="pl-k">=</span> fullText.<span class="pl-c1">replace</span>(<span class="pl-sr"><span class="pl-pds">/</span>p<span class="pl-k">$</span><span class="pl-pds">/</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>&lt;span class=&quot;value px&quot;&gt;px&lt;/span&gt;<span class="pl-pds">&#39;</span></span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L51">51</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC51">  } <span class="pl-k">else</span> {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L52">52</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC52">    fullText <span class="pl-k">+=</span> char;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L53">53</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC53">  }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L54">54</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC54">  el.innerHTML <span class="pl-k">=</span> fullText;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L55">55</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC55"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L56">56</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC56">  <span class="pl-c">// Buffer writes to the &lt;style&gt; element so we don&#39;t have to paint quite so much.</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L57">57</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC57">  styleBuffer <span class="pl-k">+=</span> char;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L58">58</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC58">  <span class="pl-k">if</span> (char <span class="pl-k">===</span> <span class="pl-s"><span class="pl-pds">&#39;</span>;<span class="pl-pds">&#39;</span></span>) {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L59">59</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC59">    style.textContent <span class="pl-k">+=</span> styleBuffer;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L60">60</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC60">    styleBuffer <span class="pl-k">=</span> <span class="pl-s"><span class="pl-pds">&#39;</span><span class="pl-pds">&#39;</span></span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L61">61</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC61">  }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L62">62</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC62">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L63">63</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC63"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L64">64</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC64"><span class="pl-k">function</span> <span class="pl-en">writeSimpleChar</span>(<span class="pl-smi">el</span>, <span class="pl-smi">char</span>) {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L65">65</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC65">  el.innerHTML <span class="pl-k">+=</span> char;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L66">66</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC66">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L67">67</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC67"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L68">68</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC68"><span class="pl-k">var</span> endOfSentence <span class="pl-k">=</span><span class="pl-sr"> <span class="pl-pds">/</span><span class="pl-c1">[<span class="pl-cce">\.\?\!</span>]</span><span class="pl-c1">\s</span><span class="pl-k">$</span><span class="pl-pds">/</span></span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L69">69</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC69"><span class="pl-k">var</span> endOfBlock <span class="pl-k">=</span><span class="pl-sr"> <span class="pl-pds">/</span><span class="pl-c1">[<span class="pl-k">^</span><span class="pl-cce">\/</span>]</span><span class="pl-cce">\n\n</span><span class="pl-k">$</span><span class="pl-pds">/</span></span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L70">70</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC70"><span class="pl-k">function</span> <span class="pl-en">writeTo</span>(<span class="pl-smi">el</span>, <span class="pl-smi">message</span>, <span class="pl-smi">index</span>, <span class="pl-smi">interval</span>, <span class="pl-smi">mirrorToStyle</span>, <span class="pl-smi">charsPerInterval</span>, <span class="pl-smi">callback</span>){</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L71">71</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC71">  <span class="pl-k">if</span> (index <span class="pl-k">&lt;</span> message.<span class="pl-c1">length</span>) {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L72">72</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC72"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L73">73</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC73">    <span class="pl-c">// Write a character or multiple characters to the buffer.</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L74">74</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC74">    <span class="pl-k">var</span> chars <span class="pl-k">=</span> message.<span class="pl-c1">slice</span>(index, index <span class="pl-k">+</span> charsPerInterval);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L75">75</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC75">    index <span class="pl-k">+=</span> charsPerInterval;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L76">76</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC76">    el.scrollTop <span class="pl-k">=</span> el.scrollHeight;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L77">77</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC77">    <span class="pl-k">if</span> (mirrorToStyle) {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L78">78</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC78">      writeChar(el, chars);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L79">79</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC79">    } <span class="pl-k">else</span> {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L80">80</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC80">      writeSimpleChar(el, chars);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L81">81</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC81">    }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L82">82</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC82"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L83">83</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC83">    <span class="pl-c">// Schedule another write.</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L84">84</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC84">    <span class="pl-k">var</span> thisInterval <span class="pl-k">=</span> interval;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L85">85</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC85">    <span class="pl-k">var</span> thisSlice <span class="pl-k">=</span> message.<span class="pl-c1">slice</span>(index <span class="pl-k">-</span> <span class="pl-c1">2</span>, index <span class="pl-k">+</span> <span class="pl-c1">1</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L86">86</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC86">    <span class="pl-k">if</span> (<span class="pl-k">!</span>isDev) {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L87">87</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC87">      <span class="pl-k">if</span> (endOfSentence.<span class="pl-c1">test</span>(thisSlice)) thisInterval <span class="pl-k">*=</span> <span class="pl-c1">70</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L88">88</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC88">      <span class="pl-k">if</span> (endOfBlock.<span class="pl-c1">test</span>(thisSlice)) thisInterval <span class="pl-k">*=</span> <span class="pl-c1">50</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L89">89</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC89">    }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L90">90</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC90"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L91">91</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC91">    <span class="pl-c1">setTimeout</span>(<span class="pl-k">function</span>() {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L92">92</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC92">      writeTo(el, message, index, interval, mirrorToStyle, charsPerInterval, callback);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L93">93</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC93">    }, thisInterval);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L94">94</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC94">  } <span class="pl-k">else</span> {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L95">95</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC95">    callback <span class="pl-k">&amp;&amp;</span> callback();</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L96">96</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC96">  }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L97">97</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC97">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L98">98</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC98"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L99">99</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC99"><span class="pl-k">function</span> <span class="pl-en">onStyleElChange</span>(<span class="pl-smi">e</span>) {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L100">100</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC100">  style.textContent <span class="pl-k">=</span> styleEl.textContent;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L101">101</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC101">}</td>
          </tr>
    </table>
  </div>
</div>


        </div>

      </div><!-- /.repo-container -->
      <div class="modal-backdrop"></div>
    </div><!-- /.container -->
  </div><!-- /.site -->


    </div><!-- /.wrapper -->

      <div class="container">
  <div class="site-footer" role="contentinfo">
    <ul class="site-footer-links right">
        <li><a href="https://status.github.com/" data-ga-click="Footer, go to status, text:status">Status</a></li>
      <li><a href="https://developer.github.com" data-ga-click="Footer, go to api, text:api">API</a></li>
      <li><a href="https://training.github.com" data-ga-click="Footer, go to training, text:training">Training</a></li>
      <li><a href="https://shop.github.com" data-ga-click="Footer, go to shop, text:shop">Shop</a></li>
        <li><a href="https://github.com/blog" data-ga-click="Footer, go to blog, text:blog">Blog</a></li>
        <li><a href="https://github.com/about" data-ga-click="Footer, go to about, text:about">About</a></li>

    </ul>

    <a href="https://github.com" aria-label="Homepage">
      <span class="mega-octicon octicon-mark-github" title="GitHub"></span>
</a>
    <ul class="site-footer-links">
      <li>&copy; 2015 <span title="0.05251s from github-fe143-cp1-prd.iad.github.net">GitHub</span>, Inc.</li>
        <li><a href="https://github.com/site/terms" data-ga-click="Footer, go to terms, text:terms">Terms</a></li>
        <li><a href="https://github.com/site/privacy" data-ga-click="Footer, go to privacy, text:privacy">Privacy</a></li>
        <li><a href="https://github.com/security" data-ga-click="Footer, go to security, text:security">Security</a></li>
        <li><a href="https://github.com/contact" data-ga-click="Footer, go to contact, text:contact">Contact</a></li>
    </ul>
  </div>
</div>


    <div class="fullscreen-overlay js-fullscreen-overlay" id="fullscreen_overlay">
  <div class="fullscreen-container js-suggester-container">
    <div class="textarea-wrap">
      <textarea name="fullscreen-contents" id="fullscreen-contents" class="fullscreen-contents js-fullscreen-contents" placeholder=""></textarea>
      <div class="suggester-container">
        <div class="suggester fullscreen-suggester js-suggester js-navigation-container"></div>
      </div>
    </div>
  </div>
  <div class="fullscreen-sidebar">
    <a href="#" class="exit-fullscreen js-exit-fullscreen tooltipped tooltipped-w" aria-label="Exit Zen Mode">
      <span class="mega-octicon octicon-screen-normal"></span>
    </a>
    <a href="#" class="theme-switcher js-theme-switcher tooltipped tooltipped-w"
      aria-label="Switch themes">
      <span class="octicon octicon-color-mode"></span>
    </a>
  </div>
</div>



    

    <div id="ajax-error-message" class="flash flash-error">
      <span class="octicon octicon-alert"></span>
      <a href="#" class="octicon octicon-x flash-close js-ajax-error-dismiss" aria-label="Dismiss error"></a>
      Something went wrong with that request. Please try again.
    </div>


      <script crossorigin="anonymous" src="https://assets-cdn.github.com/assets/frameworks-447ce66a36506ebddc8e84b4e32a77f6062f3d3482e77dd21a77a01f0643ad98.js"></script>
      <script async="async" crossorigin="anonymous" src="https://assets-cdn.github.com/assets/github/index-273626d05f0daba1adb856ea6f9d82ff151f8b9f23a21044a761d2e2f843b354.js"></script>
      
      
  </body>
</html>

