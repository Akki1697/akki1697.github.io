


<!DOCTYPE html>
<html lang="en" class="">
  <head prefix="og: http://ogp.me/ns# fb: http://ogp.me/ns/fb# object: http://ogp.me/ns/object# article: http://ogp.me/ns/article# profile: http://ogp.me/ns/profile#">
    <meta charset='utf-8'>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Language" content="en">
    
    
    <title>strml.net/app.js at b032aabcd97811ab4377eb0af10eee278ba11578 · STRML/strml.net · GitHub</title>
    <link rel="search" type="application/opensearchdescription+xml" href="/opensearch.xml" title="GitHub">
    <link rel="fluid-icon" href="https://github.com/fluidicon.png" title="GitHub">
    <link rel="apple-touch-icon" sizes="57x57" href="/apple-touch-icon-114.png">
    <link rel="apple-touch-icon" sizes="114x114" href="/apple-touch-icon-114.png">
    <link rel="apple-touch-icon" sizes="72x72" href="/apple-touch-icon-144.png">
    <link rel="apple-touch-icon" sizes="144x144" href="/apple-touch-icon-144.png">
    <meta property="fb:app_id" content="1401488693436528">

      <meta content="@github" name="twitter:site" /><meta content="summary" name="twitter:card" /><meta content="STRML/strml.net" name="twitter:title" /><meta content="STRML: Projects &amp;amp; Work. Contribute to strml.net development by creating an account on GitHub." name="twitter:description" /><meta content="https://avatars1.githubusercontent.com/u/1197375?v=3&amp;s=400" name="twitter:image:src" />
      <meta content="GitHub" property="og:site_name" /><meta content="object" property="og:type" /><meta content="https://avatars1.githubusercontent.com/u/1197375?v=3&amp;s=400" property="og:image" /><meta content="STRML/strml.net" property="og:title" /><meta content="https://github.com/STRML/strml.net" property="og:url" /><meta content="STRML: Projects &amp; Work. Contribute to strml.net development by creating an account on GitHub." property="og:description" />
      <meta name="browser-stats-url" content="https://api.github.com/_private/browser/stats">
    <meta name="browser-errors-url" content="https://api.github.com/_private/browser/errors">
    <link rel="assets" href="https://assets-cdn.github.com/">
    
    <meta name="pjax-timeout" content="1000">
    

    <meta name="msapplication-TileImage" content="/windows-tile.png">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="selected-link" value="repo_source" data-pjax-transient>
      <meta name="google-analytics" content="UA-3769691-2">

    <meta content="collector.githubapp.com" name="octolytics-host" /><meta content="collector-cdn.github.com" name="octolytics-script-host" /><meta content="github" name="octolytics-app-id" /><meta content="783D1521:06C4:1709EAA:5571A8BB" name="octolytics-dimension-request_id" />
    
    <meta content="Rails, view, blob#blame" name="analytics-event" />
    <meta class="js-ga-set" name="dimension1" content="Logged Out">
    <meta class="js-ga-set" name="dimension2" content="Header v3">
    <meta name="is-dotcom" content="true">
      <meta name="hostname" content="github.com">
    <meta name="user-login" content="">

    
    <link rel="icon" type="image/x-icon" href="https://assets-cdn.github.com/favicon.ico">


    <meta content="authenticity_token" name="csrf-param" />
<meta content="TaXWeQokaWunVtz/KHsEZ8FL/fr6JZK3Y7m7//Zc1pDsuctYjCMjqJtOvCQif+FF6dLJHd5K3ip4cx+fkoXpxw==" name="csrf-token" />

    <link crossorigin="anonymous" href="https://assets-cdn.github.com/assets/github/index-6967b378b26829cc5a2ea2ad4209ff0af50f2a65057962219dc9dcf8942683f0.css" media="all" rel="stylesheet" />
    <link crossorigin="anonymous" href="https://assets-cdn.github.com/assets/github2/index-73bfe123ff406f4bf8959a28667410beaac1485e71c92d4725a3d7afc45fc4c5.css" media="all" rel="stylesheet" />
    
    


    <meta http-equiv="x-pjax-version" content="b2ca4753a2f40f3bd3d3d6fd0fe8b32e">

            <meta content="noindex, nofollow" name="robots" />

  <meta name="description" content="STRML: Projects &amp; Work. Contribute to strml.net development by creating an account on GitHub.">
  <meta name="go-import" content="github.com/STRML/strml.net git https://github.com/STRML/strml.net.git">

  <meta content="1197375" name="octolytics-dimension-user_id" /><meta content="STRML" name="octolytics-dimension-user_login" /><meta content="33389442" name="octolytics-dimension-repository_id" /><meta content="STRML/strml.net" name="octolytics-dimension-repository_nwo" /><meta content="true" name="octolytics-dimension-repository_public" /><meta content="false" name="octolytics-dimension-repository_is_fork" /><meta content="33389442" name="octolytics-dimension-repository_network_root_id" /><meta content="STRML/strml.net" name="octolytics-dimension-repository_network_root_nwo" />
  <link href="https://github.com/STRML/strml.net/commits/b032aabcd97811ab4377eb0af10eee278ba11578.atom" rel="alternate" title="Recent Commits to strml.net:b032aabcd97811ab4377eb0af10eee278ba11578" type="application/atom+xml">

  </head>


  <body class="logged_out  env-production  vis-public">
    <a href="#start-of-content" tabindex="1" class="accessibility-aid js-skip-to-content">Skip to content</a>
    <div class="wrapper">
      
      
      


        
        <div class="header header-logged-out" role="banner">
  <div class="container clearfix">

    <a class="header-logo-wordmark" href="https://github.com/" data-ga-click="(Logged out) Header, go to homepage, icon:logo-wordmark">
      <span class="mega-octicon octicon-logo-github"></span>
    </a>

    <div class="header-actions" role="navigation">
        <a class="btn btn-primary" href="/join" data-ga-click="(Logged out) Header, clicked Sign up, text:sign-up">Sign up</a>
      <a class="btn" href="/login?return_to=%2FSTRML%2Fstrml.net%2Fblame%2Fb032aabcd97811ab4377eb0af10eee278ba11578%2Fapp.js" data-ga-click="(Logged out) Header, clicked Sign in, text:sign-in">Sign in</a>
    </div>

    <div class="site-search repo-scope js-site-search" role="search">
      <form accept-charset="UTF-8" action="/STRML/strml.net/search" class="js-site-search-form" data-global-search-url="/search" data-repo-search-url="/STRML/strml.net/search" method="get"><div style="margin:0;padding:0;display:inline"><input name="utf8" type="hidden" value="&#x2713;" /></div>
  <label class="js-chromeless-input-container form-control">
    <div class="scope-badge">This repository</div>
    <input type="text"
      class="js-site-search-focus js-site-search-field is-clearable chromeless-input"
      data-hotkey="s"
      name="q"
      placeholder="Search"
      data-global-scope-placeholder="Search GitHub"
      data-repo-scope-placeholder="Search"
      tabindex="1"
      autocapitalize="off">
  </label>
</form>
    </div>

      <ul class="header-nav left" role="navigation">
          <li class="header-nav-item">
            <a class="header-nav-link" href="/explore" data-ga-click="(Logged out) Header, go to explore, text:explore">Explore</a>
          </li>
          <li class="header-nav-item">
            <a class="header-nav-link" href="/features" data-ga-click="(Logged out) Header, go to features, text:features">Features</a>
          </li>
          <li class="header-nav-item">
            <a class="header-nav-link" href="https://enterprise.github.com/" data-ga-click="(Logged out) Header, go to enterprise, text:enterprise">Enterprise</a>
          </li>
          <li class="header-nav-item">
            <a class="header-nav-link" href="/blog" data-ga-click="(Logged out) Header, go to blog, text:blog">Blog</a>
          </li>
      </ul>

  </div>
</div>



      <div id="start-of-content" class="accessibility-aid"></div>
          <div class="site" itemscope itemtype="http://schema.org/WebPage">
    <div id="js-flash-container">
      
    </div>
    <div class="pagehead repohead instapaper_ignore readability-menu">
      <div class="container">

        
<ul class="pagehead-actions">

  <li>
      <a href="/login?return_to=%2FSTRML%2Fstrml.net"
    class="btn btn-sm btn-with-count tooltipped tooltipped-n"
    aria-label="You must be signed in to watch a repository" rel="nofollow">
    <span class="octicon octicon-eye"></span>
    Watch
  </a>
  <a class="social-count" href="/STRML/strml.net/watchers">
    8
  </a>

  </li>

  <li>
      <a href="/login?return_to=%2FSTRML%2Fstrml.net"
    class="btn btn-sm btn-with-count tooltipped tooltipped-n"
    aria-label="You must be signed in to star a repository" rel="nofollow">
    <span class="octicon octicon-star"></span>
    Star
  </a>

    <a class="social-count js-social-count" href="/STRML/strml.net/stargazers">
      160
    </a>

  </li>

    <li>
      <a href="/login?return_to=%2FSTRML%2Fstrml.net"
        class="btn btn-sm btn-with-count tooltipped tooltipped-n"
        aria-label="You must be signed in to fork a repository" rel="nofollow">
        <span class="octicon octicon-repo-forked"></span>
        Fork
      </a>
      <a href="/STRML/strml.net/network" class="social-count">
        43
      </a>
    </li>
</ul>

        <h1 itemscope itemtype="http://data-vocabulary.org/Breadcrumb" class="entry-title public">
          <span class="mega-octicon octicon-repo"></span>
          <span class="author"><a href="/STRML" class="url fn" itemprop="url" rel="author"><span itemprop="title">STRML</span></a></span><!--
       --><span class="path-divider">/</span><!--
       --><strong><a href="/STRML/strml.net" data-pjax="#js-repo-pjax-container">strml.net</a></strong>

          <span class="page-context-loader">
            <img alt="" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </span>

        </h1>
      </div><!-- /.container -->
    </div><!-- /.repohead -->

    <div class="container">
      <div class="repository-with-sidebar repo-container new-discussion-timeline  ">
        <div class="repository-sidebar clearfix">
            
<nav class="sunken-menu repo-nav js-repo-nav js-sidenav-container-pjax js-octicon-loaders"
     role="navigation"
     data-pjax="#js-repo-pjax-container"
     data-issue-count-url="/STRML/strml.net/issues/counts">
  <ul class="sunken-menu-group">
    <li class="tooltipped tooltipped-w" aria-label="Code">
      <a href="/STRML/strml.net" aria-label="Code" class="selected js-selected-navigation-item sunken-menu-item" data-hotkey="g c" data-selected-links="repo_source repo_downloads repo_commits repo_releases repo_tags repo_branches /STRML/strml.net">
        <span class="octicon octicon-code"></span> <span class="full-word">Code</span>
        <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>    </li>

      <li class="tooltipped tooltipped-w" aria-label="Issues">
        <a href="/STRML/strml.net/issues" aria-label="Issues" class="js-selected-navigation-item sunken-menu-item" data-hotkey="g i" data-selected-links="repo_issues repo_labels repo_milestones /STRML/strml.net/issues">
          <span class="octicon octicon-issue-opened"></span> <span class="full-word">Issues</span>
          <span class="js-issue-replace-counter"></span>
          <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>      </li>

    <li class="tooltipped tooltipped-w" aria-label="Pull requests">
      <a href="/STRML/strml.net/pulls" aria-label="Pull requests" class="js-selected-navigation-item sunken-menu-item" data-hotkey="g p" data-selected-links="repo_pulls /STRML/strml.net/pulls">
          <span class="octicon octicon-git-pull-request"></span> <span class="full-word">Pull requests</span>
          <span class="js-pull-replace-counter"></span>
          <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>    </li>

  </ul>
  <div class="sunken-menu-separator"></div>
  <ul class="sunken-menu-group">

    <li class="tooltipped tooltipped-w" aria-label="Pulse">
      <a href="/STRML/strml.net/pulse" aria-label="Pulse" class="js-selected-navigation-item sunken-menu-item" data-selected-links="pulse /STRML/strml.net/pulse">
        <span class="octicon octicon-pulse"></span> <span class="full-word">Pulse</span>
        <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>    </li>

    <li class="tooltipped tooltipped-w" aria-label="Graphs">
      <a href="/STRML/strml.net/graphs" aria-label="Graphs" class="js-selected-navigation-item sunken-menu-item" data-selected-links="repo_graphs repo_contributors /STRML/strml.net/graphs">
        <span class="octicon octicon-graph"></span> <span class="full-word">Graphs</span>
        <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>    </li>
  </ul>


</nav>

              <div class="only-with-full-nav">
                  
<div class="js-clone-url clone-url open"
  data-protocol-type="http">
  <h3><span class="text-emphasized">HTTPS</span> clone URL</h3>
  <div class="input-group js-zeroclipboard-container">
    <input type="text" class="input-mini input-monospace js-url-field js-zeroclipboard-target"
           value="https://github.com/STRML/strml.net.git" readonly="readonly">
    <span class="input-group-button">
      <button aria-label="Copy to clipboard" class="js-zeroclipboard btn btn-sm zeroclipboard-button tooltipped tooltipped-s" data-copied-hint="Copied!" type="button"><span class="octicon octicon-clippy"></span></button>
    </span>
  </div>
</div>

  
<div class="js-clone-url clone-url "
  data-protocol-type="subversion">
  <h3><span class="text-emphasized">Subversion</span> checkout URL</h3>
  <div class="input-group js-zeroclipboard-container">
    <input type="text" class="input-mini input-monospace js-url-field js-zeroclipboard-target"
           value="https://github.com/STRML/strml.net" readonly="readonly">
    <span class="input-group-button">
      <button aria-label="Copy to clipboard" class="js-zeroclipboard btn btn-sm zeroclipboard-button tooltipped tooltipped-s" data-copied-hint="Copied!" type="button"><span class="octicon octicon-clippy"></span></button>
    </span>
  </div>
</div>



<div class="clone-options">You can clone with
  <form accept-charset="UTF-8" action="/users/set_protocol?protocol_selector=http&amp;protocol_type=clone" class="inline-form js-clone-selector-form " data-remote="true" method="post"><div style="margin:0;padding:0;display:inline"><input name="utf8" type="hidden" value="&#x2713;" /><input name="authenticity_token" type="hidden" value="z46H612rWQUbtgFJ2y0gTZ7+PTngCrnf8qEkqgP/fTDCTj9wrD6UIgEQGD4/y00Ni3Y5JDYECp5lyojSiOb03A==" /></div><button class="btn-link js-clone-selector" data-protocol="http" type="submit">HTTPS</button></form> or <form accept-charset="UTF-8" action="/users/set_protocol?protocol_selector=subversion&amp;protocol_type=clone" class="inline-form js-clone-selector-form " data-remote="true" method="post"><div style="margin:0;padding:0;display:inline"><input name="utf8" type="hidden" value="&#x2713;" /><input name="authenticity_token" type="hidden" value="08v1hBTk2hHIVkXeWbhEhtFVhntGPJXkL9ZnvUZGS5PntWkqh93p8it7oLPxrT8t7JhmIIj+t320SRLsCwjABQ==" /></div><button class="btn-link js-clone-selector" data-protocol="subversion" type="submit">Subversion</button></form>.
  <a href="https://help.github.com/articles/which-remote-url-should-i-use" class="help tooltipped tooltipped-n" aria-label="Get help on which URL is right for you.">
    <span class="octicon octicon-question"></span>
  </a>
</div>




                <a href="/STRML/strml.net/archive/b032aabcd97811ab4377eb0af10eee278ba11578.zip"
                   class="btn btn-sm sidebar-button"
                   aria-label="Download the contents of STRML/strml.net as a zip file"
                   title="Download the contents of STRML/strml.net as a zip file"
                   rel="nofollow">
                  <span class="octicon octicon-cloud-download"></span>
                  Download ZIP
                </a>
              </div>
        </div><!-- /.repository-sidebar -->

        <div id="js-repo-pjax-container" class="repository-content context-loader-container" data-pjax-container>

          
<a href="/STRML/strml.net/blame/b032aabcd97811ab4377eb0af10eee278ba11578/app.js" class="hidden js-permalink-shortcut" data-hotkey="y">Permalink</a>

<div class="breadcrumb css-truncate blame-breadcrumb js-zeroclipboard-container">
  <span class="css-truncate-target js-zeroclipboard-target"><span class="repo-root js-repo-root"><span itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb"><a href="/STRML/strml.net/tree/b032aabcd97811ab4377eb0af10eee278ba11578" class="" data-branch="b032aabcd97811ab4377eb0af10eee278ba11578" data-pjax="true" itemscope="url" rel="nofollow"><span itemprop="title">strml.net</span></a></span></span><span class="separator">/</span><strong class="final-path">app.js</strong></span>
  <button aria-label="Copy file path to clipboard" class="js-zeroclipboard btn btn-sm zeroclipboard-button tooltipped tooltipped-s" data-copied-hint="Copied!" type="button"><span class="octicon octicon-clippy"></span></button>
</div>

<div class="line-age-legend">
  <span>Newer</span>
  <ol>
      <li class="heat1"></li>
      <li class="heat2"></li>
      <li class="heat3"></li>
      <li class="heat4"></li>
      <li class="heat5"></li>
      <li class="heat6"></li>
      <li class="heat7"></li>
      <li class="heat8"></li>
      <li class="heat9"></li>
      <li class="heat10"></li>
  </ol>
  <span>Older</span>
</div>

<div class="file">
  <div class="file-header">
    <div class="file-actions">
      <div class="btn-group">
        <a href="/STRML/strml.net/raw/b032aabcd97811ab4377eb0af10eee278ba11578/app.js" class="btn btn-sm" id="raw-url">Raw</a>
        <a href="/STRML/strml.net/blob/b032aabcd97811ab4377eb0af10eee278ba11578/app.js" class="btn btn-sm js-update-url-with-hash">Normal view</a>
        <a href="/STRML/strml.net/commits/b032aabcd97811ab4377eb0af10eee278ba11578/app.js" class="btn btn-sm" rel="nofollow">History</a>
      </div>
    </div>



    <div class="file-info">
      <span class="octicon octicon-file-text"></span>
      <span class="file-mode" title="File Mode">100644</span>
      <span class="file-info-divider"></span>
        167 lines (146 sloc)
        <span class="file-info-divider"></span>
      5.338 kB
    </div>
  </div>

  <div class="blob-wrapper">
    <table class="blame-container highlight data js-file-line-container">
        <tr class="blame-commit">
          <td class="blame-commit-info" rowspan="3">
            <a href="/STRML/strml.net/commit/5aae00b4c56baa8021580f896c2ca292cd28d867" class="blame-sha">5aae00b</a>
            <img alt="@STRML" class="avatar blame-commit-avatar" height="32" src="https://avatars2.githubusercontent.com/u/1197375?v=3&amp;s=64" width="32" />
            <a href="/STRML/strml.net/commit/5aae00b4c56baa8021580f896c2ca292cd28d867" class="blame-commit-title" title="Initial commit.">Initial commit.</a>
            <div class="blame-commit-meta">
              <a href="/STRML" class="muted-link" rel="author">STRML</a> authored
              <time datetime="2015-04-04T00:50:45Z" is="relative-time">Apr 3, 2015</time>
            </div>
          </td>
        </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L1">1</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC1"><span class="pl-s"><span class="pl-pds">&#39;</span>use strict<span class="pl-pds">&#39;</span></span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L2">2</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC2"></td>
          </tr>
        <tr class="blame-commit">
          <td class="blame-commit-info" rowspan="5">
            <a href="/STRML/strml.net/commit/b032aabcd97811ab4377eb0af10eee278ba11578" class="blame-sha">b032aab</a>
            <img alt="@STRML" class="avatar blame-commit-avatar" height="32" src="https://avatars2.githubusercontent.com/u/1197375?v=3&amp;s=64" width="32" />
            <a href="/STRML/strml.net/commit/b032aabcd97811ab4377eb0af10eee278ba11578" class="blame-commit-title" title="Add new steps, refactoring, promises, markdown rendering, and more.">Add new steps, refactoring, promises, markdown rendering, and more.</a>
            <div class="blame-commit-meta">
              <a href="/STRML" class="muted-link" rel="author">STRML</a> authored
              <time datetime="2015-04-04T13:50:34Z" is="relative-time">Apr 4, 2015</time>
            </div>
          </td>
        </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L3">3</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC3"><span class="pl-c1">require</span>(<span class="pl-s"><span class="pl-pds">&#39;</span>classlist-polyfill<span class="pl-pds">&#39;</span></span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L4">4</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC4"><span class="pl-k">var</span> Promise <span class="pl-k">=</span> <span class="pl-c1">require</span>(<span class="pl-s"><span class="pl-pds">&#39;</span>bluebird<span class="pl-pds">&#39;</span></span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L5">5</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC5"><span class="pl-k">var</span> md <span class="pl-k">=</span> <span class="pl-c1">require</span>(<span class="pl-s"><span class="pl-pds">&#39;</span>markdown<span class="pl-pds">&#39;</span></span>).markdown.toHTML;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L6">6</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC6"><span class="pl-k">var</span> workText <span class="pl-k">=</span> <span class="pl-c1">require</span>(<span class="pl-s"><span class="pl-pds">&#39;</span>raw!./work.txt<span class="pl-pds">&#39;</span></span>);</td>
          </tr>
        <tr class="blame-commit">
          <td class="blame-commit-info" rowspan="2">
            <a href="/STRML/strml.net/commit/5aae00b4c56baa8021580f896c2ca292cd28d867" class="blame-sha">5aae00b</a>
            <img alt="@STRML" class="avatar blame-commit-avatar" height="32" src="https://avatars2.githubusercontent.com/u/1197375?v=3&amp;s=64" width="32" />
            <a href="/STRML/strml.net/commit/5aae00b4c56baa8021580f896c2ca292cd28d867" class="blame-commit-title" title="Initial commit.">Initial commit.</a>
            <div class="blame-commit-meta">
              <a href="/STRML" class="muted-link" rel="author">STRML</a> authored
              <time datetime="2015-04-04T00:50:45Z" is="relative-time">Apr 4, 2015</time>
            </div>
          </td>
        </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L7">7</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC7"><span class="pl-k">var</span> pgpText <span class="pl-k">=</span> <span class="pl-c1">require</span>(<span class="pl-s"><span class="pl-pds">&#39;</span>raw!./pgp.txt<span class="pl-pds">&#39;</span></span>);</td>
          </tr>
        <tr class="blame-commit">
          <td class="blame-commit-info" rowspan="2">
            <a href="/STRML/strml.net/commit/b032aabcd97811ab4377eb0af10eee278ba11578" class="blame-sha">b032aab</a>
            <img alt="@STRML" class="avatar blame-commit-avatar" height="32" src="https://avatars2.githubusercontent.com/u/1197375?v=3&amp;s=64" width="32" />
            <a href="/STRML/strml.net/commit/b032aabcd97811ab4377eb0af10eee278ba11578" class="blame-commit-title" title="Add new steps, refactoring, promises, markdown rendering, and more.">Add new steps, refactoring, promises, markdown rendering, and more.</a>
            <div class="blame-commit-meta">
              <a href="/STRML" class="muted-link" rel="author">STRML</a> authored
              <time datetime="2015-04-04T13:50:34Z" is="relative-time">Apr 4, 2015</time>
            </div>
          </td>
        </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L8">8</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC8"><span class="pl-k">var</span> styleText <span class="pl-k">=</span> [<span class="pl-c1">0</span>,<span class="pl-c1">1</span>,<span class="pl-c1">2</span>,<span class="pl-c1">3</span>].map(<span class="pl-k">function</span>(<span class="pl-smi">i</span>) { <span class="pl-k">return</span> <span class="pl-c1">require</span>(<span class="pl-s"><span class="pl-pds">&#39;</span>raw!./styles<span class="pl-pds">&#39;</span></span> <span class="pl-k">+</span> i <span class="pl-k">+</span> <span class="pl-s"><span class="pl-pds">&#39;</span>.css<span class="pl-pds">&#39;</span></span>); });</td>
          </tr>
        <tr class="blame-commit">
          <td class="blame-commit-info" rowspan="2">
            <a href="/STRML/strml.net/commit/256d0144f99e13b74cbfe27e8071ed62270ae7dd" class="blame-sha">256d014</a>
            <img alt="@STRML" class="avatar blame-commit-avatar" height="32" src="https://avatars2.githubusercontent.com/u/1197375?v=3&amp;s=64" width="32" />
            <a href="/STRML/strml.net/commit/256d0144f99e13b74cbfe27e8071ed62270ae7dd" class="blame-commit-title" title="Autoreplace urls in data.txt and some text tweaks">Autoreplace urls in data.txt and some text tweaks</a>
            <div class="blame-commit-meta">
              <a href="/STRML" class="muted-link" rel="author">STRML</a> authored
              <time datetime="2015-04-04T01:17:24Z" is="relative-time">Apr 3, 2015</time>
            </div>
          </td>
        </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L9">9</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC9"><span class="pl-k">var</span> replaceURLs <span class="pl-k">=</span> <span class="pl-c1">require</span>(<span class="pl-s"><span class="pl-pds">&#39;</span>./lib/replaceURLs<span class="pl-pds">&#39;</span></span>);</td>
          </tr>
        <tr class="blame-commit">
          <td class="blame-commit-info" rowspan="2">
            <a href="/STRML/strml.net/commit/5aae00b4c56baa8021580f896c2ca292cd28d867" class="blame-sha">5aae00b</a>
            <img alt="@STRML" class="avatar blame-commit-avatar" height="32" src="https://avatars2.githubusercontent.com/u/1197375?v=3&amp;s=64" width="32" />
            <a href="/STRML/strml.net/commit/5aae00b4c56baa8021580f896c2ca292cd28d867" class="blame-commit-title" title="Initial commit.">Initial commit.</a>
            <div class="blame-commit-meta">
              <a href="/STRML" class="muted-link" rel="author">STRML</a> authored
              <time datetime="2015-04-04T00:50:45Z" is="relative-time">Apr 4, 2015</time>
            </div>
          </td>
        </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L10">10</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC10"></td>
          </tr>
        <tr class="blame-commit">
          <td class="blame-commit-info" rowspan="6">
            <a href="/STRML/strml.net/commit/b032aabcd97811ab4377eb0af10eee278ba11578" class="blame-sha">b032aab</a>
            <img alt="@STRML" class="avatar blame-commit-avatar" height="32" src="https://avatars2.githubusercontent.com/u/1197375?v=3&amp;s=64" width="32" />
            <a href="/STRML/strml.net/commit/b032aabcd97811ab4377eb0af10eee278ba11578" class="blame-commit-title" title="Add new steps, refactoring, promises, markdown rendering, and more.">Add new steps, refactoring, promises, markdown rendering, and more.</a>
            <div class="blame-commit-meta">
              <a href="/STRML" class="muted-link" rel="author">STRML</a> authored
              <time datetime="2015-04-04T13:50:34Z" is="relative-time">Apr 4, 2015</time>
            </div>
          </td>
        </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L11">11</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC11"><span class="pl-c">// Ghetto per-browser prefixing</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L12">12</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC12"><span class="pl-k">var</span> prefix <span class="pl-k">=</span> <span class="pl-c1">require</span>(<span class="pl-s"><span class="pl-pds">&#39;</span>./lib/getPrefix<span class="pl-pds">&#39;</span></span>)();</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L13">13</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC13">styleText <span class="pl-k">=</span> styleText.map(<span class="pl-k">function</span>(<span class="pl-smi">text</span>) {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L14">14</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC14">  <span class="pl-k">return</span> text.<span class="pl-c1">replace</span>(<span class="pl-sr"><span class="pl-pds">/</span>-webkit-<span class="pl-pds">/</span>g</span>, prefix);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L15">15</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC15">});</td>
          </tr>
        <tr class="blame-commit">
          <td class="blame-commit-info" rowspan="2">
            <a href="/STRML/strml.net/commit/5aae00b4c56baa8021580f896c2ca292cd28d867" class="blame-sha">5aae00b</a>
            <img alt="@STRML" class="avatar blame-commit-avatar" height="32" src="https://avatars2.githubusercontent.com/u/1197375?v=3&amp;s=64" width="32" />
            <a href="/STRML/strml.net/commit/5aae00b4c56baa8021580f896c2ca292cd28d867" class="blame-commit-title" title="Initial commit.">Initial commit.</a>
            <div class="blame-commit-meta">
              <a href="/STRML" class="muted-link" rel="author">STRML</a> authored
              <time datetime="2015-04-04T00:50:45Z" is="relative-time">Apr 4, 2015</time>
            </div>
          </td>
        </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L16">16</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC16"></td>
          </tr>
        <tr class="blame-commit">
          <td class="blame-commit-info" rowspan="3">
            <a href="/STRML/strml.net/commit/b032aabcd97811ab4377eb0af10eee278ba11578" class="blame-sha">b032aab</a>
            <img alt="@STRML" class="avatar blame-commit-avatar" height="32" src="https://avatars2.githubusercontent.com/u/1197375?v=3&amp;s=64" width="32" />
            <a href="/STRML/strml.net/commit/b032aabcd97811ab4377eb0af10eee278ba11578" class="blame-commit-title" title="Add new steps, refactoring, promises, markdown rendering, and more.">Add new steps, refactoring, promises, markdown rendering, and more.</a>
            <div class="blame-commit-meta">
              <a href="/STRML" class="muted-link" rel="author">STRML</a> authored
              <time datetime="2015-04-04T13:50:34Z" is="relative-time">Apr 4, 2015</time>
            </div>
          </td>
        </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L17">17</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC17"><span class="pl-c">// Wait for load to get started.</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L18">18</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC18"><span class="pl-c1">document</span>.addEventListener(<span class="pl-s"><span class="pl-pds">&quot;</span>DOMContentLoaded<span class="pl-pds">&quot;</span></span>, doWork);</td>
          </tr>
        <tr class="blame-commit">
          <td class="blame-commit-info" rowspan="2">
            <a href="/STRML/strml.net/commit/5aae00b4c56baa8021580f896c2ca292cd28d867" class="blame-sha">5aae00b</a>
            <img alt="@STRML" class="avatar blame-commit-avatar" height="32" src="https://avatars2.githubusercontent.com/u/1197375?v=3&amp;s=64" width="32" />
            <a href="/STRML/strml.net/commit/5aae00b4c56baa8021580f896c2ca292cd28d867" class="blame-commit-title" title="Initial commit.">Initial commit.</a>
            <div class="blame-commit-meta">
              <a href="/STRML" class="muted-link" rel="author">STRML</a> authored
              <time datetime="2015-04-04T00:50:45Z" is="relative-time">Apr 4, 2015</time>
            </div>
          </td>
        </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L19">19</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC19"></td>
          </tr>
        <tr class="blame-commit">
          <td class="blame-commit-info" rowspan="5">
            <a href="/STRML/strml.net/commit/b032aabcd97811ab4377eb0af10eee278ba11578" class="blame-sha">b032aab</a>
            <img alt="@STRML" class="avatar blame-commit-avatar" height="32" src="https://avatars2.githubusercontent.com/u/1197375?v=3&amp;s=64" width="32" />
            <a href="/STRML/strml.net/commit/b032aabcd97811ab4377eb0af10eee278ba11578" class="blame-commit-title" title="Add new steps, refactoring, promises, markdown rendering, and more.">Add new steps, refactoring, promises, markdown rendering, and more.</a>
            <div class="blame-commit-meta">
              <a href="/STRML" class="muted-link" rel="author">STRML</a> authored
              <time datetime="2015-04-04T13:50:34Z" is="relative-time">Apr 4, 2015</time>
            </div>
          </td>
        </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L20">20</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC20"><span class="pl-c">// Vars that will help us get er done</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L21">21</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC21"><span class="pl-k">var</span> isDev <span class="pl-k">=</span> <span class="pl-c1">window</span>.<span class="pl-c1">location</span>.<span class="pl-c1">hostname</span> <span class="pl-k">===</span> <span class="pl-s"><span class="pl-pds">&#39;</span>localhost<span class="pl-pds">&#39;</span></span> <span class="pl-k">&amp;&amp;</span> <span class="pl-c1">false</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L22">22</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC22"><span class="pl-k">var</span> speed <span class="pl-k">=</span> isDev <span class="pl-k">?</span> <span class="pl-c1">0</span> <span class="pl-k">:</span> <span class="pl-c1">16</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L23">23</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC23"><span class="pl-k">var</span> style, styleEl, workEl, pgpEl;</td>
          </tr>
        <tr class="blame-commit">
          <td class="blame-commit-info" rowspan="4">
            <a href="/STRML/strml.net/commit/5aae00b4c56baa8021580f896c2ca292cd28d867" class="blame-sha">5aae00b</a>
            <img alt="@STRML" class="avatar blame-commit-avatar" height="32" src="https://avatars2.githubusercontent.com/u/1197375?v=3&amp;s=64" width="32" />
            <a href="/STRML/strml.net/commit/5aae00b4c56baa8021580f896c2ca292cd28d867" class="blame-commit-title" title="Initial commit.">Initial commit.</a>
            <div class="blame-commit-meta">
              <a href="/STRML" class="muted-link" rel="author">STRML</a> authored
              <time datetime="2015-04-04T00:50:45Z" is="relative-time">Apr 4, 2015</time>
            </div>
          </td>
        </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L24">24</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC24"><span class="pl-k">function</span> <span class="pl-en">doWork</span>(){</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L25">25</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC25">  style <span class="pl-k">=</span> <span class="pl-c1">document</span>.<span class="pl-c1">getElementById</span>(<span class="pl-s"><span class="pl-pds">&#39;</span>style-tag<span class="pl-pds">&#39;</span></span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L26">26</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC26">  styleEl <span class="pl-k">=</span> <span class="pl-c1">document</span>.<span class="pl-c1">getElementById</span>(<span class="pl-s"><span class="pl-pds">&#39;</span>style-text<span class="pl-pds">&#39;</span></span>);</td>
          </tr>
        <tr class="blame-commit">
          <td class="blame-commit-info" rowspan="2">
            <a href="/STRML/strml.net/commit/b032aabcd97811ab4377eb0af10eee278ba11578" class="blame-sha">b032aab</a>
            <img alt="@STRML" class="avatar blame-commit-avatar" height="32" src="https://avatars2.githubusercontent.com/u/1197375?v=3&amp;s=64" width="32" />
            <a href="/STRML/strml.net/commit/b032aabcd97811ab4377eb0af10eee278ba11578" class="blame-commit-title" title="Add new steps, refactoring, promises, markdown rendering, and more.">Add new steps, refactoring, promises, markdown rendering, and more.</a>
            <div class="blame-commit-meta">
              <a href="/STRML" class="muted-link" rel="author">STRML</a> authored
              <time datetime="2015-04-04T13:50:34Z" is="relative-time">Apr 4, 2015</time>
            </div>
          </td>
        </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L27">27</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC27">  workEl <span class="pl-k">=</span> <span class="pl-c1">document</span>.<span class="pl-c1">getElementById</span>(<span class="pl-s"><span class="pl-pds">&#39;</span>work-text<span class="pl-pds">&#39;</span></span>);</td>
          </tr>
        <tr class="blame-commit">
          <td class="blame-commit-info" rowspan="3">
            <a href="/STRML/strml.net/commit/5aae00b4c56baa8021580f896c2ca292cd28d867" class="blame-sha">5aae00b</a>
            <img alt="@STRML" class="avatar blame-commit-avatar" height="32" src="https://avatars2.githubusercontent.com/u/1197375?v=3&amp;s=64" width="32" />
            <a href="/STRML/strml.net/commit/5aae00b4c56baa8021580f896c2ca292cd28d867" class="blame-commit-title" title="Initial commit.">Initial commit.</a>
            <div class="blame-commit-meta">
              <a href="/STRML" class="muted-link" rel="author">STRML</a> authored
              <time datetime="2015-04-04T00:50:45Z" is="relative-time">Apr 4, 2015</time>
            </div>
          </td>
        </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L28">28</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC28">  pgpEl <span class="pl-k">=</span> <span class="pl-c1">document</span>.<span class="pl-c1">getElementById</span>(<span class="pl-s"><span class="pl-pds">&#39;</span>pgp-text<span class="pl-pds">&#39;</span></span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L29">29</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC29"></td>
          </tr>
        <tr class="blame-commit">
          <td class="blame-commit-info" rowspan="5">
            <a href="/STRML/strml.net/commit/256d0144f99e13b74cbfe27e8071ed62270ae7dd" class="blame-sha">256d014</a>
            <img alt="@STRML" class="avatar blame-commit-avatar" height="32" src="https://avatars2.githubusercontent.com/u/1197375?v=3&amp;s=64" width="32" />
            <a href="/STRML/strml.net/commit/256d0144f99e13b74cbfe27e8071ed62270ae7dd" class="blame-commit-title" title="Autoreplace urls in data.txt and some text tweaks">Autoreplace urls in data.txt and some text tweaks</a>
            <div class="blame-commit-meta">
              <a href="/STRML" class="muted-link" rel="author">STRML</a> authored
              <time datetime="2015-04-04T01:17:24Z" is="relative-time">Apr 4, 2015</time>
            </div>
          </td>
        </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L30">30</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC30">  <span class="pl-c">// Mirror user edits back to the style element.</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L31">31</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC31">  styleEl.addEventListener(<span class="pl-s"><span class="pl-pds">&#39;</span>input<span class="pl-pds">&#39;</span></span>, <span class="pl-k">function</span>() {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L32">32</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC32">    style.textContent <span class="pl-k">=</span> styleEl.textContent;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L33">33</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC33">  });</td>
          </tr>
        <tr class="blame-commit">
          <td class="blame-commit-info" rowspan="2">
            <a href="/STRML/strml.net/commit/5aae00b4c56baa8021580f896c2ca292cd28d867" class="blame-sha">5aae00b</a>
            <img alt="@STRML" class="avatar blame-commit-avatar" height="32" src="https://avatars2.githubusercontent.com/u/1197375?v=3&amp;s=64" width="32" />
            <a href="/STRML/strml.net/commit/5aae00b4c56baa8021580f896c2ca292cd28d867" class="blame-commit-title" title="Initial commit.">Initial commit.</a>
            <div class="blame-commit-meta">
              <a href="/STRML" class="muted-link" rel="author">STRML</a> authored
              <time datetime="2015-04-04T00:50:45Z" is="relative-time">Apr 4, 2015</time>
            </div>
          </td>
        </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L34">34</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC34"></td>
          </tr>
        <tr class="blame-commit">
          <td class="blame-commit-info" rowspan="14">
            <a href="/STRML/strml.net/commit/b032aabcd97811ab4377eb0af10eee278ba11578" class="blame-sha">b032aab</a>
            <img alt="@STRML" class="avatar blame-commit-avatar" height="32" src="https://avatars2.githubusercontent.com/u/1197375?v=3&amp;s=64" width="32" />
            <a href="/STRML/strml.net/commit/b032aabcd97811ab4377eb0af10eee278ba11578" class="blame-commit-title" title="Add new steps, refactoring, promises, markdown rendering, and more.">Add new steps, refactoring, promises, markdown rendering, and more.</a>
            <div class="blame-commit-meta">
              <a href="/STRML" class="muted-link" rel="author">STRML</a> authored
              <time datetime="2015-04-04T13:50:34Z" is="relative-time">Apr 4, 2015</time>
            </div>
          </td>
        </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L35">35</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC35">  <span class="pl-k">if</span> (<span class="pl-k">!</span>isDev) {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L36">36</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC36">    writeTo(styleEl, styleText[<span class="pl-c1">0</span>], <span class="pl-c1">0</span>, speed, <span class="pl-c1">true</span>, <span class="pl-c1">1</span>)()</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L37">37</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC37">    .then(writeTo(workEl, workText, <span class="pl-c1">0</span>, speed, <span class="pl-c1">false</span>, <span class="pl-c1">1</span>))</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L38">38</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC38">    .then(writeTo(styleEl, styleText[<span class="pl-c1">1</span>], <span class="pl-c1">0</span>, speed, <span class="pl-c1">true</span>, <span class="pl-c1">1</span>))</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L39">39</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC39">    .then(setWorkListener)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L40">40</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC40">    .delay(<span class="pl-c1">500</span>)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L41">41</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC41">    .then(writeTo(styleEl, styleText[<span class="pl-c1">2</span>], <span class="pl-c1">0</span>, speed, <span class="pl-c1">true</span>, <span class="pl-c1">1</span>))</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L42">42</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC42">    .then(writeTo(pgpEl, pgpText, <span class="pl-c1">0</span>, speed, <span class="pl-c1">false</span>, <span class="pl-c1">16</span>))</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L43">43</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC43">    .then(writeTo(styleEl, styleText[<span class="pl-c1">3</span>], <span class="pl-c1">0</span>, speed, <span class="pl-c1">true</span>, <span class="pl-c1">1</span>));</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L44">44</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC44">  } <span class="pl-k">else</span> {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L45">45</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC45">    styleText.forEach(<span class="pl-k">function</span>(<span class="pl-smi">text</span>) {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L46">46</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC46">      styleEl.innerHTML <span class="pl-k">+=</span> text;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L47">47</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC47">      style.textContent <span class="pl-k">+=</span> text;</td>
          </tr>
        <tr class="blame-commit">
          <td class="blame-commit-info" rowspan="2">
            <a href="/STRML/strml.net/commit/5aae00b4c56baa8021580f896c2ca292cd28d867" class="blame-sha">5aae00b</a>
            <img alt="@STRML" class="avatar blame-commit-avatar" height="32" src="https://avatars2.githubusercontent.com/u/1197375?v=3&amp;s=64" width="32" />
            <a href="/STRML/strml.net/commit/5aae00b4c56baa8021580f896c2ca292cd28d867" class="blame-commit-title" title="Initial commit.">Initial commit.</a>
            <div class="blame-commit-meta">
              <a href="/STRML" class="muted-link" rel="author">STRML</a> authored
              <time datetime="2015-04-04T00:50:45Z" is="relative-time">Apr 4, 2015</time>
            </div>
          </td>
        </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L48">48</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC48">    });</td>
          </tr>
        <tr class="blame-commit">
          <td class="blame-commit-info" rowspan="4">
            <a href="/STRML/strml.net/commit/b032aabcd97811ab4377eb0af10eee278ba11578" class="blame-sha">b032aab</a>
            <img alt="@STRML" class="avatar blame-commit-avatar" height="32" src="https://avatars2.githubusercontent.com/u/1197375?v=3&amp;s=64" width="32" />
            <a href="/STRML/strml.net/commit/b032aabcd97811ab4377eb0af10eee278ba11578" class="blame-commit-title" title="Add new steps, refactoring, promises, markdown rendering, and more.">Add new steps, refactoring, promises, markdown rendering, and more.</a>
            <div class="blame-commit-meta">
              <a href="/STRML" class="muted-link" rel="author">STRML</a> authored
              <time datetime="2015-04-04T13:50:34Z" is="relative-time">Apr 4, 2015</time>
            </div>
          </td>
        </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L49">49</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC49">    setWorkListener();</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L50">50</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC50">    pgpEl.innerHTML <span class="pl-k">=</span> pgpText;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L51">51</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC51">  }</td>
          </tr>
        <tr class="blame-commit">
          <td class="blame-commit-info" rowspan="3">
            <a href="/STRML/strml.net/commit/5aae00b4c56baa8021580f896c2ca292cd28d867" class="blame-sha">5aae00b</a>
            <img alt="@STRML" class="avatar blame-commit-avatar" height="32" src="https://avatars2.githubusercontent.com/u/1197375?v=3&amp;s=64" width="32" />
            <a href="/STRML/strml.net/commit/5aae00b4c56baa8021580f896c2ca292cd28d867" class="blame-commit-title" title="Initial commit.">Initial commit.</a>
            <div class="blame-commit-meta">
              <a href="/STRML" class="muted-link" rel="author">STRML</a> authored
              <time datetime="2015-04-04T00:50:45Z" is="relative-time">Apr 4, 2015</time>
            </div>
          </td>
        </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L52">52</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC52">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L53">53</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC53"></td>
          </tr>
        <tr class="blame-commit">
          <td class="blame-commit-info" rowspan="9">
            <a href="/STRML/strml.net/commit/b032aabcd97811ab4377eb0af10eee278ba11578" class="blame-sha">b032aab</a>
            <img alt="@STRML" class="avatar blame-commit-avatar" height="32" src="https://avatars2.githubusercontent.com/u/1197375?v=3&amp;s=64" width="32" />
            <a href="/STRML/strml.net/commit/b032aabcd97811ab4377eb0af10eee278ba11578" class="blame-commit-title" title="Add new steps, refactoring, promises, markdown rendering, and more.">Add new steps, refactoring, promises, markdown rendering, and more.</a>
            <div class="blame-commit-meta">
              <a href="/STRML" class="muted-link" rel="author">STRML</a> authored
              <time datetime="2015-04-04T13:50:34Z" is="relative-time">Apr 4, 2015</time>
            </div>
          </td>
        </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L54">54</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC54"><span class="pl-c">/**</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L55">55</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC55"><span class="pl-c"> * Helpers</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L56">56</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC56"><span class="pl-c"> */</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L57">57</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC57"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L58">58</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC58"><span class="pl-c">//</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L59">59</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC59"><span class="pl-c">// Writing to boxes</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L60">60</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC60"><span class="pl-c">//</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L61">61</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC61"></td>
          </tr>
        <tr class="blame-commit">
          <td class="blame-commit-info" rowspan="2">
            <a href="/STRML/strml.net/commit/256d0144f99e13b74cbfe27e8071ed62270ae7dd" class="blame-sha">256d014</a>
            <img alt="@STRML" class="avatar blame-commit-avatar" height="32" src="https://avatars2.githubusercontent.com/u/1197375?v=3&amp;s=64" width="32" />
            <a href="/STRML/strml.net/commit/256d0144f99e13b74cbfe27e8071ed62270ae7dd" class="blame-commit-title" title="Autoreplace urls in data.txt and some text tweaks">Autoreplace urls in data.txt and some text tweaks</a>
            <div class="blame-commit-meta">
              <a href="/STRML" class="muted-link" rel="author">STRML</a> authored
              <time datetime="2015-04-04T01:17:24Z" is="relative-time">Apr 4, 2015</time>
            </div>
          </td>
        </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L62">62</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC62"><span class="pl-k">var</span> openComment <span class="pl-k">=</span> <span class="pl-c1">false</span>;</td>
          </tr>
        <tr class="blame-commit">
          <td class="blame-commit-info" rowspan="39">
            <a href="/STRML/strml.net/commit/5aae00b4c56baa8021580f896c2ca292cd28d867" class="blame-sha">5aae00b</a>
            <img alt="@STRML" class="avatar blame-commit-avatar" height="32" src="https://avatars2.githubusercontent.com/u/1197375?v=3&amp;s=64" width="32" />
            <a href="/STRML/strml.net/commit/5aae00b4c56baa8021580f896c2ca292cd28d867" class="blame-commit-title" title="Initial commit.">Initial commit.</a>
            <div class="blame-commit-meta">
              <a href="/STRML" class="muted-link" rel="author">STRML</a> authored
              <time datetime="2015-04-04T00:50:45Z" is="relative-time">Apr 4, 2015</time>
            </div>
          </td>
        </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L63">63</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC63"><span class="pl-k">var</span> styleBuffer <span class="pl-k">=</span> <span class="pl-s"><span class="pl-pds">&#39;</span><span class="pl-pds">&#39;</span></span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L64">64</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC64"><span class="pl-k">function</span> <span class="pl-en">writeChar</span>(<span class="pl-smi">el</span>, <span class="pl-smi">char</span>){</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L65">65</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC65">  <span class="pl-k">var</span> fullText <span class="pl-k">=</span> el.innerHTML;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L66">66</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC66">  <span class="pl-k">if</span> (char <span class="pl-k">===</span> <span class="pl-s"><span class="pl-pds">&#39;</span>/<span class="pl-pds">&#39;</span></span> <span class="pl-k">&amp;&amp;</span> openComment <span class="pl-k">===</span> <span class="pl-c1">false</span>) {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L67">67</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC67">    openComment <span class="pl-k">=</span> <span class="pl-c1">true</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L68">68</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC68">    fullText <span class="pl-k">+=</span> char;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L69">69</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC69">  } <span class="pl-k">else</span> <span class="pl-k">if</span> (char <span class="pl-k">===</span> <span class="pl-s"><span class="pl-pds">&#39;</span>/<span class="pl-pds">&#39;</span></span> <span class="pl-k">&amp;&amp;</span> fullText.<span class="pl-c1">slice</span>(<span class="pl-k">-</span><span class="pl-c1">1</span>) <span class="pl-k">===</span> <span class="pl-s"><span class="pl-pds">&#39;</span>*<span class="pl-pds">&#39;</span></span> <span class="pl-k">&amp;&amp;</span> openComment <span class="pl-k">===</span> <span class="pl-c1">true</span>) {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L70">70</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC70">    openComment <span class="pl-k">=</span> <span class="pl-c1">false</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L71">71</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC71">    <span class="pl-c">// Unfortunately we can&#39;t just open a span and close it, because the browser will helpfully</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L72">72</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC72">    <span class="pl-c">// &#39;fix&#39; it for us, and we&#39;ll end up with a single-character span and an empty closing tag.</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L73">73</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC73">    fullText <span class="pl-k">=</span> fullText.<span class="pl-c1">replace</span>(<span class="pl-sr"><span class="pl-pds">/</span>(<span class="pl-cce">\/\*</span>(?:<span class="pl-c1">[<span class="pl-k">^</span>]</span>(?!<span class="pl-cce">\/\*</span>))<span class="pl-k">*</span><span class="pl-cce">\*</span>)<span class="pl-k">$</span><span class="pl-pds">/</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>&lt;span class=&quot;comment&quot;&gt;$1/&lt;/span&gt;<span class="pl-pds">&#39;</span></span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L74">74</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC74">  } <span class="pl-k">else</span> <span class="pl-k">if</span> (char <span class="pl-k">===</span> <span class="pl-s"><span class="pl-pds">&#39;</span>:<span class="pl-pds">&#39;</span></span>) {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L75">75</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC75">    fullText <span class="pl-k">=</span> fullText.<span class="pl-c1">replace</span>(<span class="pl-sr"><span class="pl-pds">/</span>(<span class="pl-c1">[<span class="pl-c1">a-zA-Z</span>- ^<span class="pl-cce">\n</span>]</span><span class="pl-k">*</span>)<span class="pl-k">$</span><span class="pl-pds">/</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>&lt;span class=&quot;key&quot;&gt;$1&lt;/span&gt;:<span class="pl-pds">&#39;</span></span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L76">76</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC76">  } <span class="pl-k">else</span> <span class="pl-k">if</span> (char <span class="pl-k">===</span> <span class="pl-s"><span class="pl-pds">&#39;</span>;<span class="pl-pds">&#39;</span></span>) {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L77">77</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC77">    fullText <span class="pl-k">=</span> fullText.<span class="pl-c1">replace</span>(<span class="pl-sr"><span class="pl-pds">/</span>(<span class="pl-c1">[<span class="pl-k">^</span>:]</span><span class="pl-k">*</span>)<span class="pl-k">$</span><span class="pl-pds">/</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>&lt;span class=&quot;value&quot;&gt;$1&lt;/span&gt;;<span class="pl-pds">&#39;</span></span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L78">78</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC78">  } <span class="pl-k">else</span> <span class="pl-k">if</span> (char <span class="pl-k">===</span> <span class="pl-s"><span class="pl-pds">&#39;</span>{<span class="pl-pds">&#39;</span></span>) {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L79">79</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC79">    fullText <span class="pl-k">=</span> fullText.<span class="pl-c1">replace</span>(<span class="pl-sr"><span class="pl-pds">/</span>(<span class="pl-c1">.</span><span class="pl-k">*</span>)<span class="pl-k">$</span><span class="pl-pds">/</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>&lt;span class=&quot;selector&quot;&gt;$1&lt;/span&gt;{<span class="pl-pds">&#39;</span></span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L80">80</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC80">  } <span class="pl-k">else</span> <span class="pl-k">if</span> (char <span class="pl-k">===</span> <span class="pl-s"><span class="pl-pds">&#39;</span>x<span class="pl-pds">&#39;</span></span> <span class="pl-k">&amp;&amp;</span><span class="pl-sr"> <span class="pl-pds">/</span><span class="pl-c1">\d</span>p<span class="pl-pds">/</span></span>.<span class="pl-c1">test</span>(fullText.<span class="pl-c1">slice</span>(<span class="pl-k">-</span><span class="pl-c1">2</span>))) {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L81">81</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC81">    fullText <span class="pl-k">=</span> fullText.<span class="pl-c1">replace</span>(<span class="pl-sr"><span class="pl-pds">/</span>p<span class="pl-k">$</span><span class="pl-pds">/</span></span>, <span class="pl-s"><span class="pl-pds">&#39;</span>&lt;span class=&quot;value px&quot;&gt;px&lt;/span&gt;<span class="pl-pds">&#39;</span></span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L82">82</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC82">  } <span class="pl-k">else</span> {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L83">83</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC83">    fullText <span class="pl-k">+=</span> char;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L84">84</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC84">  }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L85">85</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC85">  el.innerHTML <span class="pl-k">=</span> fullText;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L86">86</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC86"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L87">87</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC87">  <span class="pl-c">// Buffer writes to the &lt;style&gt; element so we don&#39;t have to paint quite so much.</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L88">88</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC88">  styleBuffer <span class="pl-k">+=</span> char;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L89">89</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC89">  <span class="pl-k">if</span> (char <span class="pl-k">===</span> <span class="pl-s"><span class="pl-pds">&#39;</span>;<span class="pl-pds">&#39;</span></span>) {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L90">90</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC90">    style.textContent <span class="pl-k">+=</span> styleBuffer;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L91">91</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC91">    styleBuffer <span class="pl-k">=</span> <span class="pl-s"><span class="pl-pds">&#39;</span><span class="pl-pds">&#39;</span></span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L92">92</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC92">  }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L93">93</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC93">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L94">94</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC94"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L95">95</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC95"><span class="pl-k">function</span> <span class="pl-en">writeSimpleChar</span>(<span class="pl-smi">el</span>, <span class="pl-smi">char</span>) {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L96">96</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC96">  el.innerHTML <span class="pl-k">+=</span> char;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L97">97</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC97">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L98">98</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC98"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L99">99</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC99"><span class="pl-k">var</span> endOfSentence <span class="pl-k">=</span><span class="pl-sr"> <span class="pl-pds">/</span><span class="pl-c1">[<span class="pl-cce">\.\?\!</span>]</span><span class="pl-c1">\s</span><span class="pl-k">$</span><span class="pl-pds">/</span></span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L100">100</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC100"><span class="pl-k">var</span> endOfBlock <span class="pl-k">=</span><span class="pl-sr"> <span class="pl-pds">/</span><span class="pl-c1">[<span class="pl-k">^</span><span class="pl-cce">\/</span>]</span><span class="pl-cce">\n\n</span><span class="pl-k">$</span><span class="pl-pds">/</span></span>;</td>
          </tr>
        <tr class="blame-commit">
          <td class="blame-commit-info" rowspan="7">
            <a href="/STRML/strml.net/commit/b032aabcd97811ab4377eb0af10eee278ba11578" class="blame-sha">b032aab</a>
            <img alt="@STRML" class="avatar blame-commit-avatar" height="32" src="https://avatars2.githubusercontent.com/u/1197375?v=3&amp;s=64" width="32" />
            <a href="/STRML/strml.net/commit/b032aabcd97811ab4377eb0af10eee278ba11578" class="blame-commit-title" title="Add new steps, refactoring, promises, markdown rendering, and more.">Add new steps, refactoring, promises, markdown rendering, and more.</a>
            <div class="blame-commit-meta">
              <a href="/STRML" class="muted-link" rel="author">STRML</a> authored
              <time datetime="2015-04-04T13:50:34Z" is="relative-time">Apr 4, 2015</time>
            </div>
          </td>
        </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L101">101</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC101"><span class="pl-k">function</span> <span class="pl-en">writeTo</span>(<span class="pl-smi">el</span>, <span class="pl-smi">message</span>, <span class="pl-smi">index</span>, <span class="pl-smi">interval</span>, <span class="pl-smi">mirrorToStyle</span>, <span class="pl-smi">charsPerInterval</span>){</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L102">102</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC102">  <span class="pl-k">return</span> <span class="pl-k">function</span>() {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L103">103</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC103">    <span class="pl-k">return</span> Promise.try(<span class="pl-k">function</span>() {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L104">104</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC104">      <span class="pl-c">// Write a character or multiple characters to the buffer.</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L105">105</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC105">      <span class="pl-k">var</span> chars <span class="pl-k">=</span> message.<span class="pl-c1">slice</span>(index, index <span class="pl-k">+</span> charsPerInterval);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L106">106</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC106">      index <span class="pl-k">+=</span> charsPerInterval;</td>
          </tr>
        <tr class="blame-commit">
          <td class="blame-commit-info" rowspan="2">
            <a href="/STRML/strml.net/commit/5aae00b4c56baa8021580f896c2ca292cd28d867" class="blame-sha">5aae00b</a>
            <img alt="@STRML" class="avatar blame-commit-avatar" height="32" src="https://avatars2.githubusercontent.com/u/1197375?v=3&amp;s=64" width="32" />
            <a href="/STRML/strml.net/commit/5aae00b4c56baa8021580f896c2ca292cd28d867" class="blame-commit-title" title="Initial commit.">Initial commit.</a>
            <div class="blame-commit-meta">
              <a href="/STRML" class="muted-link" rel="author">STRML</a> authored
              <time datetime="2015-04-04T00:50:45Z" is="relative-time">Apr 4, 2015</time>
            </div>
          </td>
        </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L107">107</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC107"></td>
          </tr>
        <tr class="blame-commit">
          <td class="blame-commit-info" rowspan="3">
            <a href="/STRML/strml.net/commit/b032aabcd97811ab4377eb0af10eee278ba11578" class="blame-sha">b032aab</a>
            <img alt="@STRML" class="avatar blame-commit-avatar" height="32" src="https://avatars2.githubusercontent.com/u/1197375?v=3&amp;s=64" width="32" />
            <a href="/STRML/strml.net/commit/b032aabcd97811ab4377eb0af10eee278ba11578" class="blame-commit-title" title="Add new steps, refactoring, promises, markdown rendering, and more.">Add new steps, refactoring, promises, markdown rendering, and more.</a>
            <div class="blame-commit-meta">
              <a href="/STRML" class="muted-link" rel="author">STRML</a> authored
              <time datetime="2015-04-04T13:50:34Z" is="relative-time">Apr 4, 2015</time>
            </div>
          </td>
        </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L108">108</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC108">      <span class="pl-c">// Ensure we stay scrolled to the bottom.</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L109">109</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC109">      el.scrollTop <span class="pl-k">=</span> el.scrollHeight;</td>
          </tr>
        <tr class="blame-commit">
          <td class="blame-commit-info" rowspan="2">
            <a href="/STRML/strml.net/commit/256d0144f99e13b74cbfe27e8071ed62270ae7dd" class="blame-sha">256d014</a>
            <img alt="@STRML" class="avatar blame-commit-avatar" height="32" src="https://avatars2.githubusercontent.com/u/1197375?v=3&amp;s=64" width="32" />
            <a href="/STRML/strml.net/commit/256d0144f99e13b74cbfe27e8071ed62270ae7dd" class="blame-commit-title" title="Autoreplace urls in data.txt and some text tweaks">Autoreplace urls in data.txt and some text tweaks</a>
            <div class="blame-commit-meta">
              <a href="/STRML" class="muted-link" rel="author">STRML</a> authored
              <time datetime="2015-04-04T01:17:24Z" is="relative-time">Apr 4, 2015</time>
            </div>
          </td>
        </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L110">110</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC110"></td>
          </tr>
        <tr class="blame-commit">
          <td class="blame-commit-info" rowspan="17">
            <a href="/STRML/strml.net/commit/b032aabcd97811ab4377eb0af10eee278ba11578" class="blame-sha">b032aab</a>
            <img alt="@STRML" class="avatar blame-commit-avatar" height="32" src="https://avatars2.githubusercontent.com/u/1197375?v=3&amp;s=64" width="32" />
            <a href="/STRML/strml.net/commit/b032aabcd97811ab4377eb0af10eee278ba11578" class="blame-commit-title" title="Add new steps, refactoring, promises, markdown rendering, and more.">Add new steps, refactoring, promises, markdown rendering, and more.</a>
            <div class="blame-commit-meta">
              <a href="/STRML" class="muted-link" rel="author">STRML</a> authored
              <time datetime="2015-04-04T13:50:34Z" is="relative-time">Apr 4, 2015</time>
            </div>
          </td>
        </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L111">111</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC111">      <span class="pl-c">// If this is going to &lt;style&gt; it&#39;s more complex; otherwise, just write.</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L112">112</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC112">      <span class="pl-k">if</span> (mirrorToStyle) {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L113">113</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC113">        writeChar(el, chars);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L114">114</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC114">      } <span class="pl-k">else</span> {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L115">115</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC115">        writeSimpleChar(el, chars);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L116">116</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC116">      }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L117">117</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC117">    })</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L118">118</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC118">    .then(<span class="pl-k">function</span>() {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L119">119</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC119">      <span class="pl-k">if</span> (index <span class="pl-k">&lt;</span> message.<span class="pl-c1">length</span>) {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L120">120</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC120">        <span class="pl-c">// Schedule another write.</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L121">121</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC121">        <span class="pl-k">var</span> thisInterval <span class="pl-k">=</span> interval;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L122">122</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC122">        <span class="pl-k">var</span> thisSlice <span class="pl-k">=</span> message.<span class="pl-c1">slice</span>(index <span class="pl-k">-</span> <span class="pl-c1">2</span>, index <span class="pl-k">+</span> <span class="pl-c1">1</span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L123">123</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC123">        <span class="pl-k">if</span> (<span class="pl-k">!</span>isDev) {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L124">124</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC124">          <span class="pl-k">if</span> (endOfSentence.<span class="pl-c1">test</span>(thisSlice)) thisInterval <span class="pl-k">*=</span> <span class="pl-c1">70</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L125">125</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC125">          <span class="pl-k">if</span> (endOfBlock.<span class="pl-c1">test</span>(thisSlice)) thisInterval <span class="pl-k">*=</span> <span class="pl-c1">50</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L126">126</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC126">        }</td>
          </tr>
        <tr class="blame-commit">
          <td class="blame-commit-info" rowspan="2">
            <a href="/STRML/strml.net/commit/256d0144f99e13b74cbfe27e8071ed62270ae7dd" class="blame-sha">256d014</a>
            <img alt="@STRML" class="avatar blame-commit-avatar" height="32" src="https://avatars2.githubusercontent.com/u/1197375?v=3&amp;s=64" width="32" />
            <a href="/STRML/strml.net/commit/256d0144f99e13b74cbfe27e8071ed62270ae7dd" class="blame-commit-title" title="Autoreplace urls in data.txt and some text tweaks">Autoreplace urls in data.txt and some text tweaks</a>
            <div class="blame-commit-meta">
              <a href="/STRML" class="muted-link" rel="author">STRML</a> authored
              <time datetime="2015-04-04T01:17:24Z" is="relative-time">Apr 4, 2015</time>
            </div>
          </td>
        </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L127">127</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC127"></td>
          </tr>
        <tr class="blame-commit">
          <td class="blame-commit-info" rowspan="14">
            <a href="/STRML/strml.net/commit/b032aabcd97811ab4377eb0af10eee278ba11578" class="blame-sha">b032aab</a>
            <img alt="@STRML" class="avatar blame-commit-avatar" height="32" src="https://avatars2.githubusercontent.com/u/1197375?v=3&amp;s=64" width="32" />
            <a href="/STRML/strml.net/commit/b032aabcd97811ab4377eb0af10eee278ba11578" class="blame-commit-title" title="Add new steps, refactoring, promises, markdown rendering, and more.">Add new steps, refactoring, promises, markdown rendering, and more.</a>
            <div class="blame-commit-meta">
              <a href="/STRML" class="muted-link" rel="author">STRML</a> authored
              <time datetime="2015-04-04T13:50:34Z" is="relative-time">Apr 4, 2015</time>
            </div>
          </td>
        </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L128">128</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC128">        <span class="pl-k">return</span> Promise.delay(thisInterval)</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L129">129</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC129">        .then(writeTo(el, message, index, interval, mirrorToStyle, charsPerInterval));</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L130">130</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC130">      }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L131">131</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC131">    });</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L132">132</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC132">  };</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L133">133</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC133">}</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L134">134</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC134"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L135">135</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC135"><span class="pl-c">//</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L136">136</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC136"><span class="pl-c">// Fire a listener when scrolling the &#39;work&#39; box.</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L137">137</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC137"><span class="pl-c">//</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L138">138</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC138"><span class="pl-k">function</span> <span class="pl-en">setWorkListener</span>() {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L139">139</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC139">  workEl.innerHTML <span class="pl-k">=</span> <span class="pl-s"><span class="pl-pds">&#39;</span>&lt;div class=&quot;text&quot;&gt;<span class="pl-pds">&#39;</span></span> <span class="pl-k">+</span> replaceURLs(workText) <span class="pl-k">+</span> <span class="pl-s"><span class="pl-pds">&#39;</span>&lt;/div&gt;<span class="pl-pds">&#39;</span></span> <span class="pl-k">+</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L140">140</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC140">                     <span class="pl-s"><span class="pl-pds">&#39;</span>&lt;div class=&quot;md&quot;&gt;<span class="pl-pds">&#39;</span></span> <span class="pl-k">+</span> replaceURLs(md(workText)) <span class="pl-k">+</span> <span class="pl-s"><span class="pl-pds">&#39;</span>&lt;div&gt;<span class="pl-pds">&#39;</span></span>;</td>
          </tr>
        <tr class="blame-commit">
          <td class="blame-commit-info" rowspan="2">
            <a href="/STRML/strml.net/commit/5aae00b4c56baa8021580f896c2ca292cd28d867" class="blame-sha">5aae00b</a>
            <img alt="@STRML" class="avatar blame-commit-avatar" height="32" src="https://avatars2.githubusercontent.com/u/1197375?v=3&amp;s=64" width="32" />
            <a href="/STRML/strml.net/commit/5aae00b4c56baa8021580f896c2ca292cd28d867" class="blame-commit-title" title="Initial commit.">Initial commit.</a>
            <div class="blame-commit-meta">
              <a href="/STRML" class="muted-link" rel="author">STRML</a> authored
              <time datetime="2015-04-04T00:50:45Z" is="relative-time">Apr 4, 2015</time>
            </div>
          </td>
        </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L141">141</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC141"></td>
          </tr>
        <tr class="blame-commit">
          <td class="blame-commit-info" rowspan="20">
            <a href="/STRML/strml.net/commit/b032aabcd97811ab4377eb0af10eee278ba11578" class="blame-sha">b032aab</a>
            <img alt="@STRML" class="avatar blame-commit-avatar" height="32" src="https://avatars2.githubusercontent.com/u/1197375?v=3&amp;s=64" width="32" />
            <a href="/STRML/strml.net/commit/b032aabcd97811ab4377eb0af10eee278ba11578" class="blame-commit-title" title="Add new steps, refactoring, promises, markdown rendering, and more.">Add new steps, refactoring, promises, markdown rendering, and more.</a>
            <div class="blame-commit-meta">
              <a href="/STRML" class="muted-link" rel="author">STRML</a> authored
              <time datetime="2015-04-04T13:50:34Z" is="relative-time">Apr 4, 2015</time>
            </div>
          </td>
        </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L142">142</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC142">  workEl.classList.<span class="pl-c1">add</span>(<span class="pl-s"><span class="pl-pds">&#39;</span>flipped<span class="pl-pds">&#39;</span></span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L143">143</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC143">  workEl.scrollTop <span class="pl-k">=</span> <span class="pl-c1">9999</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L144">144</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC144"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L145">145</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC145">  <span class="pl-c">// flippy floppy</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L146">146</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC146">  <span class="pl-k">var</span> flipping <span class="pl-k">=</span> <span class="pl-c1">0</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L147">147</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC147">  <span class="pl-c1">require</span>(<span class="pl-s"><span class="pl-pds">&#39;</span>mouse-wheel<span class="pl-pds">&#39;</span></span>)(workEl, <span class="pl-k">function</span>(<span class="pl-smi">dx</span>, <span class="pl-smi">dy</span>) {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L148">148</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC148">    <span class="pl-k">if</span> (flipping) <span class="pl-k">return</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L149">149</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC149">    <span class="pl-k">var</span> flipped <span class="pl-k">=</span> workEl.classList.contains(<span class="pl-s"><span class="pl-pds">&#39;</span>flipped<span class="pl-pds">&#39;</span></span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L150">150</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC150">    <span class="pl-k">var</span> half <span class="pl-k">=</span> (workEl.scrollHeight <span class="pl-k">-</span> workEl.clientHeight) / <span class="pl-c1">2</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L151">151</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC151">    <span class="pl-k">var</span> pastHalf <span class="pl-k">=</span> flipped <span class="pl-k">?</span> workEl.scrollTop <span class="pl-k">&lt;</span> half <span class="pl-k">:</span> workEl.scrollTop <span class="pl-k">&gt;</span> half;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L152">152</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC152"></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L153">153</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC153">    <span class="pl-c">// If we&#39;re past half, flip the el.</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L154">154</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC154">    <span class="pl-k">if</span> (pastHalf) {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L155">155</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC155">      workEl.classList.toggle(<span class="pl-s"><span class="pl-pds">&#39;</span>flipped<span class="pl-pds">&#39;</span></span>);</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L156">156</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC156">      flipping <span class="pl-k">=</span> <span class="pl-c1">true</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L157">157</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC157">      <span class="pl-c1">setTimeout</span>(<span class="pl-k">function</span>() {</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L158">158</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC158">        workEl.scrollTop <span class="pl-k">=</span> flipped <span class="pl-k">?</span> <span class="pl-c1">0</span> <span class="pl-k">:</span> <span class="pl-c1">9999</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L159">159</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC159">        flipping <span class="pl-k">=</span> <span class="pl-c1">false</span>;</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L160">160</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC160">      }, <span class="pl-c1">250</span>);</td>
          </tr>
        <tr class="blame-commit">
          <td class="blame-commit-info" rowspan="3">
            <a href="/STRML/strml.net/commit/5aae00b4c56baa8021580f896c2ca292cd28d867" class="blame-sha">5aae00b</a>
            <img alt="@STRML" class="avatar blame-commit-avatar" height="32" src="https://avatars2.githubusercontent.com/u/1197375?v=3&amp;s=64" width="32" />
            <a href="/STRML/strml.net/commit/5aae00b4c56baa8021580f896c2ca292cd28d867" class="blame-commit-title" title="Initial commit.">Initial commit.</a>
            <div class="blame-commit-meta">
              <a href="/STRML" class="muted-link" rel="author">STRML</a> authored
              <time datetime="2015-04-04T00:50:45Z" is="relative-time">Apr 4, 2015</time>
            </div>
          </td>
        </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L161">161</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC161">    }</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L162">162</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC162"></td>
          </tr>
        <tr class="blame-commit">
          <td class="blame-commit-info" rowspan="4">
            <a href="/STRML/strml.net/commit/b032aabcd97811ab4377eb0af10eee278ba11578" class="blame-sha">b032aab</a>
            <img alt="@STRML" class="avatar blame-commit-avatar" height="32" src="https://avatars2.githubusercontent.com/u/1197375?v=3&amp;s=64" width="32" />
            <a href="/STRML/strml.net/commit/b032aabcd97811ab4377eb0af10eee278ba11578" class="blame-commit-title" title="Add new steps, refactoring, promises, markdown rendering, and more.">Add new steps, refactoring, promises, markdown rendering, and more.</a>
            <div class="blame-commit-meta">
              <a href="/STRML" class="muted-link" rel="author">STRML</a> authored
              <time datetime="2015-04-04T13:50:34Z" is="relative-time">Apr 4, 2015</time>
            </div>
          </td>
        </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L163">163</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC163">    <span class="pl-c">// Scroll. If we&#39;ve flipped, flip the scroll direction.</span></td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L164">164</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC164">    workEl.scrollTop <span class="pl-k">+=</span> (dy <span class="pl-k">*</span> (flipped <span class="pl-k">?</span> <span class="pl-k">-</span><span class="pl-c1">1</span> <span class="pl-k">:</span> <span class="pl-c1">1</span>));</td>
          </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L165">165</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC165">  }, <span class="pl-c1">true</span>);</td>
          </tr>
        <tr class="blame-commit">
          <td class="blame-commit-info" rowspan="2">
            <a href="/STRML/strml.net/commit/5aae00b4c56baa8021580f896c2ca292cd28d867" class="blame-sha">5aae00b</a>
            <img alt="@STRML" class="avatar blame-commit-avatar" height="32" src="https://avatars2.githubusercontent.com/u/1197375?v=3&amp;s=64" width="32" />
            <a href="/STRML/strml.net/commit/5aae00b4c56baa8021580f896c2ca292cd28d867" class="blame-commit-title" title="Initial commit.">Initial commit.</a>
            <div class="blame-commit-meta">
              <a href="/STRML" class="muted-link" rel="author">STRML</a> authored
              <time datetime="2015-04-04T00:50:45Z" is="relative-time">Apr 4, 2015</time>
            </div>
          </td>
        </tr>
          <tr class="blame-line">
            <td class="line-age heat10"></td>
            <td class="blob-num blame-blob-num js-line-number" id="L166">166</td>
            <td class="blob-code blob-code-inner js-file-line" id="LC166">}</td>
          </tr>
    </table>
  </div>
</div>


        </div>

      </div><!-- /.repo-container -->
      <div class="modal-backdrop"></div>
    </div><!-- /.container -->
  </div><!-- /.site -->


    </div><!-- /.wrapper -->

      <div class="container">
  <div class="site-footer" role="contentinfo">
    <ul class="site-footer-links right">
        <li><a href="https://status.github.com/" data-ga-click="Footer, go to status, text:status">Status</a></li>
      <li><a href="https://developer.github.com" data-ga-click="Footer, go to api, text:api">API</a></li>
      <li><a href="https://training.github.com" data-ga-click="Footer, go to training, text:training">Training</a></li>
      <li><a href="https://shop.github.com" data-ga-click="Footer, go to shop, text:shop">Shop</a></li>
        <li><a href="https://github.com/blog" data-ga-click="Footer, go to blog, text:blog">Blog</a></li>
        <li><a href="https://github.com/about" data-ga-click="Footer, go to about, text:about">About</a></li>

    </ul>

    <a href="https://github.com" aria-label="Homepage">
      <span class="mega-octicon octicon-mark-github" title="GitHub"></span>
</a>
    <ul class="site-footer-links">
      <li>&copy; 2015 <span title="0.06479s from github-fe140-cp1-prd.iad.github.net">GitHub</span>, Inc.</li>
        <li><a href="https://github.com/site/terms" data-ga-click="Footer, go to terms, text:terms">Terms</a></li>
        <li><a href="https://github.com/site/privacy" data-ga-click="Footer, go to privacy, text:privacy">Privacy</a></li>
        <li><a href="https://github.com/security" data-ga-click="Footer, go to security, text:security">Security</a></li>
        <li><a href="https://github.com/contact" data-ga-click="Footer, go to contact, text:contact">Contact</a></li>
    </ul>
  </div>
</div>


    <div class="fullscreen-overlay js-fullscreen-overlay" id="fullscreen_overlay">
  <div class="fullscreen-container js-suggester-container">
    <div class="textarea-wrap">
      <textarea name="fullscreen-contents" id="fullscreen-contents" class="fullscreen-contents js-fullscreen-contents" placeholder=""></textarea>
      <div class="suggester-container">
        <div class="suggester fullscreen-suggester js-suggester js-navigation-container"></div>
      </div>
    </div>
  </div>
  <div class="fullscreen-sidebar">
    <a href="#" class="exit-fullscreen js-exit-fullscreen tooltipped tooltipped-w" aria-label="Exit Zen Mode">
      <span class="mega-octicon octicon-screen-normal"></span>
    </a>
    <a href="#" class="theme-switcher js-theme-switcher tooltipped tooltipped-w"
      aria-label="Switch themes">
      <span class="octicon octicon-color-mode"></span>
    </a>
  </div>
</div>



    

    <div id="ajax-error-message" class="flash flash-error">
      <span class="octicon octicon-alert"></span>
      <a href="#" class="octicon octicon-x flash-close js-ajax-error-dismiss" aria-label="Dismiss error"></a>
      Something went wrong with that request. Please try again.
    </div>


      <script crossorigin="anonymous" src="https://assets-cdn.github.com/assets/frameworks-447ce66a36506ebddc8e84b4e32a77f6062f3d3482e77dd21a77a01f0643ad98.js"></script>
      <script async="async" crossorigin="anonymous" src="https://assets-cdn.github.com/assets/github/index-273626d05f0daba1adb856ea6f9d82ff151f8b9f23a21044a761d2e2f843b354.js"></script>
      
      
  </body>
</html>

