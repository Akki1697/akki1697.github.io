


<!DOCTYPE html>
<html lang="en" class="">
  <head prefix="og: http://ogp.me/ns# fb: http://ogp.me/ns/fb# object: http://ogp.me/ns/object# article: http://ogp.me/ns/article# profile: http://ogp.me/ns/profile#">
    <meta charset='utf-8'>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Language" content="en">
    
    
    <title>History for app.js - STRML/strml.net · GitHub</title>
    <link rel="search" type="application/opensearchdescription+xml" href="/opensearch.xml" title="GitHub">
    <link rel="fluid-icon" href="https://github.com/fluidicon.png" title="GitHub">
    <link rel="apple-touch-icon" sizes="57x57" href="/apple-touch-icon-114.png">
    <link rel="apple-touch-icon" sizes="114x114" href="/apple-touch-icon-114.png">
    <link rel="apple-touch-icon" sizes="72x72" href="/apple-touch-icon-144.png">
    <link rel="apple-touch-icon" sizes="144x144" href="/apple-touch-icon-144.png">
    <meta property="fb:app_id" content="1401488693436528">

      <meta content="@github" name="twitter:site" /><meta content="summary" name="twitter:card" /><meta content="STRML/strml.net" name="twitter:title" /><meta content="STRML: Projects &amp;amp; Work. Contribute to strml.net development by creating an account on GitHub." name="twitter:description" /><meta content="https://avatars1.githubusercontent.com/u/1197375?v=3&amp;s=400" name="twitter:image:src" />
      <meta content="GitHub" property="og:site_name" /><meta content="object" property="og:type" /><meta content="https://avatars1.githubusercontent.com/u/1197375?v=3&amp;s=400" property="og:image" /><meta content="STRML/strml.net" property="og:title" /><meta content="https://github.com/STRML/strml.net" property="og:url" /><meta content="STRML: Projects &amp; Work. Contribute to strml.net development by creating an account on GitHub." property="og:description" />
      <meta name="browser-stats-url" content="https://api.github.com/_private/browser/stats">
    <meta name="browser-errors-url" content="https://api.github.com/_private/browser/errors">
    <link rel="assets" href="https://assets-cdn.github.com/">
    
    <meta name="pjax-timeout" content="1000">
    

    <meta name="msapplication-TileImage" content="/windows-tile.png">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="selected-link" value="repo_source" data-pjax-transient>
      <meta name="google-analytics" content="UA-3769691-2">

    <meta content="collector.githubapp.com" name="octolytics-host" /><meta content="collector-cdn.github.com" name="octolytics-script-host" /><meta content="github" name="octolytics-app-id" /><meta content="783D1521:06C0:CE75A0:5571A893" name="octolytics-dimension-request_id" />
    
    <meta content="Rails, view, commits#show" name="analytics-event" />
    <meta class="js-ga-set" name="dimension1" content="Logged Out">
    <meta class="js-ga-set" name="dimension2" content="Header v3">
    <meta name="is-dotcom" content="true">
      <meta name="hostname" content="github.com">
    <meta name="user-login" content="">

    
    <link rel="icon" type="image/x-icon" href="https://assets-cdn.github.com/favicon.ico">


    <meta content="authenticity_token" name="csrf-param" />
<meta content="+AzW7JuOiXu1enxZmlR1MpQmQSDKddFmm46SrXrQLrGfb5a6CbAzl8xn5i574tWLOshQHFc/0MEIthWNAGYkzg==" name="csrf-token" />

    <link crossorigin="anonymous" href="https://assets-cdn.github.com/assets/github/index-6967b378b26829cc5a2ea2ad4209ff0af50f2a65057962219dc9dcf8942683f0.css" media="all" rel="stylesheet" />
    <link crossorigin="anonymous" href="https://assets-cdn.github.com/assets/github2/index-73bfe123ff406f4bf8959a28667410beaac1485e71c92d4725a3d7afc45fc4c5.css" media="all" rel="stylesheet" />
    
    


    <meta http-equiv="x-pjax-version" content="b2ca4753a2f40f3bd3d3d6fd0fe8b32e">

            <meta content="noindex, nofollow" name="robots" />

  <meta name="description" content="STRML: Projects &amp; Work. Contribute to strml.net development by creating an account on GitHub.">
  <meta name="go-import" content="github.com/STRML/strml.net git https://github.com/STRML/strml.net.git">

  <meta content="1197375" name="octolytics-dimension-user_id" /><meta content="STRML" name="octolytics-dimension-user_login" /><meta content="33389442" name="octolytics-dimension-repository_id" /><meta content="STRML/strml.net" name="octolytics-dimension-repository_nwo" /><meta content="true" name="octolytics-dimension-repository_public" /><meta content="false" name="octolytics-dimension-repository_is_fork" /><meta content="33389442" name="octolytics-dimension-repository_network_root_id" /><meta content="STRML/strml.net" name="octolytics-dimension-repository_network_root_nwo" />
  <link href="https://github.com/STRML/strml.net/commits/50b1cf37dfaffebaafe00e2417a2d4e32da732d2.atom" rel="alternate" title="Recent Commits to strml.net:50b1cf37dfaffebaafe00e2417a2d4e32da732d2" type="application/atom+xml">

  </head>


  <body class="logged_out  env-production  vis-public">
    <a href="#start-of-content" tabindex="1" class="accessibility-aid js-skip-to-content">Skip to content</a>
    <div class="wrapper">
      
      
      


        
        <div class="header header-logged-out" role="banner">
  <div class="container clearfix">

    <a class="header-logo-wordmark" href="https://github.com/" data-ga-click="(Logged out) Header, go to homepage, icon:logo-wordmark">
      <span class="mega-octicon octicon-logo-github"></span>
    </a>

    <div class="header-actions" role="navigation">
        <a class="btn btn-primary" href="/join" data-ga-click="(Logged out) Header, clicked Sign up, text:sign-up">Sign up</a>
      <a class="btn" href="/login?return_to=%2FSTRML%2Fstrml.net%2Fcommits%2F50b1cf37dfaffebaafe00e2417a2d4e32da732d2%2Fapp.js" data-ga-click="(Logged out) Header, clicked Sign in, text:sign-in">Sign in</a>
    </div>

    <div class="site-search repo-scope js-site-search" role="search">
      <form accept-charset="UTF-8" action="/STRML/strml.net/search" class="js-site-search-form" data-global-search-url="/search" data-repo-search-url="/STRML/strml.net/search" method="get"><div style="margin:0;padding:0;display:inline"><input name="utf8" type="hidden" value="&#x2713;" /></div>
  <label class="js-chromeless-input-container form-control">
    <div class="scope-badge">This repository</div>
    <input type="text"
      class="js-site-search-focus js-site-search-field is-clearable chromeless-input"
      data-hotkey="s"
      name="q"
      placeholder="Search"
      data-global-scope-placeholder="Search GitHub"
      data-repo-scope-placeholder="Search"
      tabindex="1"
      autocapitalize="off">
  </label>
</form>
    </div>

      <ul class="header-nav left" role="navigation">
          <li class="header-nav-item">
            <a class="header-nav-link" href="/explore" data-ga-click="(Logged out) Header, go to explore, text:explore">Explore</a>
          </li>
          <li class="header-nav-item">
            <a class="header-nav-link" href="/features" data-ga-click="(Logged out) Header, go to features, text:features">Features</a>
          </li>
          <li class="header-nav-item">
            <a class="header-nav-link" href="https://enterprise.github.com/" data-ga-click="(Logged out) Header, go to enterprise, text:enterprise">Enterprise</a>
          </li>
          <li class="header-nav-item">
            <a class="header-nav-link" href="/blog" data-ga-click="(Logged out) Header, go to blog, text:blog">Blog</a>
          </li>
      </ul>

  </div>
</div>



      <div id="start-of-content" class="accessibility-aid"></div>
          <div class="site" itemscope itemtype="http://schema.org/WebPage">
    <div id="js-flash-container">
      
    </div>
    <div class="pagehead repohead instapaper_ignore readability-menu">
      <div class="container">

        
<ul class="pagehead-actions">

  <li>
      <a href="/login?return_to=%2FSTRML%2Fstrml.net"
    class="btn btn-sm btn-with-count tooltipped tooltipped-n"
    aria-label="You must be signed in to watch a repository" rel="nofollow">
    <span class="octicon octicon-eye"></span>
    Watch
  </a>
  <a class="social-count" href="/STRML/strml.net/watchers">
    8
  </a>

  </li>

  <li>
      <a href="/login?return_to=%2FSTRML%2Fstrml.net"
    class="btn btn-sm btn-with-count tooltipped tooltipped-n"
    aria-label="You must be signed in to star a repository" rel="nofollow">
    <span class="octicon octicon-star"></span>
    Star
  </a>

    <a class="social-count js-social-count" href="/STRML/strml.net/stargazers">
      160
    </a>

  </li>

    <li>
      <a href="/login?return_to=%2FSTRML%2Fstrml.net"
        class="btn btn-sm btn-with-count tooltipped tooltipped-n"
        aria-label="You must be signed in to fork a repository" rel="nofollow">
        <span class="octicon octicon-repo-forked"></span>
        Fork
      </a>
      <a href="/STRML/strml.net/network" class="social-count">
        43
      </a>
    </li>
</ul>

        <h1 itemscope itemtype="http://data-vocabulary.org/Breadcrumb" class="entry-title public">
          <span class="mega-octicon octicon-repo"></span>
          <span class="author"><a href="/STRML" class="url fn" itemprop="url" rel="author"><span itemprop="title">STRML</span></a></span><!--
       --><span class="path-divider">/</span><!--
       --><strong><a href="/STRML/strml.net" data-pjax="#js-repo-pjax-container">strml.net</a></strong>

          <span class="page-context-loader">
            <img alt="" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </span>

        </h1>
      </div><!-- /.container -->
    </div><!-- /.repohead -->

    <div class="container">
      <div class="repository-with-sidebar repo-container new-discussion-timeline  ">
        <div class="repository-sidebar clearfix">
            
<nav class="sunken-menu repo-nav js-repo-nav js-sidenav-container-pjax js-octicon-loaders"
     role="navigation"
     data-pjax="#js-repo-pjax-container"
     data-issue-count-url="/STRML/strml.net/issues/counts">
  <ul class="sunken-menu-group">
    <li class="tooltipped tooltipped-w" aria-label="Code">
      <a href="/STRML/strml.net" aria-label="Code" class="selected js-selected-navigation-item sunken-menu-item" data-hotkey="g c" data-selected-links="repo_source repo_downloads repo_commits repo_releases repo_tags repo_branches /STRML/strml.net">
        <span class="octicon octicon-code"></span> <span class="full-word">Code</span>
        <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>    </li>

      <li class="tooltipped tooltipped-w" aria-label="Issues">
        <a href="/STRML/strml.net/issues" aria-label="Issues" class="js-selected-navigation-item sunken-menu-item" data-hotkey="g i" data-selected-links="repo_issues repo_labels repo_milestones /STRML/strml.net/issues">
          <span class="octicon octicon-issue-opened"></span> <span class="full-word">Issues</span>
          <span class="js-issue-replace-counter"></span>
          <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>      </li>

    <li class="tooltipped tooltipped-w" aria-label="Pull requests">
      <a href="/STRML/strml.net/pulls" aria-label="Pull requests" class="js-selected-navigation-item sunken-menu-item" data-hotkey="g p" data-selected-links="repo_pulls /STRML/strml.net/pulls">
          <span class="octicon octicon-git-pull-request"></span> <span class="full-word">Pull requests</span>
          <span class="js-pull-replace-counter"></span>
          <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>    </li>

  </ul>
  <div class="sunken-menu-separator"></div>
  <ul class="sunken-menu-group">

    <li class="tooltipped tooltipped-w" aria-label="Pulse">
      <a href="/STRML/strml.net/pulse" aria-label="Pulse" class="js-selected-navigation-item sunken-menu-item" data-selected-links="pulse /STRML/strml.net/pulse">
        <span class="octicon octicon-pulse"></span> <span class="full-word">Pulse</span>
        <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>    </li>

    <li class="tooltipped tooltipped-w" aria-label="Graphs">
      <a href="/STRML/strml.net/graphs" aria-label="Graphs" class="js-selected-navigation-item sunken-menu-item" data-selected-links="repo_graphs repo_contributors /STRML/strml.net/graphs">
        <span class="octicon octicon-graph"></span> <span class="full-word">Graphs</span>
        <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>    </li>
  </ul>


</nav>

              <div class="only-with-full-nav">
                  
<div class="js-clone-url clone-url open"
  data-protocol-type="http">
  <h3><span class="text-emphasized">HTTPS</span> clone URL</h3>
  <div class="input-group js-zeroclipboard-container">
    <input type="text" class="input-mini input-monospace js-url-field js-zeroclipboard-target"
           value="https://github.com/STRML/strml.net.git" readonly="readonly">
    <span class="input-group-button">
      <button aria-label="Copy to clipboard" class="js-zeroclipboard btn btn-sm zeroclipboard-button tooltipped tooltipped-s" data-copied-hint="Copied!" type="button"><span class="octicon octicon-clippy"></span></button>
    </span>
  </div>
</div>

  
<div class="js-clone-url clone-url "
  data-protocol-type="subversion">
  <h3><span class="text-emphasized">Subversion</span> checkout URL</h3>
  <div class="input-group js-zeroclipboard-container">
    <input type="text" class="input-mini input-monospace js-url-field js-zeroclipboard-target"
           value="https://github.com/STRML/strml.net" readonly="readonly">
    <span class="input-group-button">
      <button aria-label="Copy to clipboard" class="js-zeroclipboard btn btn-sm zeroclipboard-button tooltipped tooltipped-s" data-copied-hint="Copied!" type="button"><span class="octicon octicon-clippy"></span></button>
    </span>
  </div>
</div>



<div class="clone-options">You can clone with
  <form accept-charset="UTF-8" action="/users/set_protocol?protocol_selector=http&amp;protocol_type=clone" class="inline-form js-clone-selector-form " data-remote="true" method="post"><div style="margin:0;padding:0;display:inline"><input name="utf8" type="hidden" value="&#x2713;" /><input name="authenticity_token" type="hidden" value="k77w0p2/3v6jd7I5aq8V0JJqpd4M/ym55XHQW97/5eILdftK7tfNglykBwbWm9zYIv2S7HNeeskTuM+6HkAG6g==" /></div><button class="btn-link js-clone-selector" data-protocol="http" type="submit">HTTPS</button></form> or <form accept-charset="UTF-8" action="/users/set_protocol?protocol_selector=subversion&amp;protocol_type=clone" class="inline-form js-clone-selector-form " data-remote="true" method="post"><div style="margin:0;padding:0;display:inline"><input name="utf8" type="hidden" value="&#x2713;" /><input name="authenticity_token" type="hidden" value="T7+Vz4j6/ekdI9U5bgvZnIGeBmCT5nstFXFIoFiSAM9LQPWYStGsL6X6CvHv0YGmx6FToLUGkm8beIHqEonR2g==" /></div><button class="btn-link js-clone-selector" data-protocol="subversion" type="submit">Subversion</button></form>.
  <a href="https://help.github.com/articles/which-remote-url-should-i-use" class="help tooltipped tooltipped-n" aria-label="Get help on which URL is right for you.">
    <span class="octicon octicon-question"></span>
  </a>
</div>




                <a href="/STRML/strml.net/archive/50b1cf37dfaffebaafe00e2417a2d4e32da732d2.zip"
                   class="btn btn-sm sidebar-button"
                   aria-label="Download the contents of STRML/strml.net as a zip file"
                   title="Download the contents of STRML/strml.net as a zip file"
                   rel="nofollow">
                  <span class="octicon octicon-cloud-download"></span>
                  Download ZIP
                </a>
              </div>
        </div><!-- /.repository-sidebar -->

        <div id="js-repo-pjax-container" class="repository-content context-loader-container" data-pjax-container>

          
<div id="compare">
  <div class="file-navigation">
    <div class="breadcrumb">
      History for <span class="repo-root js-repo-root"><span itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb"><a href="/STRML/strml.net/commits/50b1cf37dfaffebaafe00e2417a2d4e32da732d2" class="" data-branch="50b1cf37dfaffebaafe00e2417a2d4e32da732d2" data-pjax="true" itemscope="url" rel="nofollow"><span itemprop="title">strml.net</span></a></span></span><span class="separator">/</span><strong class="final-path">app.js</strong>
    </div>
  </div>

  

  <div class="commits-listing commits-listing-padded js-navigation-container js-active-navigation-container" data-navigation-scroll="page">

    
<div class="commit-group-title">
  <span class="octicon octicon-git-commit"></span>Commits on May 20, 2015
</div>

<ol class="commit-group table-list table-list-bordered">
    
<li class="commit commits-list-item table-list-item js-navigation-item js-details-container js-socket-channel js-updatable-content"
      data-channel="STRML/strml.net:commit:50b1cf37dfaffebaafe00e2417a2d4e32da732d2"
      data-url="/STRML/strml.net/commit/50b1cf37dfaffebaafe00e2417a2d4e32da732d2/show_partial?partial=commits%2Fcommits_list_item"
    >

  <div class="table-list-cell commit-avatar-cell">
    <div class="avatar-parent-child">
    <a href="/STRML" data-skip-pjax="true" rel="author"><img alt="@STRML" class="avatar" height="36" src="https://avatars2.githubusercontent.com/u/1197375?v=3&amp;s=72" width="36" /></a>
    </div>
  </div>
  <div class="table-list-cell">
    <p class="commit-title ">
        <a href="/STRML/strml.net/commit/50b1cf37dfaffebaafe00e2417a2d4e32da732d2" class="message" data-pjax="true" title="Speed up pgp text &amp; build">Speed up pgp text &amp; build</a>

    
    </p>

    <div class="commit-meta">
        <a href="/STRML/strml.net/commits/50b1cf37dfaffebaafe00e2417a2d4e32da732d2/app.js?author=STRML" aria-label="View all commits by Samuel Reed" class="commit-author tooltipped tooltipped-s" rel="author">STRML</a>
       authored <time datetime="2015-05-20T01:03:25Z" is="relative-time">May 19, 2015</time>



    </div>

  </div>
  <div class="commit-links-cell table-list-cell">
    <div class="commit-links-group btn-group">
      <button aria-label="Copy the full SHA" class="js-zeroclipboard btn btn-outline zeroclipboard-button tooltipped tooltipped-s" data-clipboard-text="50b1cf37dfaffebaafe00e2417a2d4e32da732d2" data-copied-hint="Copied!" type="button"><span class="octicon octicon-clippy"></span></button>
      <a href="/STRML/strml.net/commit/50b1cf37dfaffebaafe00e2417a2d4e32da732d2#diff-0364f57fbff2fabbe941ed20c328ef1a" class="sha btn btn-outline">
        50b1cf3
      </a>
    </div>
    <a href="/STRML/strml.net/tree/50b1cf37dfaffebaafe00e2417a2d4e32da732d2/app.js" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-s" rel="nofollow"><span class="octicon octicon-code"></span></a>
  </div>

</li>

</ol>

    
<div class="commit-group-title">
  <span class="octicon octicon-git-commit"></span>Commits on May 16, 2015
</div>

<ol class="commit-group table-list table-list-bordered">
    
<li class="commit commits-list-item table-list-item js-navigation-item js-details-container js-socket-channel js-updatable-content"
      data-channel="STRML/strml.net:commit:7250fd48517e9b654f36985bd1a29211e1c9d371"
      data-url="/STRML/strml.net/commit/7250fd48517e9b654f36985bd1a29211e1c9d371/show_partial?partial=commits%2Fcommits_list_item"
    >

  <div class="table-list-cell commit-avatar-cell">
    <div class="avatar-parent-child">
    <a href="/STRML" data-skip-pjax="true" rel="author"><img alt="@STRML" class="avatar" height="36" src="https://avatars2.githubusercontent.com/u/1197375?v=3&amp;s=72" width="36" /></a>
    </div>
  </div>
  <div class="table-list-cell">
    <p class="commit-title ">
        <a href="/STRML/strml.net/commit/7250fd48517e9b654f36985bd1a29211e1c9d371" class="message" data-pjax="true" title="Add pause/resume">Add pause/resume</a>

    
    </p>

    <div class="commit-meta">
        <a href="/STRML/strml.net/commits/50b1cf37dfaffebaafe00e2417a2d4e32da732d2/app.js?author=STRML" aria-label="View all commits by Samuel Reed" class="commit-author tooltipped tooltipped-s" rel="author">STRML</a>
       authored <time datetime="2015-05-16T14:42:45Z" is="relative-time">May 16, 2015</time>



    </div>

  </div>
  <div class="commit-links-cell table-list-cell">
    <div class="commit-links-group btn-group">
      <button aria-label="Copy the full SHA" class="js-zeroclipboard btn btn-outline zeroclipboard-button tooltipped tooltipped-s" data-clipboard-text="7250fd48517e9b654f36985bd1a29211e1c9d371" data-copied-hint="Copied!" type="button"><span class="octicon octicon-clippy"></span></button>
      <a href="/STRML/strml.net/commit/7250fd48517e9b654f36985bd1a29211e1c9d371#diff-0364f57fbff2fabbe941ed20c328ef1a" class="sha btn btn-outline">
        7250fd4
      </a>
    </div>
    <a href="/STRML/strml.net/tree/7250fd48517e9b654f36985bd1a29211e1c9d371/app.js" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-s" rel="nofollow"><span class="octicon octicon-code"></span></a>
  </div>

</li>

</ol>

    
<div class="commit-group-title">
  <span class="octicon octicon-git-commit"></span>Commits on May 15, 2015
</div>

<ol class="commit-group table-list table-list-bordered">
    
<li class="commit commits-list-item table-list-item js-navigation-item js-details-container js-socket-channel js-updatable-content"
      data-channel="STRML/strml.net:commit:9004795f35f41b6cda061a643cc0ef32dee281b9"
      data-url="/STRML/strml.net/commit/9004795f35f41b6cda061a643cc0ef32dee281b9/show_partial?partial=commits%2Fcommits_list_item"
    >

  <div class="table-list-cell commit-avatar-cell">
    <div class="avatar-parent-child">
    <a href="/STRML" data-skip-pjax="true" rel="author"><img alt="@STRML" class="avatar" height="36" src="https://avatars2.githubusercontent.com/u/1197375?v=3&amp;s=72" width="36" /></a>
    </div>
  </div>
  <div class="table-list-cell">
    <p class="commit-title ">
        <a href="/STRML/strml.net/commit/9004795f35f41b6cda061a643cc0ef32dee281b9" class="message" data-pjax="true" title="Don&#39;t goof if the browser isn&#39;t IE/FF/Webkit">Don't goof if the browser isn't IE/FF/Webkit</a>

    
    </p>

    <div class="commit-meta">
        <a href="/STRML/strml.net/commits/50b1cf37dfaffebaafe00e2417a2d4e32da732d2/app.js?author=STRML" aria-label="View all commits by Samuel Reed" class="commit-author tooltipped tooltipped-s" rel="author">STRML</a>
       authored <time datetime="2015-05-15T22:52:53Z" is="relative-time">May 15, 2015</time>



    </div>

  </div>
  <div class="commit-links-cell table-list-cell">
    <div class="commit-links-group btn-group">
      <button aria-label="Copy the full SHA" class="js-zeroclipboard btn btn-outline zeroclipboard-button tooltipped tooltipped-s" data-clipboard-text="9004795f35f41b6cda061a643cc0ef32dee281b9" data-copied-hint="Copied!" type="button"><span class="octicon octicon-clippy"></span></button>
      <a href="/STRML/strml.net/commit/9004795f35f41b6cda061a643cc0ef32dee281b9#diff-0364f57fbff2fabbe941ed20c328ef1a" class="sha btn btn-outline">
        9004795
      </a>
    </div>
    <a href="/STRML/strml.net/tree/9004795f35f41b6cda061a643cc0ef32dee281b9/app.js" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-s" rel="nofollow"><span class="octicon octicon-code"></span></a>
  </div>

</li>

</ol>

    
<div class="commit-group-title">
  <span class="octicon octicon-git-commit"></span>Commits on May 11, 2015
</div>

<ol class="commit-group table-list table-list-bordered">
    
<li class="commit commits-list-item table-list-item js-navigation-item js-details-container js-socket-channel js-updatable-content"
      data-channel="STRML/strml.net:commit:3f1a7b2aaa6181270b951ce31b277564e4eb93ff"
      data-url="/STRML/strml.net/commit/3f1a7b2aaa6181270b951ce31b277564e4eb93ff/show_partial?partial=commits%2Fcommits_list_item"
    >

  <div class="table-list-cell commit-avatar-cell">
    <div class="avatar-parent-child">
    <a href="/STRML" data-skip-pjax="true" rel="author"><img alt="@STRML" class="avatar" height="36" src="https://avatars2.githubusercontent.com/u/1197375?v=3&amp;s=72" width="36" /></a>
    </div>
  </div>
  <div class="table-list-cell">
    <p class="commit-title ">
        <a href="/STRML/strml.net/commit/3f1a7b2aaa6181270b951ce31b277564e4eb93ff" class="message" data-pjax="true" title="Allow skipping animation, and add header (really footer) bar.">Allow skipping animation, and add header (really footer) bar.</a>

    
    </p>

    <div class="commit-meta">
        <a href="/STRML/strml.net/commits/50b1cf37dfaffebaafe00e2417a2d4e32da732d2/app.js?author=STRML" aria-label="View all commits by Samuel Reed" class="commit-author tooltipped tooltipped-s" rel="author">STRML</a>
       authored <time datetime="2015-05-11T04:24:58Z" is="relative-time">May 10, 2015</time>



    </div>

  </div>
  <div class="commit-links-cell table-list-cell">
    <div class="commit-links-group btn-group">
      <button aria-label="Copy the full SHA" class="js-zeroclipboard btn btn-outline zeroclipboard-button tooltipped tooltipped-s" data-clipboard-text="3f1a7b2aaa6181270b951ce31b277564e4eb93ff" data-copied-hint="Copied!" type="button"><span class="octicon octicon-clippy"></span></button>
      <a href="/STRML/strml.net/commit/3f1a7b2aaa6181270b951ce31b277564e4eb93ff#diff-0364f57fbff2fabbe941ed20c328ef1a" class="sha btn btn-outline">
        3f1a7b2
      </a>
    </div>
    <a href="/STRML/strml.net/tree/3f1a7b2aaa6181270b951ce31b277564e4eb93ff/app.js" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-s" rel="nofollow"><span class="octicon octicon-code"></span></a>
  </div>

</li>

</ol>

    
<div class="commit-group-title">
  <span class="octicon octicon-git-commit"></span>Commits on Apr 4, 2015
</div>

<ol class="commit-group table-list table-list-bordered">
    
<li class="commit commits-list-item table-list-item js-navigation-item js-details-container js-socket-channel js-updatable-content"
      data-channel="STRML/strml.net:commit:d395e7f6f050317d8d8d05e2e85782dc2500341a"
      data-url="/STRML/strml.net/commit/d395e7f6f050317d8d8d05e2e85782dc2500341a/show_partial?partial=commits%2Fcommits_list_item"
    >

  <div class="table-list-cell commit-avatar-cell">
    <div class="avatar-parent-child">
    <a href="/STRML" data-skip-pjax="true" rel="author"><img alt="@STRML" class="avatar" height="36" src="https://avatars2.githubusercontent.com/u/1197375?v=3&amp;s=72" width="36" /></a>
    </div>
  </div>
  <div class="table-list-cell">
    <p class="commit-title ">
        <a href="/STRML/strml.net/commit/d395e7f6f050317d8d8d05e2e85782dc2500341a" class="message" data-pjax="true" title="Trim css a bit">Trim css a bit</a>

    
    </p>

    <div class="commit-meta">
        <a href="/STRML/strml.net/commits/50b1cf37dfaffebaafe00e2417a2d4e32da732d2/app.js?author=STRML" aria-label="View all commits by Samuel Reed" class="commit-author tooltipped tooltipped-s" rel="author">STRML</a>
       authored <time datetime="2015-04-04T16:34:29Z" is="relative-time">Apr 4, 2015</time>



    </div>

  </div>
  <div class="commit-links-cell table-list-cell">
    <div class="commit-links-group btn-group">
      <button aria-label="Copy the full SHA" class="js-zeroclipboard btn btn-outline zeroclipboard-button tooltipped tooltipped-s" data-clipboard-text="d395e7f6f050317d8d8d05e2e85782dc2500341a" data-copied-hint="Copied!" type="button"><span class="octicon octicon-clippy"></span></button>
      <a href="/STRML/strml.net/commit/d395e7f6f050317d8d8d05e2e85782dc2500341a#diff-0364f57fbff2fabbe941ed20c328ef1a" class="sha btn btn-outline">
        d395e7f
      </a>
    </div>
    <a href="/STRML/strml.net/tree/d395e7f6f050317d8d8d05e2e85782dc2500341a/app.js" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-s" rel="nofollow"><span class="octicon octicon-code"></span></a>
  </div>

</li>

    
<li class="commit commits-list-item table-list-item js-navigation-item js-details-container js-socket-channel js-updatable-content"
      data-channel="STRML/strml.net:commit:12ec4a3cd79b1cd71cbacd047f2c4f5dcb74f6be"
      data-url="/STRML/strml.net/commit/12ec4a3cd79b1cd71cbacd047f2c4f5dcb74f6be/show_partial?partial=commits%2Fcommits_list_item"
    >

  <div class="table-list-cell commit-avatar-cell">
    <div class="avatar-parent-child">
    <a href="/STRML" data-skip-pjax="true" rel="author"><img alt="@STRML" class="avatar" height="36" src="https://avatars2.githubusercontent.com/u/1197375?v=3&amp;s=72" width="36" /></a>
    </div>
  </div>
  <div class="table-list-cell">
    <p class="commit-title ">
        <a href="/STRML/strml.net/commit/12ec4a3cd79b1cd71cbacd047f2c4f5dcb74f6be" class="message" data-pjax="true" title="Wait until after rendering markdown to adjust styles">Wait until after rendering markdown to adjust styles</a>

    
    </p>

    <div class="commit-meta">
        <a href="/STRML/strml.net/commits/50b1cf37dfaffebaafe00e2417a2d4e32da732d2/app.js?author=STRML" aria-label="View all commits by Samuel Reed" class="commit-author tooltipped tooltipped-s" rel="author">STRML</a>
       authored <time datetime="2015-04-04T13:57:02Z" is="relative-time">Apr 4, 2015</time>



    </div>

  </div>
  <div class="commit-links-cell table-list-cell">
    <div class="commit-links-group btn-group">
      <button aria-label="Copy the full SHA" class="js-zeroclipboard btn btn-outline zeroclipboard-button tooltipped tooltipped-s" data-clipboard-text="12ec4a3cd79b1cd71cbacd047f2c4f5dcb74f6be" data-copied-hint="Copied!" type="button"><span class="octicon octicon-clippy"></span></button>
      <a href="/STRML/strml.net/commit/12ec4a3cd79b1cd71cbacd047f2c4f5dcb74f6be#diff-0364f57fbff2fabbe941ed20c328ef1a" class="sha btn btn-outline">
        12ec4a3
      </a>
    </div>
    <a href="/STRML/strml.net/tree/12ec4a3cd79b1cd71cbacd047f2c4f5dcb74f6be/app.js" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-s" rel="nofollow"><span class="octicon octicon-code"></span></a>
  </div>

</li>

    
<li class="commit commits-list-item table-list-item js-navigation-item js-details-container js-socket-channel js-updatable-content"
      data-channel="STRML/strml.net:commit:b032aabcd97811ab4377eb0af10eee278ba11578"
      data-url="/STRML/strml.net/commit/b032aabcd97811ab4377eb0af10eee278ba11578/show_partial?partial=commits%2Fcommits_list_item"
    >

  <div class="table-list-cell commit-avatar-cell">
    <div class="avatar-parent-child">
    <a href="/STRML" data-skip-pjax="true" rel="author"><img alt="@STRML" class="avatar" height="36" src="https://avatars2.githubusercontent.com/u/1197375?v=3&amp;s=72" width="36" /></a>
    </div>
  </div>
  <div class="table-list-cell">
    <p class="commit-title ">
        <a href="/STRML/strml.net/commit/b032aabcd97811ab4377eb0af10eee278ba11578" class="message" data-pjax="true" title="Add new steps, refactoring, promises, markdown rendering, and more.">Add new steps, refactoring, promises, markdown rendering, and more.</a>

    
    </p>

    <div class="commit-meta">
        <a href="/STRML/strml.net/commits/50b1cf37dfaffebaafe00e2417a2d4e32da732d2/app.js?author=STRML" aria-label="View all commits by Samuel Reed" class="commit-author tooltipped tooltipped-s" rel="author">STRML</a>
       authored <time datetime="2015-04-04T13:50:34Z" is="relative-time">Apr 4, 2015</time>



    </div>

  </div>
  <div class="commit-links-cell table-list-cell">
    <div class="commit-links-group btn-group">
      <button aria-label="Copy the full SHA" class="js-zeroclipboard btn btn-outline zeroclipboard-button tooltipped tooltipped-s" data-clipboard-text="b032aabcd97811ab4377eb0af10eee278ba11578" data-copied-hint="Copied!" type="button"><span class="octicon octicon-clippy"></span></button>
      <a href="/STRML/strml.net/commit/b032aabcd97811ab4377eb0af10eee278ba11578#diff-0364f57fbff2fabbe941ed20c328ef1a" class="sha btn btn-outline">
        b032aab
      </a>
    </div>
    <a href="/STRML/strml.net/tree/b032aabcd97811ab4377eb0af10eee278ba11578/app.js" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-s" rel="nofollow"><span class="octicon octicon-code"></span></a>
  </div>

</li>

    
<li class="commit commits-list-item table-list-item js-navigation-item js-details-container js-socket-channel js-updatable-content"
      data-channel="STRML/strml.net:commit:256d0144f99e13b74cbfe27e8071ed62270ae7dd"
      data-url="/STRML/strml.net/commit/256d0144f99e13b74cbfe27e8071ed62270ae7dd/show_partial?partial=commits%2Fcommits_list_item"
    >

  <div class="table-list-cell commit-avatar-cell">
    <div class="avatar-parent-child">
    <a href="/STRML" data-skip-pjax="true" rel="author"><img alt="@STRML" class="avatar" height="36" src="https://avatars2.githubusercontent.com/u/1197375?v=3&amp;s=72" width="36" /></a>
    </div>
  </div>
  <div class="table-list-cell">
    <p class="commit-title ">
        <a href="/STRML/strml.net/commit/256d0144f99e13b74cbfe27e8071ed62270ae7dd" class="message" data-pjax="true" title="Autoreplace urls in data.txt and some text tweaks">Autoreplace urls in data.txt and some text tweaks</a>

    
    </p>

    <div class="commit-meta">
        <a href="/STRML/strml.net/commits/50b1cf37dfaffebaafe00e2417a2d4e32da732d2/app.js?author=STRML" aria-label="View all commits by Samuel Reed" class="commit-author tooltipped tooltipped-s" rel="author">STRML</a>
       authored <time datetime="2015-04-04T01:17:24Z" is="relative-time">Apr 3, 2015</time>



    </div>

  </div>
  <div class="commit-links-cell table-list-cell">
    <div class="commit-links-group btn-group">
      <button aria-label="Copy the full SHA" class="js-zeroclipboard btn btn-outline zeroclipboard-button tooltipped tooltipped-s" data-clipboard-text="256d0144f99e13b74cbfe27e8071ed62270ae7dd" data-copied-hint="Copied!" type="button"><span class="octicon octicon-clippy"></span></button>
      <a href="/STRML/strml.net/commit/256d0144f99e13b74cbfe27e8071ed62270ae7dd#diff-0364f57fbff2fabbe941ed20c328ef1a" class="sha btn btn-outline">
        256d014
      </a>
    </div>
    <a href="/STRML/strml.net/tree/256d0144f99e13b74cbfe27e8071ed62270ae7dd/app.js" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-s" rel="nofollow"><span class="octicon octicon-code"></span></a>
  </div>

</li>

    
<li class="commit commits-list-item table-list-item js-navigation-item js-details-container js-socket-channel js-updatable-content"
      data-channel="STRML/strml.net:commit:5aae00b4c56baa8021580f896c2ca292cd28d867"
      data-url="/STRML/strml.net/commit/5aae00b4c56baa8021580f896c2ca292cd28d867/show_partial?partial=commits%2Fcommits_list_item"
    >

  <div class="table-list-cell commit-avatar-cell">
    <div class="avatar-parent-child">
    <a href="/STRML" data-skip-pjax="true" rel="author"><img alt="@STRML" class="avatar" height="36" src="https://avatars2.githubusercontent.com/u/1197375?v=3&amp;s=72" width="36" /></a>
    </div>
  </div>
  <div class="table-list-cell">
    <p class="commit-title ">
        <a href="/STRML/strml.net/commit/5aae00b4c56baa8021580f896c2ca292cd28d867" class="message" data-pjax="true" title="Initial commit.">Initial commit.</a>

    
    </p>

    <div class="commit-meta">
        <a href="/STRML/strml.net/commits/50b1cf37dfaffebaafe00e2417a2d4e32da732d2/app.js?author=STRML" aria-label="View all commits by Samuel Reed" class="commit-author tooltipped tooltipped-s" rel="author">STRML</a>
       authored <time datetime="2015-04-04T00:50:45Z" is="relative-time">Apr 3, 2015</time>



    </div>

  </div>
  <div class="commit-links-cell table-list-cell">
    <div class="commit-links-group btn-group">
      <button aria-label="Copy the full SHA" class="js-zeroclipboard btn btn-outline zeroclipboard-button tooltipped tooltipped-s" data-clipboard-text="5aae00b4c56baa8021580f896c2ca292cd28d867" data-copied-hint="Copied!" type="button"><span class="octicon octicon-clippy"></span></button>
      <a href="/STRML/strml.net/commit/5aae00b4c56baa8021580f896c2ca292cd28d867#diff-0364f57fbff2fabbe941ed20c328ef1a" class="sha btn btn-outline">
        5aae00b
      </a>
    </div>
    <a href="/STRML/strml.net/tree/5aae00b4c56baa8021580f896c2ca292cd28d867/app.js" aria-label="Browse the repository at this point in the history" class="btn btn-outline tooltipped tooltipped-s" rel="nofollow"><span class="octicon octicon-code"></span></a>
  </div>

</li>

</ol>


  </div>



    <div class="paginate-container" data-pjax>
      
    </div>

</div>

        </div>

      </div><!-- /.repo-container -->
      <div class="modal-backdrop"></div>
    </div><!-- /.container -->
  </div><!-- /.site -->


    </div><!-- /.wrapper -->

      <div class="container">
  <div class="site-footer" role="contentinfo">
    <ul class="site-footer-links right">
        <li><a href="https://status.github.com/" data-ga-click="Footer, go to status, text:status">Status</a></li>
      <li><a href="https://developer.github.com" data-ga-click="Footer, go to api, text:api">API</a></li>
      <li><a href="https://training.github.com" data-ga-click="Footer, go to training, text:training">Training</a></li>
      <li><a href="https://shop.github.com" data-ga-click="Footer, go to shop, text:shop">Shop</a></li>
        <li><a href="https://github.com/blog" data-ga-click="Footer, go to blog, text:blog">Blog</a></li>
        <li><a href="https://github.com/about" data-ga-click="Footer, go to about, text:about">About</a></li>

    </ul>

    <a href="https://github.com" aria-label="Homepage">
      <span class="mega-octicon octicon-mark-github" title="GitHub"></span>
</a>
    <ul class="site-footer-links">
      <li>&copy; 2015 <span title="0.07659s from github-fe118-cp1-prd.iad.github.net">GitHub</span>, Inc.</li>
        <li><a href="https://github.com/site/terms" data-ga-click="Footer, go to terms, text:terms">Terms</a></li>
        <li><a href="https://github.com/site/privacy" data-ga-click="Footer, go to privacy, text:privacy">Privacy</a></li>
        <li><a href="https://github.com/security" data-ga-click="Footer, go to security, text:security">Security</a></li>
        <li><a href="https://github.com/contact" data-ga-click="Footer, go to contact, text:contact">Contact</a></li>
    </ul>
  </div>
</div>


    <div class="fullscreen-overlay js-fullscreen-overlay" id="fullscreen_overlay">
  <div class="fullscreen-container js-suggester-container">
    <div class="textarea-wrap">
      <textarea name="fullscreen-contents" id="fullscreen-contents" class="fullscreen-contents js-fullscreen-contents" placeholder=""></textarea>
      <div class="suggester-container">
        <div class="suggester fullscreen-suggester js-suggester js-navigation-container"></div>
      </div>
    </div>
  </div>
  <div class="fullscreen-sidebar">
    <a href="#" class="exit-fullscreen js-exit-fullscreen tooltipped tooltipped-w" aria-label="Exit Zen Mode">
      <span class="mega-octicon octicon-screen-normal"></span>
    </a>
    <a href="#" class="theme-switcher js-theme-switcher tooltipped tooltipped-w"
      aria-label="Switch themes">
      <span class="octicon octicon-color-mode"></span>
    </a>
  </div>
</div>



    

    <div id="ajax-error-message" class="flash flash-error">
      <span class="octicon octicon-alert"></span>
      <a href="#" class="octicon octicon-x flash-close js-ajax-error-dismiss" aria-label="Dismiss error"></a>
      Something went wrong with that request. Please try again.
    </div>


      <script crossorigin="anonymous" src="https://assets-cdn.github.com/assets/frameworks-447ce66a36506ebddc8e84b4e32a77f6062f3d3482e77dd21a77a01f0643ad98.js"></script>
      <script async="async" crossorigin="anonymous" src="https://assets-cdn.github.com/assets/github/index-273626d05f0daba1adb856ea6f9d82ff151f8b9f23a21044a761d2e2f843b354.js"></script>
      
      
  </body>
</html>

