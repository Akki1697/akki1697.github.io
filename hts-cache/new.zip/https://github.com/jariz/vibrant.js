


<!DOCTYPE html>
<html lang="en" class="">
  <head prefix="og: http://ogp.me/ns# fb: http://ogp.me/ns/fb# object: http://ogp.me/ns/object# article: http://ogp.me/ns/article# profile: http://ogp.me/ns/profile#">
    <meta charset='utf-8'>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Language" content="en">
    
    
    <title>jariz/vibrant.js · GitHub</title>
    <link rel="search" type="application/opensearchdescription+xml" href="/opensearch.xml" title="GitHub">
    <link rel="fluid-icon" href="https://github.com/fluidicon.png" title="GitHub">
    <link rel="apple-touch-icon" sizes="57x57" href="/apple-touch-icon-114.png">
    <link rel="apple-touch-icon" sizes="114x114" href="/apple-touch-icon-114.png">
    <link rel="apple-touch-icon" sizes="72x72" href="/apple-touch-icon-144.png">
    <link rel="apple-touch-icon" sizes="144x144" href="/apple-touch-icon-144.png">
    <meta property="fb:app_id" content="1401488693436528">

      <meta content="@github" name="twitter:site" /><meta content="summary" name="twitter:card" /><meta content="jariz/vibrant.js" name="twitter:title" /><meta content="vibrant.js - Extract prominent colors from an image. JS port of Android&amp;#39;s Palette." name="twitter:description" /><meta content="https://avatars3.githubusercontent.com/u/1415847?v=3&amp;s=400" name="twitter:image:src" />
      <meta content="GitHub" property="og:site_name" /><meta content="object" property="og:type" /><meta content="https://avatars3.githubusercontent.com/u/1415847?v=3&amp;s=400" property="og:image" /><meta content="jariz/vibrant.js" property="og:title" /><meta content="https://github.com/jariz/vibrant.js" property="og:url" /><meta content="vibrant.js - Extract prominent colors from an image. JS port of Android&#39;s Palette." property="og:description" />
      <meta name="browser-stats-url" content="https://api.github.com/_private/browser/stats">
    <meta name="browser-errors-url" content="https://api.github.com/_private/browser/errors">
    <link rel="assets" href="https://assets-cdn.github.com/">
    
    <meta name="pjax-timeout" content="1000">
    

    <meta name="msapplication-TileImage" content="/windows-tile.png">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="selected-link" value="repo_source" data-pjax-transient>
      <meta name="google-analytics" content="UA-3769691-2">

    <meta content="collector.githubapp.com" name="octolytics-host" /><meta content="collector-cdn.github.com" name="octolytics-script-host" /><meta content="github" name="octolytics-app-id" /><meta content="783D1521:06C2:13E794C:5571A933" name="octolytics-dimension-request_id" />
    
    <meta content="Rails, view, files#disambiguate" name="analytics-event" />
    <meta class="js-ga-set" name="dimension1" content="Logged Out">
    <meta class="js-ga-set" name="dimension2" content="Header v3">
    <meta name="is-dotcom" content="true">
      <meta name="hostname" content="github.com">
    <meta name="user-login" content="">

    
    <link rel="icon" type="image/x-icon" href="https://assets-cdn.github.com/favicon.ico">


    <meta content="authenticity_token" name="csrf-param" />
<meta content="YnCXmCBzaxD6WB/9USCsbhkCdm9D85rr7NA+Kxxtqbv/A+NM06Ia0mZD6SYuu7/g2ZdpXff31TNFO456W+VhQg==" name="csrf-token" />

    <link crossorigin="anonymous" href="https://assets-cdn.github.com/assets/github/index-6967b378b26829cc5a2ea2ad4209ff0af50f2a65057962219dc9dcf8942683f0.css" media="all" rel="stylesheet" />
    <link crossorigin="anonymous" href="https://assets-cdn.github.com/assets/github2/index-73bfe123ff406f4bf8959a28667410beaac1485e71c92d4725a3d7afc45fc4c5.css" media="all" rel="stylesheet" />
    
    


    <meta http-equiv="x-pjax-version" content="b2ca4753a2f40f3bd3d3d6fd0fe8b32e">

      
  <meta name="description" content="vibrant.js - Extract prominent colors from an image. JS port of Android&#39;s Palette.">
  <meta name="go-import" content="github.com/jariz/vibrant.js git https://github.com/jariz/vibrant.js.git">

  <meta content="1415847" name="octolytics-dimension-user_id" /><meta content="jariz" name="octolytics-dimension-user_login" /><meta content="36187165" name="octolytics-dimension-repository_id" /><meta content="jariz/vibrant.js" name="octolytics-dimension-repository_nwo" /><meta content="true" name="octolytics-dimension-repository_public" /><meta content="false" name="octolytics-dimension-repository_is_fork" /><meta content="36187165" name="octolytics-dimension-repository_network_root_id" /><meta content="jariz/vibrant.js" name="octolytics-dimension-repository_network_root_nwo" />
  <link href="https://github.com/jariz/vibrant.js/commits/master.atom" rel="alternate" title="Recent Commits to vibrant.js:master" type="application/atom+xml">

  </head>


  <body class="logged_out  env-production  vis-public">
    <a href="#start-of-content" tabindex="1" class="accessibility-aid js-skip-to-content">Skip to content</a>
    <div class="wrapper">
      
      
      


        
        <div class="header header-logged-out" role="banner">
  <div class="container clearfix">

    <a class="header-logo-wordmark" href="https://github.com/" data-ga-click="(Logged out) Header, go to homepage, icon:logo-wordmark">
      <span class="mega-octicon octicon-logo-github"></span>
    </a>

    <div class="header-actions" role="navigation">
        <a class="btn btn-primary" href="/join" data-ga-click="(Logged out) Header, clicked Sign up, text:sign-up">Sign up</a>
      <a class="btn" href="/login?return_to=%2Fjariz%2Fvibrant.js" data-ga-click="(Logged out) Header, clicked Sign in, text:sign-in">Sign in</a>
    </div>

    <div class="site-search repo-scope js-site-search" role="search">
      <form accept-charset="UTF-8" action="/jariz/vibrant.js/search" class="js-site-search-form" data-global-search-url="/search" data-repo-search-url="/jariz/vibrant.js/search" method="get"><div style="margin:0;padding:0;display:inline"><input name="utf8" type="hidden" value="&#x2713;" /></div>
  <label class="js-chromeless-input-container form-control">
    <div class="scope-badge">This repository</div>
    <input type="text"
      class="js-site-search-focus js-site-search-field is-clearable chromeless-input"
      data-hotkey="s"
      name="q"
      placeholder="Search"
      data-global-scope-placeholder="Search GitHub"
      data-repo-scope-placeholder="Search"
      tabindex="1"
      autocapitalize="off">
  </label>
</form>
    </div>

      <ul class="header-nav left" role="navigation">
          <li class="header-nav-item">
            <a class="header-nav-link" href="/explore" data-ga-click="(Logged out) Header, go to explore, text:explore">Explore</a>
          </li>
          <li class="header-nav-item">
            <a class="header-nav-link" href="/features" data-ga-click="(Logged out) Header, go to features, text:features">Features</a>
          </li>
          <li class="header-nav-item">
            <a class="header-nav-link" href="https://enterprise.github.com/" data-ga-click="(Logged out) Header, go to enterprise, text:enterprise">Enterprise</a>
          </li>
          <li class="header-nav-item">
            <a class="header-nav-link" href="/blog" data-ga-click="(Logged out) Header, go to blog, text:blog">Blog</a>
          </li>
      </ul>

  </div>
</div>



      <div id="start-of-content" class="accessibility-aid"></div>
          <div class="site" itemscope itemtype="http://schema.org/WebPage">
    <div id="js-flash-container">
      
    </div>
    <div class="pagehead repohead instapaper_ignore readability-menu">
      <div class="container">

        
<ul class="pagehead-actions">

  <li>
      <a href="/login?return_to=%2Fjariz%2Fvibrant.js"
    class="btn btn-sm btn-with-count tooltipped tooltipped-n"
    aria-label="You must be signed in to watch a repository" rel="nofollow">
    <span class="octicon octicon-eye"></span>
    Watch
  </a>
  <a class="social-count" href="/jariz/vibrant.js/watchers">
    53
  </a>

  </li>

  <li>
      <a href="/login?return_to=%2Fjariz%2Fvibrant.js"
    class="btn btn-sm btn-with-count tooltipped tooltipped-n"
    aria-label="You must be signed in to star a repository" rel="nofollow">
    <span class="octicon octicon-star"></span>
    Star
  </a>

    <a class="social-count js-social-count" href="/jariz/vibrant.js/stargazers">
      2,414
    </a>

  </li>

    <li>
      <a href="/login?return_to=%2Fjariz%2Fvibrant.js"
        class="btn btn-sm btn-with-count tooltipped tooltipped-n"
        aria-label="You must be signed in to fork a repository" rel="nofollow">
        <span class="octicon octicon-repo-forked"></span>
        Fork
      </a>
      <a href="/jariz/vibrant.js/network" class="social-count">
        58
      </a>
    </li>
</ul>

        <h1 itemscope itemtype="http://data-vocabulary.org/Breadcrumb" class="entry-title public">
          <span class="mega-octicon octicon-repo"></span>
          <span class="author"><a href="/jariz" class="url fn" itemprop="url" rel="author"><span itemprop="title">jariz</span></a></span><!--
       --><span class="path-divider">/</span><!--
       --><strong><a href="/jariz/vibrant.js" data-pjax="#js-repo-pjax-container">vibrant.js</a></strong>

          <span class="page-context-loader">
            <img alt="" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </span>

        </h1>
      </div><!-- /.container -->
    </div><!-- /.repohead -->

    <div class="container">
      <div class="repository-with-sidebar repo-container new-discussion-timeline with-full-navigation ">
        <div class="repository-sidebar clearfix">
            
<nav class="sunken-menu repo-nav js-repo-nav js-sidenav-container-pjax js-octicon-loaders"
     role="navigation"
     data-pjax="#js-repo-pjax-container"
     data-issue-count-url="/jariz/vibrant.js/issues/counts">
  <ul class="sunken-menu-group">
    <li class="tooltipped tooltipped-w" aria-label="Code">
      <a href="/jariz/vibrant.js" aria-label="Code" class="selected js-selected-navigation-item sunken-menu-item" data-hotkey="g c" data-selected-links="repo_source repo_downloads repo_commits repo_releases repo_tags repo_branches /jariz/vibrant.js">
        <span class="octicon octicon-code"></span> <span class="full-word">Code</span>
        <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>    </li>

      <li class="tooltipped tooltipped-w" aria-label="Issues">
        <a href="/jariz/vibrant.js/issues" aria-label="Issues" class="js-selected-navigation-item sunken-menu-item" data-hotkey="g i" data-selected-links="repo_issues repo_labels repo_milestones /jariz/vibrant.js/issues">
          <span class="octicon octicon-issue-opened"></span> <span class="full-word">Issues</span>
          <span class="js-issue-replace-counter"></span>
          <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>      </li>

    <li class="tooltipped tooltipped-w" aria-label="Pull requests">
      <a href="/jariz/vibrant.js/pulls" aria-label="Pull requests" class="js-selected-navigation-item sunken-menu-item" data-hotkey="g p" data-selected-links="repo_pulls /jariz/vibrant.js/pulls">
          <span class="octicon octicon-git-pull-request"></span> <span class="full-word">Pull requests</span>
          <span class="js-pull-replace-counter"></span>
          <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>    </li>

  </ul>
  <div class="sunken-menu-separator"></div>
  <ul class="sunken-menu-group">

    <li class="tooltipped tooltipped-w" aria-label="Pulse">
      <a href="/jariz/vibrant.js/pulse" aria-label="Pulse" class="js-selected-navigation-item sunken-menu-item" data-selected-links="pulse /jariz/vibrant.js/pulse">
        <span class="octicon octicon-pulse"></span> <span class="full-word">Pulse</span>
        <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>    </li>

    <li class="tooltipped tooltipped-w" aria-label="Graphs">
      <a href="/jariz/vibrant.js/graphs" aria-label="Graphs" class="js-selected-navigation-item sunken-menu-item" data-selected-links="repo_graphs repo_contributors /jariz/vibrant.js/graphs">
        <span class="octicon octicon-graph"></span> <span class="full-word">Graphs</span>
        <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>    </li>
  </ul>


</nav>

              <div class="only-with-full-nav">
                  
<div class="js-clone-url clone-url open"
  data-protocol-type="http">
  <h3><span class="text-emphasized">HTTPS</span> clone URL</h3>
  <div class="input-group js-zeroclipboard-container">
    <input type="text" class="input-mini input-monospace js-url-field js-zeroclipboard-target"
           value="https://github.com/jariz/vibrant.js.git" readonly="readonly">
    <span class="input-group-button">
      <button aria-label="Copy to clipboard" class="js-zeroclipboard btn btn-sm zeroclipboard-button tooltipped tooltipped-s" data-copied-hint="Copied!" type="button"><span class="octicon octicon-clippy"></span></button>
    </span>
  </div>
</div>

  
<div class="js-clone-url clone-url "
  data-protocol-type="subversion">
  <h3><span class="text-emphasized">Subversion</span> checkout URL</h3>
  <div class="input-group js-zeroclipboard-container">
    <input type="text" class="input-mini input-monospace js-url-field js-zeroclipboard-target"
           value="https://github.com/jariz/vibrant.js" readonly="readonly">
    <span class="input-group-button">
      <button aria-label="Copy to clipboard" class="js-zeroclipboard btn btn-sm zeroclipboard-button tooltipped tooltipped-s" data-copied-hint="Copied!" type="button"><span class="octicon octicon-clippy"></span></button>
    </span>
  </div>
</div>



<div class="clone-options">You can clone with
  <form accept-charset="UTF-8" action="/users/set_protocol?protocol_selector=http&amp;protocol_type=clone" class="inline-form js-clone-selector-form " data-remote="true" method="post"><div style="margin:0;padding:0;display:inline"><input name="utf8" type="hidden" value="&#x2713;" /><input name="authenticity_token" type="hidden" value="t3dxc8b+qceNTCnO73D1nsCGnvwvuQ9140s+vKjiBVgzMy9yykGonbKaKI+KZmpjytHdB7wbrAfGH1cWio/6lw==" /></div><button class="btn-link js-clone-selector" data-protocol="http" type="submit">HTTPS</button></form> or <form accept-charset="UTF-8" action="/users/set_protocol?protocol_selector=subversion&amp;protocol_type=clone" class="inline-form js-clone-selector-form " data-remote="true" method="post"><div style="margin:0;padding:0;display:inline"><input name="utf8" type="hidden" value="&#x2713;" /><input name="authenticity_token" type="hidden" value="QDCRFOD/28HAaJ65AzfbIqvzRLnWOtfEDAJbGwSB9gsJIL/nPp73UT8w5fpoe0CvlxY5iNMlkOsHGBwXHLPOug==" /></div><button class="btn-link js-clone-selector" data-protocol="subversion" type="submit">Subversion</button></form>.
  <a href="https://help.github.com/articles/which-remote-url-should-i-use" class="help tooltipped tooltipped-n" aria-label="Get help on which URL is right for you.">
    <span class="octicon octicon-question"></span>
  </a>
</div>




                <a href="/jariz/vibrant.js/archive/master.zip"
                   class="btn btn-sm sidebar-button"
                   aria-label="Download the contents of jariz/vibrant.js as a zip file"
                   title="Download the contents of jariz/vibrant.js as a zip file"
                   rel="nofollow">
                  <span class="octicon octicon-cloud-download"></span>
                  Download ZIP
                </a>
              </div>
        </div><!-- /.repository-sidebar -->

        <div id="js-repo-pjax-container" class="repository-content context-loader-container" data-pjax-container>

          
<span id="js-show-full-navigation"></span>

<div class="repository-meta js-details-container ">
    <div class="repository-description">
      Extract prominent colors from an image. JS port of Android's Palette.
    </div>

    <div class="repository-website">
      <p><a href="http://jariz.github.io/vibrant.js/" rel="nofollow">http://jariz.github.io/vibrant.js/</a></p>
    </div>


</div>

<div class="overall-summary overall-summary-bottomless">

  <div class="stats-switcher-viewport js-stats-switcher-viewport">
    <div class="stats-switcher-wrapper">
    <ul class="numbers-summary">
      <li class="commits">
        <a data-pjax href="/jariz/vibrant.js/commits/master">
            <span class="octicon octicon-history"></span>
            <span class="num text-emphasized">
              11
            </span>
            commits
        </a>
      </li>
      <li>
        <a data-pjax href="/jariz/vibrant.js/branches">
          <span class="octicon octicon-git-branch"></span>
          <span class="num text-emphasized">
            2
          </span>
          branches
        </a>
      </li>

      <li>
        <a data-pjax href="/jariz/vibrant.js/releases">
          <span class="octicon octicon-tag"></span>
          <span class="num text-emphasized">
            1
          </span>
          release
        </a>
      </li>

      <li>
        
  <a href="/jariz/vibrant.js/graphs/contributors">
    <span class="octicon octicon-organization"></span>
    <span class="num text-emphasized">
      1
    </span>
    contributor
  </a>
      </li>
    </ul>

      <div class="repository-lang-stats">
        <ol class="repository-lang-stats-numbers">
          <li>
              <a href="/jariz/vibrant.js/search?l=javascript">
                <span class="color-block language-color" style="background-color:#f1e05a;"></span>
                <span class="lang">JavaScript</span>
                <span class="percent">61.2%</span>
              </a>
          </li>
          <li>
              <a href="/jariz/vibrant.js/search?l=coffeescript">
                <span class="color-block language-color" style="background-color:#244776;"></span>
                <span class="lang">CoffeeScript</span>
                <span class="percent">23.0%</span>
              </a>
          </li>
          <li>
              <a href="/jariz/vibrant.js/search?l=html">
                <span class="color-block language-color" style="background-color:#e44b23;"></span>
                <span class="lang">HTML</span>
                <span class="percent">14.9%</span>
              </a>
          </li>
        </ol>
      </div>
    </div>
  </div>

</div>

  <div class="repository-lang-stats-graph js-toggle-lang-stats" title="Click for language details">
    <span class="language-color" aria-label="JavaScript 61.2%" style="width:61.2%; background-color:#f1e05a;" itemprop="keywords">JavaScript</span>
    <span class="language-color" aria-label="CoffeeScript 23.0%" style="width:23.0%; background-color:#244776;" itemprop="keywords">CoffeeScript</span>
    <span class="language-color" aria-label="HTML 14.9%" style="width:14.9%; background-color:#e44b23;" itemprop="keywords">HTML</span>
  </div>

<include-fragment src="/jariz/vibrant.js/show_partial?partial=tree%2Frecently_touched_branches_list"></include-fragment>

<div class="file-navigation in-mid-page">
  <a href="/jariz/vibrant.js/find/master"
        class="js-show-file-finder btn btn-sm empty-icon tooltipped tooltipped-s right"
        data-pjax
        data-hotkey="t"
        aria-label="Quickly jump between files">
    <span class="octicon octicon-list-unordered"></span>
  </a>
    <a href="/jariz/vibrant.js/compare" aria-label="Compare, review, create a pull request" class="btn btn-sm btn-primary tooltipped tooltipped-se left compare-button" aria-label="Compare &amp; review" data-pjax data-ga-click="Repository, go to compare view, location:repo overview; icon:git-compare">
      <span class="octicon octicon-git-compare"></span>
    </a>

  
<div class="select-menu js-menu-container js-select-menu left">
  <span class="btn btn-sm select-menu-button js-menu-target css-truncate" data-hotkey="w"
    data-ref="master"
    title="master"
    role="button" aria-label="Switch branches or tags" tabindex="0" aria-haspopup="true">
    <span class="octicon octicon-git-branch"></span>
    <i>branch:</i>
    <span class="js-select-button css-truncate-target">master</span>
  </span>

  <div class="select-menu-modal-holder js-menu-content js-navigation-container" data-pjax aria-hidden="true">

    <div class="select-menu-modal">
      <div class="select-menu-header">
        <span class="select-menu-title">Switch branches/tags</span>
        <span class="octicon octicon-x js-menu-close" role="button" aria-label="Close"></span>
      </div>

      <div class="select-menu-filters">
        <div class="select-menu-text-filter">
          <input type="text" aria-label="Filter branches/tags" id="context-commitish-filter-field" class="js-filterable-field js-navigation-enable" placeholder="Filter branches/tags">
        </div>
        <div class="select-menu-tabs">
          <ul>
            <li class="select-menu-tab">
              <a href="#" data-tab-filter="branches" data-filter-placeholder="Filter branches/tags" class="js-select-menu-tab">Branches</a>
            </li>
            <li class="select-menu-tab">
              <a href="#" data-tab-filter="tags" data-filter-placeholder="Find a tag…" class="js-select-menu-tab">Tags</a>
            </li>
          </ul>
        </div>
      </div>

      <div class="select-menu-list select-menu-tab-bucket js-select-menu-tab-bucket" data-tab-filter="branches">

        <div data-filterable-for="context-commitish-filter-field" data-filterable-type="substring">


            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/jariz/vibrant.js/tree/gh-pages"
               data-name="gh-pages"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="gh-pages">
                gh-pages
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open selected"
               href="/jariz/vibrant.js/tree/master"
               data-name="master"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="master">
                master
              </span>
            </a>
        </div>

          <div class="select-menu-no-results">Nothing to show</div>
      </div>

      <div class="select-menu-list select-menu-tab-bucket js-select-menu-tab-bucket" data-tab-filter="tags">
        <div data-filterable-for="context-commitish-filter-field" data-filterable-type="substring">


            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/jariz/vibrant.js/tree/1.0"
                 data-name="1.0"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="1.0">1.0</a>
            </div>
        </div>

        <div class="select-menu-no-results">Nothing to show</div>
      </div>

    </div>
  </div>
</div>



  <div class="breadcrumb"><span class="repo-root js-repo-root"><span itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb"><a href="/jariz/vibrant.js" class="" data-branch="master" data-pjax="true" itemscope="url"><span itemprop="title">vibrant.js</span></a></span></span><span class="separator">/</span>
    <a class="btn-link disabled tooltipped tooltipped-e" href="#" aria-label="You must be signed in to make or propose changes">
      <span class="octicon octicon-plus"></span>
    </a>
</div>
</div>



  
  <div class="commit commit-tease js-details-container" >
    <p class="commit-title ">
        <a href="/jariz/vibrant.js/commit/736fa99974d6506a5c8b975016b2c1dcbee9341f" class="message" data-pjax="true" title="Add node-vibrant">Add node-vibrant</a>
        
    </p>
    <div class="commit-meta">
      <button aria-label="Copy SHA" class="js-zeroclipboard zeroclipboard-link tooltipped tooltipped-s" data-clipboard-text="736fa99974d6506a5c8b975016b2c1dcbee9341f" data-copied-hint="Copied!" type="button"><span class="octicon octicon-clippy"></span></button>
      <a href="/jariz/vibrant.js/commit/736fa99974d6506a5c8b975016b2c1dcbee9341f" class="sha-block" data-pjax>latest commit <span class="sha">736fa99974</span></a>

      <div class="authorship">
        <img alt="@jariz" class="avatar" height="20" src="https://avatars1.githubusercontent.com/u/1415847?v=3&amp;s=40" width="20" />
        <span class="author-name"><a href="/jariz" rel="author">jariz</a></span>
        authored <time class="updated" datetime="2015-06-04T15:03:32Z" is="relative-time">Jun 4, 2015</time>

      </div>
    </div>
  </div>

  
<div class="file-wrap">
  <a href="/jariz/vibrant.js/tree/736fa99974d6506a5c8b975016b2c1dcbee9341f" class="hidden js-permalink-shortcut" data-hotkey="y">Permalink</a>

  <table class="files" data-pjax>


    <tbody>
      <tr class="warning include-fragment-error">
        <td class="icon"><span class="octicon octicon-alert"></span></td>
        <td class="content" colspan="3">Failed to load latest commit information.</td>
      </tr>

        <tr>
          <td class="icon">
            <span class="octicon octicon-file-directory"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/jariz/vibrant.js/tree/master/dist" class="js-directory-link" id="2a6d07eef8b10b84129b42424ed99327-476e5e5af59fca5cea7a0715bbb346c92a310592" title="dist">dist</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/jariz/vibrant.js/commit/3629aaf520e38a1249e2b390ba48d5717804fd09" class="message" data-pjax="true" title="Add license, readme, compiled file, og tags, and all that jazz">Add license, readme, compiled file, og tags, and all that jazz</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2015-05-26T11:02:35Z" is="time-ago">May 26, 2015</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-directory"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/jariz/vibrant.js/tree/master/examples" class="js-directory-link" id="bfebe34154a0dfd9fc7b447fc9ed74e9-bbfa294733883bfc462e316eac6232c799f260a9" title="examples">examples</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/jariz/vibrant.js/commit/3629aaf520e38a1249e2b390ba48d5717804fd09" class="message" data-pjax="true" title="Add license, readme, compiled file, og tags, and all that jazz">Add license, readme, compiled file, og tags, and all that jazz</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2015-05-26T11:02:35Z" is="time-ago">May 26, 2015</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-directory"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/jariz/vibrant.js/tree/master/src" class="js-directory-link" id="25d902c24283ab8cfbac54dfa101ad31-4218fa220cf88a1eca3a03ac400b5388b8847841" title="src">src</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/jariz/vibrant.js/commit/050ef650f3bde8bf1b20c1efa26d1b01ac6e27c3" class="message" data-pjax="true" title="Add some more documentation, footer.
(cherry picked from commit ffce5c2)">Add some more documentation, footer.</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2015-05-25T22:51:18Z" is="time-ago">May 26, 2015</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/jariz/vibrant.js/blob/master/.gitignore" class="js-directory-link" id="a084b794bc0759e7a6b77810e01874f2-f66128b217416f006f6bcf4b41fc6eb15c44b13f" title=".gitignore">.gitignore</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/jariz/vibrant.js/commit/b992a709b2948d665092c7b0725c5d72cb143932" class="message" data-pjax="true" title="Initial">Initial</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2015-05-25T00:21:59Z" is="time-ago">May 25, 2015</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/jariz/vibrant.js/blob/master/LICENSE.md" class="js-directory-link" id="37854d19817c792316d481f5beb93cc7-a679ed75a026178096c0d5d47f349d14fabb7bc3" title="LICENSE.md">LICENSE.md</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/jariz/vibrant.js/commit/3629aaf520e38a1249e2b390ba48d5717804fd09" class="message" data-pjax="true" title="Add license, readme, compiled file, og tags, and all that jazz">Add license, readme, compiled file, og tags, and all that jazz</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2015-05-26T11:02:35Z" is="time-ago">May 26, 2015</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/jariz/vibrant.js/blob/master/README.md" class="js-directory-link" id="04c6e90faac2675aa89e2176d2eec7d8-22a3113a86bf7218c4c983b10c263c0261bc4c5e" title="README.md">README.md</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/jariz/vibrant.js/commit/736fa99974d6506a5c8b975016b2c1dcbee9341f" class="message" data-pjax="true" title="Add node-vibrant">Add node-vibrant</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2015-06-04T15:03:32Z" is="time-ago">Jun 4, 2015</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/jariz/vibrant.js/blob/master/bower.json" class="js-directory-link" id="0a08a7565aba4405282251491979bb6b-a9350ab929c72325e833627e4be0f0bc6bf1fbd5" title="bower.json">bower.json</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/jariz/vibrant.js/commit/3629aaf520e38a1249e2b390ba48d5717804fd09" class="message" data-pjax="true" title="Add license, readme, compiled file, og tags, and all that jazz">Add license, readme, compiled file, og tags, and all that jazz</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2015-05-26T11:02:35Z" is="time-ago">May 26, 2015</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/jariz/vibrant.js/blob/master/gulpfile.coffee" class="js-directory-link" id="97599b685e6282e123c02b0f1f23a51d-02b987259d9df14f6a8f4bd2e39730a3df9aa145" title="gulpfile.coffee">gulpfile.coffee</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/jariz/vibrant.js/commit/1df17e3c983b3939aae28387bc84a713c36bcf84" class="message" data-pjax="true" title="Change watch task to default">Change watch task to default</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2015-05-26T11:06:08Z" is="time-ago">May 26, 2015</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/jariz/vibrant.js/blob/master/index.html" class="js-directory-link" id="eacf331f0ffc35d4b482f1d15a887d3b-21893bf178d7eec7e69dba622afe8161188c9b07" title="index.html">index.html</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/jariz/vibrant.js/commit/3629aaf520e38a1249e2b390ba48d5717804fd09" class="message" data-pjax="true" title="Add license, readme, compiled file, og tags, and all that jazz">Add license, readme, compiled file, og tags, and all that jazz</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2015-05-26T11:02:35Z" is="time-ago">May 26, 2015</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/jariz/vibrant.js/blob/master/package.json" class="js-directory-link" id="b9cfc7f2cdf78a7f4b91a753d10865a2-9b227950dca1eed6892b257404fc89b69afffe49" title="package.json">package.json</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/jariz/vibrant.js/commit/5ba63546cf93ce2282a31225c18689ff1896344f" class="message" data-pjax="true" title="Fix #1">Fix</a> <a href="https://github.com/jariz/vibrant.js/issues/1" class="issue-link" title="del dependency not installed via npm">#1</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2015-05-27T09:43:47Z" is="time-ago">May 27, 2015</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/jariz/vibrant.js/blob/master/style.css" class="js-directory-link" id="da232d78aa810382f2dcdceae308ff8e-1dc4f18e139ede14c7e05380702af29fef30bbcf" title="style.css">style.css</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/jariz/vibrant.js/commit/050ef650f3bde8bf1b20c1efa26d1b01ac6e27c3" class="message" data-pjax="true" title="Add some more documentation, footer.
(cherry picked from commit ffce5c2)">Add some more documentation, footer.</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2015-05-25T22:51:18Z" is="time-ago">May 25, 2015</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/jariz/vibrant.js/blob/master/website.coffee" class="js-directory-link" id="5c2ffc192b52413a53b5cce7143eb6ba-d92c85a94e377cad212fa9294c017cd62dea2a78" title="website.coffee">website.coffee</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/jariz/vibrant.js/commit/e02b3191461b66f98324ec2b3d187e340f348a9a" class="message" data-pjax="true" title="Forgot to remove some parameters from createComparisonValue, increase quality, make sure images are not yet loaded on demo">Forgot to remove some parameters from createComparisonValue, increase…</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2015-05-25T10:44:41Z" is="time-ago">May 25, 2015</time></span>
          </td>
        </tr>
    </tbody>
  </table>

</div>


  <div id="readme" class="boxed-group flush clearfix announce instapaper_body md">
    <h3>
      <span class="octicon octicon-book"></span>
      README.md
    </h3>

    <article class="markdown-body entry-content" itemprop="mainContentOfPage"><h1><a id="user-content-vibrantjs" class="anchor" href="#vibrantjs" aria-hidden="true"><span class="octicon octicon-link"></span></a>Vibrant.js</h1>

<p>Extract prominent colors from an image.
Vibrant.js is a javascript port of the <a href="https://developer.android.com/reference/android/support/v7/graphics/Palette.html">awesome Palette class</a> in the Android support library.</p>

<p><a href="https://camo.githubusercontent.com/104d2ac9246e9eeeede83108ecdc35734a2f1421/68747470733a2f2f692e696d6775722e636f6d2f4178665437684d2e706e67" target="_blank"><img src="https://camo.githubusercontent.com/104d2ac9246e9eeeede83108ecdc35734a2f1421/68747470733a2f2f692e696d6775722e636f6d2f4178665437684d2e706e67" alt="" data-canonical-src="https://i.imgur.com/AxfT7hM.png" style="max-width:100%;"></a></p>

<h2><a id="user-content-demo--usage-docs" class="anchor" href="#demo--usage-docs" aria-hidden="true"><span class="octicon octicon-link"></span></a>Demo &amp; usage docs</h2>

<p>See the website: <a href="http://jariz.github.io/vibrant.js/">http://jariz.github.io/vibrant.js/</a></p>

<h2><a id="user-content-installing" class="anchor" href="#installing" aria-hidden="true"><span class="octicon octicon-link"></span></a>Installing</h2>

<h4><a id="user-content-bower" class="anchor" href="#bower" aria-hidden="true"><span class="octicon octicon-link"></span></a>Bower</h4>

<p><code>bower install vibrant</code></p>

<h4><a id="user-content-download" class="anchor" href="#download" aria-hidden="true"><span class="octicon octicon-link"></span></a>Download</h4>

<p>See our <a href="https://github.com/jariz/vibrant.js/releases/">releases</a></p>

<h4><a id="user-content-npm" class="anchor" href="#npm" aria-hidden="true"><span class="octicon octicon-link"></span></a>npm</h4>

<p><code>npm install node-vibrant</code><br>
This is a node compatible version made by <a href="https://github.com/akfish">AKFish</a>, <a href="https://github.com/akfish/node-vibrant">more info &amp; docs</a>.</p>

<h2><a id="user-content-building" class="anchor" href="#building" aria-hidden="true"><span class="octicon octicon-link"></span></a>Building</h2>

<ol>
<li><code>npm install</code></li>
<li><code>bower install</code></li>
<li>Compile gulpfile: <code>coffee -c gulpfile.coffee</code></li>
<li><code>gulp</code></li>
<li>Done. Optionally run <code>gulp watch</code> for automatic compiling.</li>
</ol>

<h2><a id="user-content-other-cool-stuff" class="anchor" href="#other-cool-stuff" aria-hidden="true"><span class="octicon octicon-link"></span></a>Other cool stuff</h2>

<p>Check out <a href="http://github.com/jariz/tabbie">Tabbie</a>, the fully customisable material new tab page, with all your favorite websites and services!  </p>

<p><a href="http://github.com/jariz/tabbie"><img src="https://cloud.githubusercontent.com/assets/1415847/7971420/f3dec05a-0a44-11e5-8ecb-fcac49e91f50.png" alt="" style="max-width:100%;"></a></p>
</article>
  </div>


        </div>

      </div><!-- /.repo-container -->
      <div class="modal-backdrop"></div>
    </div><!-- /.container -->
  </div><!-- /.site -->


    </div><!-- /.wrapper -->

      <div class="container">
  <div class="site-footer" role="contentinfo">
    <ul class="site-footer-links right">
        <li><a href="https://status.github.com/" data-ga-click="Footer, go to status, text:status">Status</a></li>
      <li><a href="https://developer.github.com" data-ga-click="Footer, go to api, text:api">API</a></li>
      <li><a href="https://training.github.com" data-ga-click="Footer, go to training, text:training">Training</a></li>
      <li><a href="https://shop.github.com" data-ga-click="Footer, go to shop, text:shop">Shop</a></li>
        <li><a href="https://github.com/blog" data-ga-click="Footer, go to blog, text:blog">Blog</a></li>
        <li><a href="https://github.com/about" data-ga-click="Footer, go to about, text:about">About</a></li>

    </ul>

    <a href="https://github.com" aria-label="Homepage">
      <span class="mega-octicon octicon-mark-github" title="GitHub"></span>
</a>
    <ul class="site-footer-links">
      <li>&copy; 2015 <span title="0.04864s from github-fe133-cp1-prd.iad.github.net">GitHub</span>, Inc.</li>
        <li><a href="https://github.com/site/terms" data-ga-click="Footer, go to terms, text:terms">Terms</a></li>
        <li><a href="https://github.com/site/privacy" data-ga-click="Footer, go to privacy, text:privacy">Privacy</a></li>
        <li><a href="https://github.com/security" data-ga-click="Footer, go to security, text:security">Security</a></li>
        <li><a href="https://github.com/contact" data-ga-click="Footer, go to contact, text:contact">Contact</a></li>
    </ul>
  </div>
</div>


    <div class="fullscreen-overlay js-fullscreen-overlay" id="fullscreen_overlay">
  <div class="fullscreen-container js-suggester-container">
    <div class="textarea-wrap">
      <textarea name="fullscreen-contents" id="fullscreen-contents" class="fullscreen-contents js-fullscreen-contents" placeholder=""></textarea>
      <div class="suggester-container">
        <div class="suggester fullscreen-suggester js-suggester js-navigation-container"></div>
      </div>
    </div>
  </div>
  <div class="fullscreen-sidebar">
    <a href="#" class="exit-fullscreen js-exit-fullscreen tooltipped tooltipped-w" aria-label="Exit Zen Mode">
      <span class="mega-octicon octicon-screen-normal"></span>
    </a>
    <a href="#" class="theme-switcher js-theme-switcher tooltipped tooltipped-w"
      aria-label="Switch themes">
      <span class="octicon octicon-color-mode"></span>
    </a>
  </div>
</div>



    

    <div id="ajax-error-message" class="flash flash-error">
      <span class="octicon octicon-alert"></span>
      <a href="#" class="octicon octicon-x flash-close js-ajax-error-dismiss" aria-label="Dismiss error"></a>
      Something went wrong with that request. Please try again.
    </div>


      <script crossorigin="anonymous" src="https://assets-cdn.github.com/assets/frameworks-447ce66a36506ebddc8e84b4e32a77f6062f3d3482e77dd21a77a01f0643ad98.js"></script>
      <script async="async" crossorigin="anonymous" src="https://assets-cdn.github.com/assets/github/index-273626d05f0daba1adb856ea6f9d82ff151f8b9f23a21044a761d2e2f843b354.js"></script>
      
      
  </body>
</html>

