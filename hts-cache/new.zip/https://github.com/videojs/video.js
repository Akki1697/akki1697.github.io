


<!DOCTYPE html>
<html lang="en" class="">
  <head prefix="og: http://ogp.me/ns# fb: http://ogp.me/ns/fb# object: http://ogp.me/ns/object# article: http://ogp.me/ns/article# profile: http://ogp.me/ns/profile#">
    <meta charset='utf-8'>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Language" content="en">
    
    
    <title>videojs/video.js · GitHub</title>
    <link rel="search" type="application/opensearchdescription+xml" href="/opensearch.xml" title="GitHub">
    <link rel="fluid-icon" href="https://github.com/fluidicon.png" title="GitHub">
    <link rel="apple-touch-icon" sizes="57x57" href="/apple-touch-icon-114.png">
    <link rel="apple-touch-icon" sizes="114x114" href="/apple-touch-icon-114.png">
    <link rel="apple-touch-icon" sizes="72x72" href="/apple-touch-icon-144.png">
    <link rel="apple-touch-icon" sizes="144x144" href="/apple-touch-icon-144.png">
    <meta property="fb:app_id" content="1401488693436528">

      <meta content="@github" name="twitter:site" /><meta content="summary" name="twitter:card" /><meta content="videojs/video.js" name="twitter:title" /><meta content="Video.js - open source HTML5 &amp;amp; Flash video player. Contribute to video.js development by creating an account on GitHub." name="twitter:description" /><meta content="https://avatars1.githubusercontent.com/u/3287189?v=3&amp;s=400" name="twitter:image:src" />
      <meta content="GitHub" property="og:site_name" /><meta content="object" property="og:type" /><meta content="https://avatars1.githubusercontent.com/u/3287189?v=3&amp;s=400" property="og:image" /><meta content="videojs/video.js" property="og:title" /><meta content="https://github.com/videojs/video.js" property="og:url" /><meta content="Video.js - open source HTML5 &amp; Flash video player. Contribute to video.js development by creating an account on GitHub." property="og:description" />
      <meta name="browser-stats-url" content="https://api.github.com/_private/browser/stats">
    <meta name="browser-errors-url" content="https://api.github.com/_private/browser/errors">
    <link rel="assets" href="https://assets-cdn.github.com/">
    
    <meta name="pjax-timeout" content="1000">
    

    <meta name="msapplication-TileImage" content="/windows-tile.png">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="selected-link" value="repo_source" data-pjax-transient>
      <meta name="google-analytics" content="UA-3769691-2">

    <meta content="collector.githubapp.com" name="octolytics-host" /><meta content="collector-cdn.github.com" name="octolytics-script-host" /><meta content="github" name="octolytics-app-id" /><meta content="783D1521:06C0:D21AB1:5571AB44" name="octolytics-dimension-request_id" />
    
    <meta content="Rails, view, files#disambiguate" name="analytics-event" />
    <meta class="js-ga-set" name="dimension1" content="Logged Out">
    <meta class="js-ga-set" name="dimension2" content="Header v3">
    <meta name="is-dotcom" content="true">
      <meta name="hostname" content="github.com">
    <meta name="user-login" content="">

    
    <link rel="icon" type="image/x-icon" href="https://assets-cdn.github.com/favicon.ico">


    <meta content="authenticity_token" name="csrf-param" />
<meta content="tMGYj3VcDW/klos/+zbvAKR9B4fYiP1xoWD169fuL3v/i6crR2OaXiZFMO0pO5OL+Xnqte5nJAS16h+q+jKKyQ==" name="csrf-token" />

    <link crossorigin="anonymous" href="https://assets-cdn.github.com/assets/github/index-6967b378b26829cc5a2ea2ad4209ff0af50f2a65057962219dc9dcf8942683f0.css" media="all" rel="stylesheet" />
    <link crossorigin="anonymous" href="https://assets-cdn.github.com/assets/github2/index-73bfe123ff406f4bf8959a28667410beaac1485e71c92d4725a3d7afc45fc4c5.css" media="all" rel="stylesheet" />
    
    


    <meta http-equiv="x-pjax-version" content="b2ca4753a2f40f3bd3d3d6fd0fe8b32e">

      
  <meta name="description" content="Video.js - open source HTML5 &amp; Flash video player. Contribute to video.js development by creating an account on GitHub.">
  <meta name="go-import" content="github.com/videojs/video.js git https://github.com/videojs/video.js.git">

  <meta content="3287189" name="octolytics-dimension-user_id" /><meta content="videojs" name="octolytics-dimension-user_login" /><meta content="667006" name="octolytics-dimension-repository_id" /><meta content="videojs/video.js" name="octolytics-dimension-repository_nwo" /><meta content="true" name="octolytics-dimension-repository_public" /><meta content="false" name="octolytics-dimension-repository_is_fork" /><meta content="667006" name="octolytics-dimension-repository_network_root_id" /><meta content="videojs/video.js" name="octolytics-dimension-repository_network_root_nwo" />
  <link href="https://github.com/videojs/video.js/commits/master.atom" rel="alternate" title="Recent Commits to video.js:master" type="application/atom+xml">

  </head>


  <body class="logged_out  env-production  vis-public">
    <a href="#start-of-content" tabindex="1" class="accessibility-aid js-skip-to-content">Skip to content</a>
    <div class="wrapper">
      
      
      


        
        <div class="header header-logged-out" role="banner">
  <div class="container clearfix">

    <a class="header-logo-wordmark" href="https://github.com/" data-ga-click="(Logged out) Header, go to homepage, icon:logo-wordmark">
      <span class="mega-octicon octicon-logo-github"></span>
    </a>

    <div class="header-actions" role="navigation">
        <a class="btn btn-primary" href="/join" data-ga-click="(Logged out) Header, clicked Sign up, text:sign-up">Sign up</a>
      <a class="btn" href="/login?return_to=%2Fvideojs%2Fvideo.js" data-ga-click="(Logged out) Header, clicked Sign in, text:sign-in">Sign in</a>
    </div>

    <div class="site-search repo-scope js-site-search" role="search">
      <form accept-charset="UTF-8" action="/videojs/video.js/search" class="js-site-search-form" data-global-search-url="/search" data-repo-search-url="/videojs/video.js/search" method="get"><div style="margin:0;padding:0;display:inline"><input name="utf8" type="hidden" value="&#x2713;" /></div>
  <label class="js-chromeless-input-container form-control">
    <div class="scope-badge">This repository</div>
    <input type="text"
      class="js-site-search-focus js-site-search-field is-clearable chromeless-input"
      data-hotkey="s"
      name="q"
      placeholder="Search"
      data-global-scope-placeholder="Search GitHub"
      data-repo-scope-placeholder="Search"
      tabindex="1"
      autocapitalize="off">
  </label>
</form>
    </div>

      <ul class="header-nav left" role="navigation">
          <li class="header-nav-item">
            <a class="header-nav-link" href="/explore" data-ga-click="(Logged out) Header, go to explore, text:explore">Explore</a>
          </li>
          <li class="header-nav-item">
            <a class="header-nav-link" href="/features" data-ga-click="(Logged out) Header, go to features, text:features">Features</a>
          </li>
          <li class="header-nav-item">
            <a class="header-nav-link" href="https://enterprise.github.com/" data-ga-click="(Logged out) Header, go to enterprise, text:enterprise">Enterprise</a>
          </li>
          <li class="header-nav-item">
            <a class="header-nav-link" href="/blog" data-ga-click="(Logged out) Header, go to blog, text:blog">Blog</a>
          </li>
      </ul>

  </div>
</div>



      <div id="start-of-content" class="accessibility-aid"></div>
          <div class="site" itemscope itemtype="http://schema.org/WebPage">
    <div id="js-flash-container">
      
    </div>
    <div class="pagehead repohead instapaper_ignore readability-menu">
      <div class="container">

        
<ul class="pagehead-actions">

  <li>
      <a href="/login?return_to=%2Fvideojs%2Fvideo.js"
    class="btn btn-sm btn-with-count tooltipped tooltipped-n"
    aria-label="You must be signed in to watch a repository" rel="nofollow">
    <span class="octicon octicon-eye"></span>
    Watch
  </a>
  <a class="social-count" href="/videojs/video.js/watchers">
    693
  </a>

  </li>

  <li>
      <a href="/login?return_to=%2Fvideojs%2Fvideo.js"
    class="btn btn-sm btn-with-count tooltipped tooltipped-n"
    aria-label="You must be signed in to star a repository" rel="nofollow">
    <span class="octicon octicon-star"></span>
    Star
  </a>

    <a class="social-count js-social-count" href="/videojs/video.js/stargazers">
      9,179
    </a>

  </li>

    <li>
      <a href="/login?return_to=%2Fvideojs%2Fvideo.js"
        class="btn btn-sm btn-with-count tooltipped tooltipped-n"
        aria-label="You must be signed in to fork a repository" rel="nofollow">
        <span class="octicon octicon-repo-forked"></span>
        Fork
      </a>
      <a href="/videojs/video.js/network" class="social-count">
        2,582
      </a>
    </li>
</ul>

        <h1 itemscope itemtype="http://data-vocabulary.org/Breadcrumb" class="entry-title public">
          <span class="mega-octicon octicon-repo"></span>
          <span class="author"><a href="/videojs" class="url fn" itemprop="url" rel="author"><span itemprop="title">videojs</span></a></span><!--
       --><span class="path-divider">/</span><!--
       --><strong><a href="/videojs/video.js" data-pjax="#js-repo-pjax-container">video.js</a></strong>

          <span class="page-context-loader">
            <img alt="" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </span>

        </h1>
      </div><!-- /.container -->
    </div><!-- /.repohead -->

    <div class="container">
      <div class="repository-with-sidebar repo-container new-discussion-timeline with-full-navigation ">
        <div class="repository-sidebar clearfix">
            
<nav class="sunken-menu repo-nav js-repo-nav js-sidenav-container-pjax js-octicon-loaders"
     role="navigation"
     data-pjax="#js-repo-pjax-container"
     data-issue-count-url="/videojs/video.js/issues/counts">
  <ul class="sunken-menu-group">
    <li class="tooltipped tooltipped-w" aria-label="Code">
      <a href="/videojs/video.js" aria-label="Code" class="selected js-selected-navigation-item sunken-menu-item" data-hotkey="g c" data-selected-links="repo_source repo_downloads repo_commits repo_releases repo_tags repo_branches /videojs/video.js">
        <span class="octicon octicon-code"></span> <span class="full-word">Code</span>
        <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>    </li>

      <li class="tooltipped tooltipped-w" aria-label="Issues">
        <a href="/videojs/video.js/issues" aria-label="Issues" class="js-selected-navigation-item sunken-menu-item" data-hotkey="g i" data-selected-links="repo_issues repo_labels repo_milestones /videojs/video.js/issues">
          <span class="octicon octicon-issue-opened"></span> <span class="full-word">Issues</span>
          <span class="js-issue-replace-counter"></span>
          <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>      </li>

    <li class="tooltipped tooltipped-w" aria-label="Pull requests">
      <a href="/videojs/video.js/pulls" aria-label="Pull requests" class="js-selected-navigation-item sunken-menu-item" data-hotkey="g p" data-selected-links="repo_pulls /videojs/video.js/pulls">
          <span class="octicon octicon-git-pull-request"></span> <span class="full-word">Pull requests</span>
          <span class="js-pull-replace-counter"></span>
          <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>    </li>

      <li class="tooltipped tooltipped-w" aria-label="Wiki">
        <a href="/videojs/video.js/wiki" aria-label="Wiki" class="js-selected-navigation-item sunken-menu-item" data-hotkey="g w" data-selected-links="repo_wiki /videojs/video.js/wiki">
          <span class="octicon octicon-book"></span> <span class="full-word">Wiki</span>
          <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>      </li>
  </ul>
  <div class="sunken-menu-separator"></div>
  <ul class="sunken-menu-group">

    <li class="tooltipped tooltipped-w" aria-label="Pulse">
      <a href="/videojs/video.js/pulse" aria-label="Pulse" class="js-selected-navigation-item sunken-menu-item" data-selected-links="pulse /videojs/video.js/pulse">
        <span class="octicon octicon-pulse"></span> <span class="full-word">Pulse</span>
        <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>    </li>

    <li class="tooltipped tooltipped-w" aria-label="Graphs">
      <a href="/videojs/video.js/graphs" aria-label="Graphs" class="js-selected-navigation-item sunken-menu-item" data-selected-links="repo_graphs repo_contributors /videojs/video.js/graphs">
        <span class="octicon octicon-graph"></span> <span class="full-word">Graphs</span>
        <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>    </li>
  </ul>


</nav>

              <div class="only-with-full-nav">
                  
<div class="js-clone-url clone-url open"
  data-protocol-type="http">
  <h3><span class="text-emphasized">HTTPS</span> clone URL</h3>
  <div class="input-group js-zeroclipboard-container">
    <input type="text" class="input-mini input-monospace js-url-field js-zeroclipboard-target"
           value="https://github.com/videojs/video.js.git" readonly="readonly">
    <span class="input-group-button">
      <button aria-label="Copy to clipboard" class="js-zeroclipboard btn btn-sm zeroclipboard-button tooltipped tooltipped-s" data-copied-hint="Copied!" type="button"><span class="octicon octicon-clippy"></span></button>
    </span>
  </div>
</div>

  
<div class="js-clone-url clone-url "
  data-protocol-type="subversion">
  <h3><span class="text-emphasized">Subversion</span> checkout URL</h3>
  <div class="input-group js-zeroclipboard-container">
    <input type="text" class="input-mini input-monospace js-url-field js-zeroclipboard-target"
           value="https://github.com/videojs/video.js" readonly="readonly">
    <span class="input-group-button">
      <button aria-label="Copy to clipboard" class="js-zeroclipboard btn btn-sm zeroclipboard-button tooltipped tooltipped-s" data-copied-hint="Copied!" type="button"><span class="octicon octicon-clippy"></span></button>
    </span>
  </div>
</div>



<div class="clone-options">You can clone with
  <form accept-charset="UTF-8" action="/users/set_protocol?protocol_selector=http&amp;protocol_type=clone" class="inline-form js-clone-selector-form " data-remote="true" method="post"><div style="margin:0;padding:0;display:inline"><input name="utf8" type="hidden" value="&#x2713;" /><input name="authenticity_token" type="hidden" value="drb1CjekSKFKfqUj5haLpwibaf3eMeZNtUytnd2lJjTBDIliaJ2P40qOsdpAYGS34VeeDz6fz5ua+/kTT0f+JQ==" /></div><button class="btn-link js-clone-selector" data-protocol="http" type="submit">HTTPS</button></form> or <form accept-charset="UTF-8" action="/users/set_protocol?protocol_selector=subversion&amp;protocol_type=clone" class="inline-form js-clone-selector-form " data-remote="true" method="post"><div style="margin:0;padding:0;display:inline"><input name="utf8" type="hidden" value="&#x2713;" /><input name="authenticity_token" type="hidden" value="cbMT7+iiBFuk2qCcysVIxUw7uThA4mOMrtA4qhDy8DfWsTi4qV5TQJ6C9k9kgOYfqRCCSVe5WJxyRFBCGlbw2g==" /></div><button class="btn-link js-clone-selector" data-protocol="subversion" type="submit">Subversion</button></form>.
  <a href="https://help.github.com/articles/which-remote-url-should-i-use" class="help tooltipped tooltipped-n" aria-label="Get help on which URL is right for you.">
    <span class="octicon octicon-question"></span>
  </a>
</div>




                <a href="/videojs/video.js/archive/master.zip"
                   class="btn btn-sm sidebar-button"
                   aria-label="Download the contents of videojs/video.js as a zip file"
                   title="Download the contents of videojs/video.js as a zip file"
                   rel="nofollow">
                  <span class="octicon octicon-cloud-download"></span>
                  Download ZIP
                </a>
              </div>
        </div><!-- /.repository-sidebar -->

        <div id="js-repo-pjax-container" class="repository-content context-loader-container" data-pjax-container>

          
<span id="js-show-full-navigation"></span>

<div class="repository-meta js-details-container ">
    <div class="repository-description">
      Video.js - open source HTML5 &amp; Flash video player
    </div>

    <div class="repository-website">
      <p><a href="http://www.videojs.com" rel="nofollow">http://www.videojs.com</a></p>
    </div>


</div>

<div class="overall-summary overall-summary-bottomless">

  <div class="stats-switcher-viewport js-stats-switcher-viewport">
    <div class="stats-switcher-wrapper">
    <ul class="numbers-summary">
      <li class="commits">
        <a data-pjax href="/videojs/video.js/commits/master">
            <span class="octicon octicon-history"></span>
            <span class="num text-emphasized">
              1,883
            </span>
            commits
        </a>
      </li>
      <li>
        <a data-pjax href="/videojs/video.js/branches">
          <span class="octicon octicon-git-branch"></span>
          <span class="num text-emphasized">
            10
          </span>
          branches
        </a>
      </li>

      <li>
        <a data-pjax href="/videojs/video.js/releases">
          <span class="octicon octicon-tag"></span>
          <span class="num text-emphasized">
            95
          </span>
          releases
        </a>
      </li>

      <li>
        
  <a href="/videojs/video.js/graphs/contributors">
    <span class="octicon octicon-organization"></span>
    <span class="num text-emphasized">
      162
    </span>
    contributors
  </a>
      </li>
    </ul>

      <div class="repository-lang-stats">
        <ol class="repository-lang-stats-numbers">
          <li>
              <a href="/videojs/video.js/search?l=javascript">
                <span class="color-block language-color" style="background-color:#f1e05a;"></span>
                <span class="lang">JavaScript</span>
                <span class="percent">94.5%</span>
              </a>
          </li>
          <li>
              <a href="/videojs/video.js/search?l=css">
                <span class="color-block language-color" style="background-color:#563d7c;"></span>
                <span class="lang">CSS</span>
                <span class="percent">5.2%</span>
              </a>
          </li>
          <li>
              <span class="other">
                <span class="color-block language-color" style="background-color:#ededed;"></span>
                <span class="lang">Other</span>
                <span class="percent">0.3%</span>
              </span>
          </li>
        </ol>
      </div>
    </div>
  </div>

</div>

  <div class="repository-lang-stats-graph js-toggle-lang-stats" title="Click for language details">
    <span class="language-color" aria-label="JavaScript 94.5%" style="width:94.5%; background-color:#f1e05a;" itemprop="keywords">JavaScript</span>
    <span class="language-color" aria-label="CSS 5.2%" style="width:5.2%; background-color:#563d7c;" itemprop="keywords">CSS</span>
    <span class="language-color" aria-label="Other 0.3%" style="width:0.3%; background-color:#ededed;" itemprop="keywords">Other</span>
  </div>

<include-fragment src="/videojs/video.js/show_partial?partial=tree%2Frecently_touched_branches_list"></include-fragment>

<div class="file-navigation in-mid-page">
  <a href="/videojs/video.js/find/master"
        class="js-show-file-finder btn btn-sm empty-icon tooltipped tooltipped-s right"
        data-pjax
        data-hotkey="t"
        aria-label="Quickly jump between files">
    <span class="octicon octicon-list-unordered"></span>
  </a>
    <a href="/videojs/video.js/compare" aria-label="Compare, review, create a pull request" class="btn btn-sm btn-primary tooltipped tooltipped-se left compare-button" aria-label="Compare &amp; review" data-pjax data-ga-click="Repository, go to compare view, location:repo overview; icon:git-compare">
      <span class="octicon octicon-git-compare"></span>
    </a>

  
<div class="select-menu js-menu-container js-select-menu left">
  <span class="btn btn-sm select-menu-button js-menu-target css-truncate" data-hotkey="w"
    data-ref="master"
    title="master"
    role="button" aria-label="Switch branches or tags" tabindex="0" aria-haspopup="true">
    <span class="octicon octicon-git-branch"></span>
    <i>branch:</i>
    <span class="js-select-button css-truncate-target">master</span>
  </span>

  <div class="select-menu-modal-holder js-menu-content js-navigation-container" data-pjax aria-hidden="true">

    <div class="select-menu-modal">
      <div class="select-menu-header">
        <span class="select-menu-title">Switch branches/tags</span>
        <span class="octicon octicon-x js-menu-close" role="button" aria-label="Close"></span>
      </div>

      <div class="select-menu-filters">
        <div class="select-menu-text-filter">
          <input type="text" aria-label="Filter branches/tags" id="context-commitish-filter-field" class="js-filterable-field js-navigation-enable" placeholder="Filter branches/tags">
        </div>
        <div class="select-menu-tabs">
          <ul>
            <li class="select-menu-tab">
              <a href="#" data-tab-filter="branches" data-filter-placeholder="Filter branches/tags" class="js-select-menu-tab">Branches</a>
            </li>
            <li class="select-menu-tab">
              <a href="#" data-tab-filter="tags" data-filter-placeholder="Find a tag…" class="js-select-menu-tab">Tags</a>
            </li>
          </ul>
        </div>
      </div>

      <div class="select-menu-list select-menu-tab-bucket js-select-menu-tab-bucket" data-tab-filter="branches">

        <div data-filterable-for="context-commitish-filter-field" data-filterable-type="substring">


            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/videojs/video.js/tree/bower-release"
               data-name="bower-release"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="bower-release">
                bower-release
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/videojs/video.js/tree/feature/hls"
               data-name="feature/hls"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="feature/hls">
                feature/hls
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/videojs/video.js/tree/feature/lib-changes"
               data-name="feature/lib-changes"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="feature/lib-changes">
                feature/lib-changes
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/videojs/video.js/tree/gh-pages"
               data-name="gh-pages"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="gh-pages">
                gh-pages
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open selected"
               href="/videojs/video.js/tree/master"
               data-name="master"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="master">
                master
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/videojs/video.js/tree/patch"
               data-name="patch"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="patch">
                patch
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/videojs/video.js/tree/release/4-1"
               data-name="release/4-1"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="release/4-1">
                release/4-1
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/videojs/video.js/tree/release/4.2.0"
               data-name="release/4.2.0"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="release/4.2.0">
                release/4.2.0
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/videojs/video.js/tree/revert-1974-feature/canhandlesource"
               data-name="revert-1974-feature/canhandlesource"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="revert-1974-feature/canhandlesource">
                revert-1974-feature/canhandlesource
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/videojs/video.js/tree/stable"
               data-name="stable"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="stable">
                stable
              </span>
            </a>
        </div>

          <div class="select-menu-no-results">Nothing to show</div>
      </div>

      <div class="select-menu-list select-menu-tab-bucket js-select-menu-tab-bucket" data-tab-filter="tags">
        <div data-filterable-for="context-commitish-filter-field" data-filterable-type="substring">


            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v5.0.0-30"
                 data-name="v5.0.0-30"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v5.0.0-30">v5.0.0-30</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v5.0.0-29"
                 data-name="v5.0.0-29"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v5.0.0-29">v5.0.0-29</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v5.0.0-28"
                 data-name="v5.0.0-28"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v5.0.0-28">v5.0.0-28</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v5.0.0-27"
                 data-name="v5.0.0-27"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v5.0.0-27">v5.0.0-27</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v5.0.0-26"
                 data-name="v5.0.0-26"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v5.0.0-26">v5.0.0-26</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v5.0.0-25"
                 data-name="v5.0.0-25"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v5.0.0-25">v5.0.0-25</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v5.0.0-24"
                 data-name="v5.0.0-24"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v5.0.0-24">v5.0.0-24</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v5.0.0-23"
                 data-name="v5.0.0-23"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v5.0.0-23">v5.0.0-23</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v5.0.0-22"
                 data-name="v5.0.0-22"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v5.0.0-22">v5.0.0-22</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v5.0.0-21"
                 data-name="v5.0.0-21"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v5.0.0-21">v5.0.0-21</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v5.0.0-20"
                 data-name="v5.0.0-20"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v5.0.0-20">v5.0.0-20</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v5.0.0-19"
                 data-name="v5.0.0-19"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v5.0.0-19">v5.0.0-19</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v5.0.0-18"
                 data-name="v5.0.0-18"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v5.0.0-18">v5.0.0-18</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v5.0.0-17"
                 data-name="v5.0.0-17"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v5.0.0-17">v5.0.0-17</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v5.0.0-16"
                 data-name="v5.0.0-16"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v5.0.0-16">v5.0.0-16</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v5.0.0-15"
                 data-name="v5.0.0-15"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v5.0.0-15">v5.0.0-15</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v5.0.0-14"
                 data-name="v5.0.0-14"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v5.0.0-14">v5.0.0-14</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v5.0.0-13"
                 data-name="v5.0.0-13"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v5.0.0-13">v5.0.0-13</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v5.0.0-12"
                 data-name="v5.0.0-12"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v5.0.0-12">v5.0.0-12</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v5.0.0-11"
                 data-name="v5.0.0-11"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v5.0.0-11">v5.0.0-11</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v5.0.0-10"
                 data-name="v5.0.0-10"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v5.0.0-10">v5.0.0-10</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v5.0.0-9"
                 data-name="v5.0.0-9"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v5.0.0-9">v5.0.0-9</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v5.0.0-8"
                 data-name="v5.0.0-8"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v5.0.0-8">v5.0.0-8</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v5.0.0-7"
                 data-name="v5.0.0-7"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v5.0.0-7">v5.0.0-7</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v5.0.0-6"
                 data-name="v5.0.0-6"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v5.0.0-6">v5.0.0-6</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v5.0.0-5"
                 data-name="v5.0.0-5"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v5.0.0-5">v5.0.0-5</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v5.0.0-4"
                 data-name="v5.0.0-4"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v5.0.0-4">v5.0.0-4</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v5.0.0-3"
                 data-name="v5.0.0-3"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v5.0.0-3">v5.0.0-3</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v5.0.0-2"
                 data-name="v5.0.0-2"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v5.0.0-2">v5.0.0-2</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v5.0.0-1"
                 data-name="v5.0.0-1"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v5.0.0-1">v5.0.0-1</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v4.12.7"
                 data-name="v4.12.7"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v4.12.7">v4.12.7</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v4.12.6"
                 data-name="v4.12.6"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v4.12.6">v4.12.6</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v4.12.5"
                 data-name="v4.12.5"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v4.12.5">v4.12.5</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v4.12.4"
                 data-name="v4.12.4"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v4.12.4">v4.12.4</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v4.12.3"
                 data-name="v4.12.3"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v4.12.3">v4.12.3</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v4.12.2"
                 data-name="v4.12.2"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v4.12.2">v4.12.2</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v4.12.1"
                 data-name="v4.12.1"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v4.12.1">v4.12.1</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v4.12.0"
                 data-name="v4.12.0"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v4.12.0">v4.12.0</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v4.11.4"
                 data-name="v4.11.4"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v4.11.4">v4.11.4</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v4.11.3"
                 data-name="v4.11.3"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v4.11.3">v4.11.3</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v4.11.2"
                 data-name="v4.11.2"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v4.11.2">v4.11.2</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v4.11.1"
                 data-name="v4.11.1"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v4.11.1">v4.11.1</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v4.11.0"
                 data-name="v4.11.0"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v4.11.0">v4.11.0</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v4.10.2"
                 data-name="v4.10.2"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v4.10.2">v4.10.2</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v4.10.1"
                 data-name="v4.10.1"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v4.10.1">v4.10.1</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v4.10.0"
                 data-name="v4.10.0"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v4.10.0">v4.10.0</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v4.9.1"
                 data-name="v4.9.1"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v4.9.1">v4.9.1</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v4.9.0"
                 data-name="v4.9.0"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v4.9.0">v4.9.0</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v4.8.5"
                 data-name="v4.8.5"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v4.8.5">v4.8.5</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v4.8.4"
                 data-name="v4.8.4"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v4.8.4">v4.8.4</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v4.8.3"
                 data-name="v4.8.3"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v4.8.3">v4.8.3</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v4.8.2"
                 data-name="v4.8.2"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v4.8.2">v4.8.2</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v4.8.1"
                 data-name="v4.8.1"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v4.8.1">v4.8.1</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v4.8.0"
                 data-name="v4.8.0"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v4.8.0">v4.8.0</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v4.7.3"
                 data-name="v4.7.3"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v4.7.3">v4.7.3</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v4.7.2"
                 data-name="v4.7.2"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v4.7.2">v4.7.2</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v4.7.1"
                 data-name="v4.7.1"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v4.7.1">v4.7.1</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v4.7.0"
                 data-name="v4.7.0"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v4.7.0">v4.7.0</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v4.6.4"
                 data-name="v4.6.4"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v4.6.4">v4.6.4</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v4.6.3"
                 data-name="v4.6.3"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v4.6.3">v4.6.3</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v4.6.2"
                 data-name="v4.6.2"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v4.6.2">v4.6.2</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v4.6.1"
                 data-name="v4.6.1"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v4.6.1">v4.6.1</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v4.6.0"
                 data-name="v4.6.0"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v4.6.0">v4.6.0</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v4.5.2"
                 data-name="v4.5.2"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v4.5.2">v4.5.2</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v4.5.1"
                 data-name="v4.5.1"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v4.5.1">v4.5.1</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v4.5.0"
                 data-name="v4.5.0"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v4.5.0">v4.5.0</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v4.4.3"
                 data-name="v4.4.3"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v4.4.3">v4.4.3</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v4.4.2"
                 data-name="v4.4.2"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v4.4.2">v4.4.2</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v4.4.1"
                 data-name="v4.4.1"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v4.4.1">v4.4.1</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v4.4.0"
                 data-name="v4.4.0"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v4.4.0">v4.4.0</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v4.3.0"
                 data-name="v4.3.0"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v4.3.0">v4.3.0</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v4.2.2"
                 data-name="v4.2.2"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v4.2.2">v4.2.2</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v4.2.1"
                 data-name="v4.2.1"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v4.2.1">v4.2.1</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v4.2.0"
                 data-name="v4.2.0"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v4.2.0">v4.2.0</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v4.1.0"
                 data-name="v4.1.0"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v4.1.0">v4.1.0</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v4.0.4"
                 data-name="v4.0.4"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v4.0.4">v4.0.4</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v4.0.3"
                 data-name="v4.0.3"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v4.0.3">v4.0.3</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v4.0.2"
                 data-name="v4.0.2"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v4.0.2">v4.0.2</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v4.0.1"
                 data-name="v4.0.1"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v4.0.1">v4.0.1</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v3.0b"
                 data-name="v3.0b"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v3.0b">v3.0b</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/v2.0.3"
                 data-name="v2.0.3"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v2.0.3">v2.0.3</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/4.0.1"
                 data-name="4.0.1"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="4.0.1">4.0.1</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/4.0.0"
                 data-name="4.0.0"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="4.0.0">4.0.0</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/3.2.3"
                 data-name="3.2.3"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="3.2.3">3.2.3</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/3.2.2"
                 data-name="3.2.2"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="3.2.2">3.2.2</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/3.2.1"
                 data-name="3.2.1"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="3.2.1">3.2.1</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/3.2.0"
                 data-name="3.2.0"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="3.2.0">3.2.0</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/3.1.0"
                 data-name="3.1.0"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="3.1.0">3.1.0</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/3.0r1"
                 data-name="3.0r1"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="3.0r1">3.0r1</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/3.0.8"
                 data-name="3.0.8"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="3.0.8">3.0.8</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/3.0.7"
                 data-name="3.0.7"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="3.0.7">3.0.7</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/3.0.6"
                 data-name="3.0.6"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="3.0.6">3.0.6</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/3.0.5"
                 data-name="3.0.5"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="3.0.5">3.0.5</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/3.0.4"
                 data-name="3.0.4"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="3.0.4">3.0.4</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/videojs/video.js/tree/3.0.3"
                 data-name="3.0.3"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="3.0.3">3.0.3</a>
            </div>
        </div>

        <div class="select-menu-no-results">Nothing to show</div>
      </div>

    </div>
  </div>
</div>



  <div class="breadcrumb"><span class="repo-root js-repo-root"><span itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb"><a href="/videojs/video.js" class="" data-branch="master" data-pjax="true" itemscope="url"><span itemprop="title">video.js</span></a></span></span><span class="separator">/</span>
    <a class="btn-link disabled tooltipped tooltipped-e" href="#" aria-label="You must be signed in to make or propose changes">
      <span class="octicon octicon-plus"></span>
    </a>
</div>
</div>



  
  <div class="commit commit-tease js-details-container" >
    <p class="commit-title ">
        <a href="/videojs/video.js/commit/3a0f14728e2ac72215350ee1b68a1de2ea36856f" class="message" data-pjax="true" title="v5.0.0-30">v5.0.0-30</a>
        
    </p>
    <div class="commit-meta">
      <button aria-label="Copy SHA" class="js-zeroclipboard zeroclipboard-link tooltipped tooltipped-s" data-clipboard-text="3a0f14728e2ac72215350ee1b68a1de2ea36856f" data-copied-hint="Copied!" type="button"><span class="octicon octicon-clippy"></span></button>
      <a href="/videojs/video.js/commit/3a0f14728e2ac72215350ee1b68a1de2ea36856f" class="sha-block" data-pjax>latest commit <span class="sha">3a0f14728e</span></a>

      <div class="authorship">
        <img alt="@heff" class="avatar" height="20" src="https://avatars0.githubusercontent.com/u/166?v=3&amp;s=40" width="20" />
        <span class="author-name"><a href="/heff" rel="contributor">heff</a></span>
        authored <time class="updated" datetime="2015-06-05T00:39:39Z" is="relative-time">Jun 5, 2015</time>

      </div>
    </div>
  </div>

  
<div class="file-wrap">
  <a href="/videojs/video.js/tree/3a0f14728e2ac72215350ee1b68a1de2ea36856f" class="hidden js-permalink-shortcut" data-hotkey="y">Permalink</a>

  <table class="files" data-pjax>


    <tbody>
      <tr class="warning include-fragment-error">
        <td class="icon"><span class="octicon octicon-alert"></span></td>
        <td class="content" colspan="3">Failed to load latest commit information.</td>
      </tr>

        <tr>
          <td class="icon">
            <span class="octicon octicon-file-directory"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/videojs/video.js/tree/master/build" class="js-directory-link" id="b0da275520918e23dd615e2a747528f1-5e754d9cd5a0402684fd0b90fb6228044711479f" title="build">build</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/videojs/video.js/commit/d8e7d13fd09ca3209e9089def6e4fcdb2fcd63af" class="message" data-pjax="true" title="build: Updated test configuration for new Savage testing">build: Updated test configuration for new Savage testing</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2015-05-12T21:05:08Z" is="time-ago">May 12, 2015</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-directory"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/videojs/video.js/tree/master/docs" class="js-directory-link" id="e3e2a9bfd88566b05001b02a3f51d286-4ca3e9278585c9b7d198e834a172762b46b26a5c" title="docs">docs</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/videojs/video.js/commit/6b2dca32fc4b07a73cfca122f6b2266dc3c98a56" class="message" data-pjax="true" title="Normalise lang codes to lowercase for insensitive match

Use primary code (&#39;en&#39;) if specific code (&#39;en-us&#39;) doesn not match
Always re-merge languages

closes #2177

Updated language function to lowercase internally

Updated component.localize to not require stubbing">Normalise lang codes to lowercase for insensitive match</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2015-05-22T00:07:13Z" is="time-ago">May 21, 2015</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-directory"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/videojs/video.js/tree/master/lang" class="js-directory-link" id="7572559ca86e781ba8fe8073a0b725c6-c5e912d70d28f3cd38eebe997f61b1837d561eef" title="lang">lang</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/videojs/video.js/commit/4805e41ee05b5b0474a67d608b3bf0f7d39d9e75" class="message" data-pjax="true" title="Merge pull request #1927 from juniorlisboa/master

Legend in pt-Br is wrong.">Merge pull request</a> <a href="https://github.com/videojs/video.js/pull/1927" class="issue-link" title="Legend in pt-Br is wrong.">#1927</a> <a href="/videojs/video.js/commit/4805e41ee05b5b0474a67d608b3bf0f7d39d9e75" class="message" data-pjax="true" title="Merge pull request #1927 from juniorlisboa/master

Legend in pt-Br is wrong.">from juniorlisboa/master</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2015-03-30T19:47:21Z" is="time-ago">Mar 30, 2015</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-directory"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/videojs/video.js/tree/master/sandbox" class="js-directory-link" id="93bc63e0b4f48fbbff568d9fc0dc3def-ca1af4fe96f6786668839828451368aebe4cf917" title="sandbox">sandbox</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/videojs/video.js/commit/6ad6d17efbf8aaa6544e6b96b7a8b3ba7dc1b4b4" class="message" data-pjax="true" title="small fix in instruction in sandbox doc">small fix in instruction in sandbox doc</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2015-05-29T14:01:44Z" is="time-ago">May 29, 2015</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-directory"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/videojs/video.js/tree/master/src" class="js-directory-link" id="25d902c24283ab8cfbac54dfa101ad31-86750e4fd00050f6cd81a5a0abdb93d7ec3327e8" title="src">src</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/videojs/video.js/commit/040410122ff872679cd4f7cbf6d9b18d66a0fe39" class="message" data-pjax="true" title="Merge pull request #2218 from mmcc/ie10-flex-check

added IE10 flex support check">Merge pull request</a> <a href="https://github.com/videojs/video.js/pull/2218" class="issue-link" title="added IE10 flex support check">#2218</a> <a href="/videojs/video.js/commit/040410122ff872679cd4f7cbf6d9b18d66a0fe39" class="message" data-pjax="true" title="Merge pull request #2218 from mmcc/ie10-flex-check

added IE10 flex support check">from mmcc/ie10-flex-check</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2015-06-05T00:37:50Z" is="time-ago">Jun 4, 2015</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-directory"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/videojs/video.js/tree/master/test" class="js-directory-link" id="098f6bcd4621d373cade4e832627b4f6-e3d7ce5d0fd4f7ff0810670badffe162d73508e9" title="test">test</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="https://github.com/mmcc" class="user-mention">@mmcc</a> <a href="/videojs/video.js/commit/42f00f2bfc231c870f37edfedfc697497c9dd7c0" class="message" data-pjax="true" title="@mmcc deprecated the options() function and removed internal uses. closes #2229">deprecated the options() function and removed internal uses. cl…</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2015-06-05T00:33:34Z" is="time-ago">Jun 4, 2015</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/videojs/video.js/blob/master/.editorconfig" class="js-directory-link" id="1e70daafb475c0ce3fef7d2728279182-d36ec32119e2a1dbf10726a331223cddefc6001f" title=".editorconfig">.editorconfig</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/videojs/video.js/commit/55d02cf6d87caea72edd2c383d72ac658bf6b888" class="message" data-pjax="true" title="Added .editorconfig and travis CI badge">Added .editorconfig and travis CI badge</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2012-12-11T22:33:42Z" is="time-ago">Dec 11, 2012</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/videojs/video.js/blob/master/.gitignore" class="js-directory-link" id="a084b794bc0759e7a6b77810e01874f2-4f3d583204ed4b38b52739cb4031abe43abcd6fa" title=".gitignore">.gitignore</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/videojs/video.js/commit/dcb24ce744c258c6709d3e2bad28b1684ca2429a" class="message" data-pjax="true" title="Removing dist again in favor of some dark git magic">Removing dist again in favor of some dark git magic</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2015-04-29T18:09:17Z" is="time-ago">Apr 29, 2015</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/videojs/video.js/blob/master/.jshintrc" class="js-directory-link" id="4d5aa81bf4f18104bb6ea53a8b5d1f43-9487b85dc0109b30ea0d07f8e49af19294d92647" title=".jshintrc">.jshintrc</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="https://github.com/eXon" class="user-mention">@eXon</a> <a href="/videojs/video.js/commit/e5595b1e38d0aa7c26bb2494e95995afe8ab83e9" class="message" data-pjax="true" title="@eXon began Tech 2.0 work, improved how tech events are handled by the player. closes #2057

closes #1485">began Tech 2.0 work, improved how tech events are handled by th…</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2015-05-06T18:02:01Z" is="time-ago">May 6, 2015</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/videojs/video.js/blob/master/.npmignore" class="js-directory-link" id="0fd4ef892d9d4990033701887c2f9bcc-c8b074852c0b2013b09df5564a51a413ec046b36" title=".npmignore">.npmignore</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/videojs/video.js/commit/cc5e515360961a769cdec05a58f2c98004d6d936" class="message" data-pjax="true" title="Use .npmignore to package a smaller subset of videojs for distribution. Make sure to include the video-js.less file for the designer to use.">Use .npmignore to package a smaller subset of videojs for distributio…</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2014-03-04T14:50:58Z" is="time-ago">Mar 4, 2014</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/videojs/video.js/blob/master/.travis.yml" class="js-directory-link" id="354f30a63fb0907d4ad57269548329e3-3e31a08e9d6ec9acc34364304dbe93cdd06dc5f7" title=".travis.yml">.travis.yml</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/videojs/video.js/commit/4a62ebb04202884068f2f2d909223cbf50d225f6" class="message" data-pjax="true" title="Added travis vars for sauce testing">Added travis vars for sauce testing</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2015-05-12T20:15:24Z" is="time-ago">May 12, 2015</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/videojs/video.js/blob/master/CHANGELOG.md" class="js-directory-link" id="4ac32a78649ca5bdd8e0ba38b7006a1e-ed1a296d664108b2328ed94c124fc2856ff84543" title="CHANGELOG.md">CHANGELOG.md</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="https://github.com/mmcc" class="user-mention">@mmcc</a> <a href="/videojs/video.js/commit/42f00f2bfc231c870f37edfedfc697497c9dd7c0" class="message" data-pjax="true" title="@mmcc deprecated the options() function and removed internal uses. closes #2229">deprecated the options() function and removed internal uses. cl…</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2015-06-05T00:33:34Z" is="time-ago">Jun 5, 2015</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/videojs/video.js/blob/master/CONTRIBUTING.md" class="js-directory-link" id="6a3371457528722a734f3c51d9238c13-50f87fd73148288b862f85083d58b64dfe99d23f" title="CONTRIBUTING.md">CONTRIBUTING.md</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/videojs/video.js/commit/b2c3e2d759a8fe59c59f26470e925eaa84739598" class="message" data-pjax="true" title="Delete the duplicated &#39;a&#39;">Delete the duplicated 'a'</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2014-12-24T09:02:04Z" is="time-ago">Dec 24, 2014</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/videojs/video.js/blob/master/Gruntfile.js" class="js-directory-link" id="35b4a816e0441e6a375cd925af50752c-9ec0365133d3aecf40780bdcd7c989d4a0dc23ff" title="Gruntfile.js">Gruntfile.js</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/videojs/video.js/commit/90b2f5d6ac3f13eb67a959e58d0973037a0f722b" class="message" data-pjax="true" title="build: @gkatsev updated the Gruntfile to use ES6. closes #2106">build:</a> <a href="https://github.com/gkatsev" class="user-mention">@gkatsev</a> <a href="/videojs/video.js/commit/90b2f5d6ac3f13eb67a959e58d0973037a0f722b" class="message" data-pjax="true" title="build: @gkatsev updated the Gruntfile to use ES6. closes #2106">updated the Gruntfile to use ES6. closes</a> <a href="https://github.com/videojs/video.js/pull/2106" class="issue-link" title="Babelify grunt">#2106</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2015-05-01T19:54:31Z" is="time-ago">May 1, 2015</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/videojs/video.js/blob/master/LICENSE" class="js-directory-link" id="9879d6db96fd29134fc802214163b95a-8a7f05ff3c663cec554a48d37040f7cb3f2de6bb" title="LICENSE">LICENSE</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/videojs/video.js/commit/6e5fc8d687b43ca60082b06ae2f5eb02b59c17f6" class="message" data-pjax="true" title="More build and testing cleanup. Also some reorganization.">More build and testing cleanup. Also some reorganization.</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2015-04-02T18:33:51Z" is="time-ago">Apr 2, 2015</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/videojs/video.js/blob/master/README.md" class="js-directory-link" id="04c6e90faac2675aa89e2176d2eec7d8-7484b4de7b071a0b21ee13eeb4350e0b90321a19" title="README.md">README.md</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/videojs/video.js/commit/b4fbdc24d5b72a3561b2356f15eadac5ede4e419" class="message" data-pjax="true" title="update copyright">update copyright</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2015-04-28T22:14:05Z" is="time-ago">Apr 28, 2015</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/videojs/video.js/blob/master/bower.json" class="js-directory-link" id="0a08a7565aba4405282251491979bb6b-9993d4c33c0203caf78170612024650b03c057f8" title="bower.json">bower.json</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/videojs/video.js/commit/2bf0be72f3b1a3bd5b8421bb5ccda7dae6cf13cc" class="message" data-pjax="true" title="build: bower.json: remove moot `version` field

Per https://github.com/bower/bower.json-spec/commit/a325da3d79baab018c572d75dc1781b12322f6cd

closes #2144

bower.json: main: fix path to video.js

bower.json: main: video-js.css =&gt; video-js.scss

Per https://github.com/bower/bower.json-spec/pull/43 :
&gt; Use source files with module exports and imports over pre-built distribution files.

Also, the example in that PR includes
/sass/motion.scss in and excludes
/dist/movement.css &amp; /dist/movement.min.css
from its `main`.

bower.json: Set moduleType &amp; use non-dist video.js

Again, see https://github.com/bower/bower.json-spec/pull/43">build: bower.json: remove moot `version` field</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2015-05-14T05:59:22Z" is="time-ago">May 13, 2015</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/videojs/video.js/blob/master/component.json" class="js-directory-link" id="162d38b326426c84ac91e51f931105bb-4a7c4222c1e2c0fd43e4b75ca74c3772c49589e4" title="component.json">component.json</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/videojs/video.js/commit/3a0f14728e2ac72215350ee1b68a1de2ea36856f" class="message" data-pjax="true" title="v5.0.0-30">v5.0.0-30</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2015-06-05T00:39:39Z" is="time-ago">Jun 5, 2015</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/videojs/video.js/blob/master/composer.json" class="js-directory-link" id="b5d0ee8c97c7abd7e3fa29b9a27d1780-2b91423f09fec0e84e5dd711e9a289c696cdd066" title="composer.json">composer.json</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/videojs/video.js/commit/8a05aa11a13eeccffaff39d5579214c908b8aa13" class="message" data-pjax="true" title="Added a composer.json for PHP packages. closes #1241">Added a composer.json for PHP packages. closes</a> <a href="https://github.com/videojs/video.js/pull/1241" class="issue-link" title="Create composer.json">#1241</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2014-06-14T00:01:11Z" is="time-ago">Jun 13, 2014</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/videojs/video.js/blob/master/contrib.json" class="js-directory-link" id="7e451665c8c6834ff419e918026455cd-c7198393a7d4859da45a2508ed216e86400581aa" title="contrib.json">contrib.json</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/videojs/video.js/commit/cba2c54fb66041b4731d9e4e9ebf20184c15e28d" class="message" data-pjax="true" title="Fixed prerelease task to update master">Fixed prerelease task to update master</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2015-04-30T21:27:44Z" is="time-ago">Apr 30, 2015</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/videojs/video.js/blob/master/grunt.js" class="js-directory-link" id="86e2cde74e147ea63f39fd9f2a8772ae-85f4314877d1079fa68952403abacaf51330b166" title="grunt.js">grunt.js</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="https://github.com/mmcc" class="user-mention">@mmcc</a> <a href="/videojs/video.js/commit/dac91a7b7bb92b283015da62a52a2f2f3a709c46" class="message" data-pjax="true" title="@mmcc moved the fonts into their own repo. closes #2223">moved the fonts into their own repo. closes</a> <a href="https://github.com/videojs/video.js/pull/2223" class="issue-link" title="Move fonts out of core repo">#2223</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2015-06-02T18:04:40Z" is="time-ago">Jun 2, 2015</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/videojs/video.js/blob/master/package.json" class="js-directory-link" id="b9cfc7f2cdf78a7f4b91a753d10865a2-de432d32a33f05dc8dd41cb5844236445e7a6a70" title="package.json">package.json</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/videojs/video.js/commit/3a0f14728e2ac72215350ee1b68a1de2ea36856f" class="message" data-pjax="true" title="v5.0.0-30">v5.0.0-30</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2015-06-05T00:39:39Z" is="time-ago">Jun 5, 2015</time></span>
          </td>
        </tr>
    </tbody>
  </table>

</div>


  <div id="readme" class="boxed-group flush clearfix announce instapaper_body md">
    <h3>
      <span class="octicon octicon-book"></span>
      README.md
    </h3>

    <article class="markdown-body entry-content" itemprop="mainContentOfPage"><h2><a id="user-content-please-note" class="anchor" href="#please-note" aria-hidden="true"><span class="octicon octicon-link"></span></a>Please Note!</h2>

<p>The master branch is now the development branch for 5.0 and should be considered unstable until the first 5.0 release. If you're looking for the most recent stable release, please refer to the <a href="https://github.com/videojs/video.js/tree/stable">stable branch</a>.</p>

<p><a href="https://camo.githubusercontent.com/71b8c791a7921951f227f7c6457a283912c714e8/68747470733a2f2f692e636c6f756475702e636f6d2f43336e41555a2d6c34632e706e67" target="_blank"><img src="https://camo.githubusercontent.com/71b8c791a7921951f227f7c6457a283912c714e8/68747470733a2f2f692e636c6f756475702e636f6d2f43336e41555a2d6c34632e706e67" alt="Video.js logo" data-canonical-src="https://i.cloudup.com/C3nAUZ-l4c.png" style="max-width:100%;"></a></p>

<h1><a id="user-content-videojs---html5-video-player--" class="anchor" href="#videojs---html5-video-player--" aria-hidden="true"><span class="octicon octicon-link"></span></a><a href="http://videojs.com">Video.js - HTML5 Video Player</a>  <a href="https://travis-ci.org/videojs/video.js"><img src="https://camo.githubusercontent.com/b2a79233000987153e6986f756097925877cbcb5/68747470733a2f2f7472617669732d63692e6f72672f766964656f6a732f766964656f2e6a732e7376673f6272616e63683d6d6173746572" alt="Build Status" data-canonical-src="https://travis-ci.org/videojs/video.js.svg?branch=master" style="max-width:100%;"></a></h1>

<blockquote>
<p>Video.js is a web video player built from the ground up for an HTML5 world. It supports HTML5 and Flash video, as well as YouTube and Vimeo (through <a href="https://github.com/videojs/video.js/wiki/Plugins">plugins</a>). It supports video playback on desktops and mobile devices. This project was started mid 2010, and the player is now used on over <del>50,000</del> 100,000 websites.</p>
</blockquote>

<h2><a id="user-content-quick-start" class="anchor" href="#quick-start" aria-hidden="true"><span class="octicon octicon-link"></span></a>Quick start</h2>

<p>Thanks to the awesome folks over at <a href="http://www.fastly.com/">Fastly</a>, there's a free, CDN hosted version of Video.js that anyone can use. Simply add these includes to your document's
<code>&lt;head&gt;</code>:</p>

<div class="highlight highlight-html"><pre>&lt;<span class="pl-ent">link</span> <span class="pl-e">href</span>=<span class="pl-s"><span class="pl-pds">"</span>http://vjs.zencdn.net/4.12/video-js.css<span class="pl-pds">"</span></span> <span class="pl-e">rel</span>=<span class="pl-s"><span class="pl-pds">"</span>stylesheet<span class="pl-pds">"</span></span>&gt;
&lt;<span class="pl-ent">script</span> <span class="pl-e">src</span>=<span class="pl-s"><span class="pl-pds">"</span>http://vjs.zencdn.net/4.12/video.js<span class="pl-pds">"</span></span>&gt;&lt;/<span class="pl-ent">script</span>&gt;</pre></div>

<p>Then, whenever you want to use Video.js you can simply use the <code>&lt;video&gt;</code> element as your normally would, but with an additional <code>data-setup</code> attribute containing any Video.js options. These options
can include any Video.js option plus potential <a href="https://github.com/videojs/video.js/wiki/Plugins">plugin</a> options, just make sure they're valid JSON!</p>

<div class="highlight highlight-html"><pre>&lt;<span class="pl-ent">video</span> <span class="pl-e">id</span>=<span class="pl-s"><span class="pl-pds">"</span>really-cool-video<span class="pl-pds">"</span></span> <span class="pl-e">class</span>=<span class="pl-s"><span class="pl-pds">"</span>video-js vjs-default-skin<span class="pl-pds">"</span></span> <span class="pl-e">controls</span>
 <span class="pl-e">preload</span>=<span class="pl-s"><span class="pl-pds">"</span>auto<span class="pl-pds">"</span></span> <span class="pl-e">width</span>=<span class="pl-s"><span class="pl-pds">"</span>640<span class="pl-pds">"</span></span> <span class="pl-e">height</span>=<span class="pl-s"><span class="pl-pds">"</span>264<span class="pl-pds">"</span></span> <span class="pl-e">poster</span>=<span class="pl-s"><span class="pl-pds">"</span>really-cool-video-poster.jpg<span class="pl-pds">"</span></span>
 <span class="pl-e">data-setup</span>=<span class="pl-s"><span class="pl-pds">'</span>{}<span class="pl-pds">'</span></span>&gt;
  &lt;<span class="pl-ent">source</span> <span class="pl-e">src</span>=<span class="pl-s"><span class="pl-pds">"</span>really-cool-video.mp4<span class="pl-pds">"</span></span> <span class="pl-e">type</span>=<span class="pl-s"><span class="pl-pds">'</span>video/mp4<span class="pl-pds">'</span></span>&gt;
  &lt;<span class="pl-ent">source</span> <span class="pl-e">src</span>=<span class="pl-s"><span class="pl-pds">"</span>really-cool-video.webm<span class="pl-pds">"</span></span> <span class="pl-e">type</span>=<span class="pl-s"><span class="pl-pds">'</span>video/webm<span class="pl-pds">'</span></span>&gt;
  &lt;<span class="pl-ent">p</span> <span class="pl-e">class</span>=<span class="pl-s"><span class="pl-pds">"</span>vjs-no-js<span class="pl-pds">"</span></span>&gt;
    To view this video please enable JavaScript, and consider upgrading to a web browser
    that &lt;<span class="pl-ent">a</span> <span class="pl-e">href</span>=<span class="pl-s"><span class="pl-pds">"</span>http://videojs.com/html5-video-support/<span class="pl-pds">"</span></span> <span class="pl-e">target</span>=<span class="pl-s"><span class="pl-pds">"</span>_blank<span class="pl-pds">"</span></span>&gt;supports HTML5 video&lt;/<span class="pl-ent">a</span>&gt;
  &lt;/<span class="pl-ent">p</span>&gt;
&lt;/<span class="pl-ent">video</span>&gt;</pre></div>

<p>If you don't want to use auto-setup, you can leave off the <code>data-setup</code> attribute and initialize a video element manually.</p>

<div class="highlight highlight-javascript"><pre><span class="pl-k">var</span> player <span class="pl-k">=</span> videojs(<span class="pl-s"><span class="pl-pds">'</span>really-cool-video<span class="pl-pds">'</span></span>, { <span class="pl-c">/* Options */</span> }, <span class="pl-k">function</span>() {
  <span class="pl-en">console</span><span class="pl-c1">.log</span>(<span class="pl-s"><span class="pl-pds">'</span>Good to go!<span class="pl-pds">'</span></span>);

  <span class="pl-v">this</span>.play(); <span class="pl-c">// if you don't trust autoplay for some reason</span>

  <span class="pl-c">// How about an event listener?</span>
  <span class="pl-v">this</span>.on(<span class="pl-s"><span class="pl-pds">'</span>ended<span class="pl-pds">'</span></span>, <span class="pl-k">function</span>() {
    <span class="pl-en">console</span><span class="pl-c1">.log</span>(<span class="pl-s"><span class="pl-pds">'</span>awww...over so soon?<span class="pl-pds">'</span></span>);
  });
});</pre></div>

<p>If you're ready to dive in, the <a href="/videojs/video.js/blob/master/docs/index.md">documentation</a> is the first place to go for more information. Generally the
<a href="/videojs/video.js/blob/master/docs/api/vjs.Player.md">player API docs</a> are the most pertinent.</p>

<h2><a id="user-content-contributing" class="anchor" href="#contributing" aria-hidden="true"><span class="octicon octicon-link"></span></a>Contributing</h2>

<p>Video.js is a free and open source library, and we appreciate any help you're willing to give. Check out the <a href="/videojs/video.js/blob/master/CONTRIBUTING.md">contributing guide</a>.</p>

<h2><a id="user-content-building-your-own-videojs-from-source" class="anchor" href="#building-your-own-videojs-from-source" aria-hidden="true"><span class="octicon octicon-link"></span></a>Building your own Video.js from source</h2>

<p>To build your own custom version read the section on <a href="/videojs/video.js/blob/master/CONTRIBUTING.md#contributing-code">contributing code</a> and <a href="/videojs/video.js/blob/master/CONTRIBUTING.md#building-your-own-copy-of-videojs">"Building your own copy"</a> in the contributing guide.</p>

<h2><a id="user-content-license" class="anchor" href="#license" aria-hidden="true"><span class="octicon octicon-link"></span></a>License</h2>

<p>Video.js is licensed under the Apache License, Version 2.0. <a href="/videojs/video.js/blob/master/LICENSE">View the license file</a></p>

<p>Copyright 2014-2015 Brightcove, Inc.</p>
</article>
  </div>


        </div>

      </div><!-- /.repo-container -->
      <div class="modal-backdrop"></div>
    </div><!-- /.container -->
  </div><!-- /.site -->


    </div><!-- /.wrapper -->

      <div class="container">
  <div class="site-footer" role="contentinfo">
    <ul class="site-footer-links right">
        <li><a href="https://status.github.com/" data-ga-click="Footer, go to status, text:status">Status</a></li>
      <li><a href="https://developer.github.com" data-ga-click="Footer, go to api, text:api">API</a></li>
      <li><a href="https://training.github.com" data-ga-click="Footer, go to training, text:training">Training</a></li>
      <li><a href="https://shop.github.com" data-ga-click="Footer, go to shop, text:shop">Shop</a></li>
        <li><a href="https://github.com/blog" data-ga-click="Footer, go to blog, text:blog">Blog</a></li>
        <li><a href="https://github.com/about" data-ga-click="Footer, go to about, text:about">About</a></li>

    </ul>

    <a href="https://github.com" aria-label="Homepage">
      <span class="mega-octicon octicon-mark-github" title="GitHub"></span>
</a>
    <ul class="site-footer-links">
      <li>&copy; 2015 <span title="0.05593s from github-fe127-cp1-prd.iad.github.net">GitHub</span>, Inc.</li>
        <li><a href="https://github.com/site/terms" data-ga-click="Footer, go to terms, text:terms">Terms</a></li>
        <li><a href="https://github.com/site/privacy" data-ga-click="Footer, go to privacy, text:privacy">Privacy</a></li>
        <li><a href="https://github.com/security" data-ga-click="Footer, go to security, text:security">Security</a></li>
        <li><a href="https://github.com/contact" data-ga-click="Footer, go to contact, text:contact">Contact</a></li>
    </ul>
  </div>
</div>


    <div class="fullscreen-overlay js-fullscreen-overlay" id="fullscreen_overlay">
  <div class="fullscreen-container js-suggester-container">
    <div class="textarea-wrap">
      <textarea name="fullscreen-contents" id="fullscreen-contents" class="fullscreen-contents js-fullscreen-contents" placeholder=""></textarea>
      <div class="suggester-container">
        <div class="suggester fullscreen-suggester js-suggester js-navigation-container"></div>
      </div>
    </div>
  </div>
  <div class="fullscreen-sidebar">
    <a href="#" class="exit-fullscreen js-exit-fullscreen tooltipped tooltipped-w" aria-label="Exit Zen Mode">
      <span class="mega-octicon octicon-screen-normal"></span>
    </a>
    <a href="#" class="theme-switcher js-theme-switcher tooltipped tooltipped-w"
      aria-label="Switch themes">
      <span class="octicon octicon-color-mode"></span>
    </a>
  </div>
</div>



    

    <div id="ajax-error-message" class="flash flash-error">
      <span class="octicon octicon-alert"></span>
      <a href="#" class="octicon octicon-x flash-close js-ajax-error-dismiss" aria-label="Dismiss error"></a>
      Something went wrong with that request. Please try again.
    </div>


      <script crossorigin="anonymous" src="https://assets-cdn.github.com/assets/frameworks-447ce66a36506ebddc8e84b4e32a77f6062f3d3482e77dd21a77a01f0643ad98.js"></script>
      <script async="async" crossorigin="anonymous" src="https://assets-cdn.github.com/assets/github/index-273626d05f0daba1adb856ea6f9d82ff151f8b9f23a21044a761d2e2f843b354.js"></script>
      
      
  </body>
</html>

