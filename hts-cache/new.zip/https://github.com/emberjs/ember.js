


<!DOCTYPE html>
<html lang="en" class="">
  <head prefix="og: http://ogp.me/ns# fb: http://ogp.me/ns/fb# object: http://ogp.me/ns/object# article: http://ogp.me/ns/article# profile: http://ogp.me/ns/profile#">
    <meta charset='utf-8'>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Language" content="en">
    
    
    <title>emberjs/ember.js · GitHub</title>
    <link rel="search" type="application/opensearchdescription+xml" href="/opensearch.xml" title="GitHub">
    <link rel="fluid-icon" href="https://github.com/fluidicon.png" title="GitHub">
    <link rel="apple-touch-icon" sizes="57x57" href="/apple-touch-icon-114.png">
    <link rel="apple-touch-icon" sizes="114x114" href="/apple-touch-icon-114.png">
    <link rel="apple-touch-icon" sizes="72x72" href="/apple-touch-icon-144.png">
    <link rel="apple-touch-icon" sizes="144x144" href="/apple-touch-icon-144.png">
    <meta property="fb:app_id" content="1401488693436528">

      <meta content="@github" name="twitter:site" /><meta content="summary" name="twitter:card" /><meta content="emberjs/ember.js" name="twitter:title" /><meta content="ember.js - Ember.js - A JavaScript framework for creating ambitious web applications" name="twitter:description" /><meta content="https://avatars0.githubusercontent.com/u/1253363?v=3&amp;s=400" name="twitter:image:src" />
      <meta content="GitHub" property="og:site_name" /><meta content="object" property="og:type" /><meta content="https://avatars0.githubusercontent.com/u/1253363?v=3&amp;s=400" property="og:image" /><meta content="emberjs/ember.js" property="og:title" /><meta content="https://github.com/emberjs/ember.js" property="og:url" /><meta content="ember.js - Ember.js - A JavaScript framework for creating ambitious web applications" property="og:description" />
      <meta name="browser-stats-url" content="https://api.github.com/_private/browser/stats">
    <meta name="browser-errors-url" content="https://api.github.com/_private/browser/errors">
    <link rel="assets" href="https://assets-cdn.github.com/">
    
    <meta name="pjax-timeout" content="1000">
    

    <meta name="msapplication-TileImage" content="/windows-tile.png">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="selected-link" value="repo_source" data-pjax-transient>
      <meta name="google-analytics" content="UA-3769691-2">

    <meta content="collector.githubapp.com" name="octolytics-host" /><meta content="collector-cdn.github.com" name="octolytics-script-host" /><meta content="github" name="octolytics-app-id" /><meta content="783D1521:06BF:921472:5571AB2B" name="octolytics-dimension-request_id" />
    
    <meta content="Rails, view, files#disambiguate" name="analytics-event" />
    <meta class="js-ga-set" name="dimension1" content="Logged Out">
    <meta class="js-ga-set" name="dimension2" content="Header v3">
    <meta name="is-dotcom" content="true">
      <meta name="hostname" content="github.com">
    <meta name="user-login" content="">

    
    <link rel="icon" type="image/x-icon" href="https://assets-cdn.github.com/favicon.ico">


    <meta content="authenticity_token" name="csrf-param" />
<meta content="JTWrfuQrh6xKZ4aLHvlZ4ZBfbVnbYCIx0MKPS2HdThamyx0xeyovdrnQMw0cG8ucvFVrHnzw7MJ2DpRnfV9pWg==" name="csrf-token" />

    <link crossorigin="anonymous" href="https://assets-cdn.github.com/assets/github/index-6967b378b26829cc5a2ea2ad4209ff0af50f2a65057962219dc9dcf8942683f0.css" media="all" rel="stylesheet" />
    <link crossorigin="anonymous" href="https://assets-cdn.github.com/assets/github2/index-73bfe123ff406f4bf8959a28667410beaac1485e71c92d4725a3d7afc45fc4c5.css" media="all" rel="stylesheet" />
    
    


    <meta http-equiv="x-pjax-version" content="b2ca4753a2f40f3bd3d3d6fd0fe8b32e">

      
  <meta name="description" content="ember.js - Ember.js - A JavaScript framework for creating ambitious web applications">
  <meta name="go-import" content="github.com/emberjs/ember.js git https://github.com/emberjs/ember.js.git">

  <meta content="1253363" name="octolytics-dimension-user_id" /><meta content="emberjs" name="octolytics-dimension-user_login" /><meta content="1801829" name="octolytics-dimension-repository_id" /><meta content="emberjs/ember.js" name="octolytics-dimension-repository_nwo" /><meta content="true" name="octolytics-dimension-repository_public" /><meta content="false" name="octolytics-dimension-repository_is_fork" /><meta content="1801829" name="octolytics-dimension-repository_network_root_id" /><meta content="emberjs/ember.js" name="octolytics-dimension-repository_network_root_nwo" />
  <link href="https://github.com/emberjs/ember.js/commits/master.atom" rel="alternate" title="Recent Commits to ember.js:master" type="application/atom+xml">

  </head>


  <body class="logged_out  env-production  vis-public">
    <a href="#start-of-content" tabindex="1" class="accessibility-aid js-skip-to-content">Skip to content</a>
    <div class="wrapper">
      
      
      


        
        <div class="header header-logged-out" role="banner">
  <div class="container clearfix">

    <a class="header-logo-wordmark" href="https://github.com/" data-ga-click="(Logged out) Header, go to homepage, icon:logo-wordmark">
      <span class="mega-octicon octicon-logo-github"></span>
    </a>

    <div class="header-actions" role="navigation">
        <a class="btn btn-primary" href="/join" data-ga-click="(Logged out) Header, clicked Sign up, text:sign-up">Sign up</a>
      <a class="btn" href="/login?return_to=%2Femberjs%2Fember.js" data-ga-click="(Logged out) Header, clicked Sign in, text:sign-in">Sign in</a>
    </div>

    <div class="site-search repo-scope js-site-search" role="search">
      <form accept-charset="UTF-8" action="/emberjs/ember.js/search" class="js-site-search-form" data-global-search-url="/search" data-repo-search-url="/emberjs/ember.js/search" method="get"><div style="margin:0;padding:0;display:inline"><input name="utf8" type="hidden" value="&#x2713;" /></div>
  <label class="js-chromeless-input-container form-control">
    <div class="scope-badge">This repository</div>
    <input type="text"
      class="js-site-search-focus js-site-search-field is-clearable chromeless-input"
      data-hotkey="s"
      name="q"
      placeholder="Search"
      data-global-scope-placeholder="Search GitHub"
      data-repo-scope-placeholder="Search"
      tabindex="1"
      autocapitalize="off">
  </label>
</form>
    </div>

      <ul class="header-nav left" role="navigation">
          <li class="header-nav-item">
            <a class="header-nav-link" href="/explore" data-ga-click="(Logged out) Header, go to explore, text:explore">Explore</a>
          </li>
          <li class="header-nav-item">
            <a class="header-nav-link" href="/features" data-ga-click="(Logged out) Header, go to features, text:features">Features</a>
          </li>
          <li class="header-nav-item">
            <a class="header-nav-link" href="https://enterprise.github.com/" data-ga-click="(Logged out) Header, go to enterprise, text:enterprise">Enterprise</a>
          </li>
          <li class="header-nav-item">
            <a class="header-nav-link" href="/blog" data-ga-click="(Logged out) Header, go to blog, text:blog">Blog</a>
          </li>
      </ul>

  </div>
</div>



      <div id="start-of-content" class="accessibility-aid"></div>
          <div class="site" itemscope itemtype="http://schema.org/WebPage">
    <div id="js-flash-container">
      
    </div>
    <div class="pagehead repohead instapaper_ignore readability-menu">
      <div class="container">

        
<ul class="pagehead-actions">

  <li>
      <a href="/login?return_to=%2Femberjs%2Fember.js"
    class="btn btn-sm btn-with-count tooltipped tooltipped-n"
    aria-label="You must be signed in to watch a repository" rel="nofollow">
    <span class="octicon octicon-eye"></span>
    Watch
  </a>
  <a class="social-count" href="/emberjs/ember.js/watchers">
    1,125
  </a>

  </li>

  <li>
      <a href="/login?return_to=%2Femberjs%2Fember.js"
    class="btn btn-sm btn-with-count tooltipped tooltipped-n"
    aria-label="You must be signed in to star a repository" rel="nofollow">
    <span class="octicon octicon-star"></span>
    Star
  </a>

    <a class="social-count js-social-count" href="/emberjs/ember.js/stargazers">
      13,938
    </a>

  </li>

    <li>
      <a href="/login?return_to=%2Femberjs%2Fember.js"
        class="btn btn-sm btn-with-count tooltipped tooltipped-n"
        aria-label="You must be signed in to fork a repository" rel="nofollow">
        <span class="octicon octicon-repo-forked"></span>
        Fork
      </a>
      <a href="/emberjs/ember.js/network" class="social-count">
        2,975
      </a>
    </li>
</ul>

        <h1 itemscope itemtype="http://data-vocabulary.org/Breadcrumb" class="entry-title public">
          <span class="mega-octicon octicon-repo"></span>
          <span class="author"><a href="/emberjs" class="url fn" itemprop="url" rel="author"><span itemprop="title">emberjs</span></a></span><!--
       --><span class="path-divider">/</span><!--
       --><strong><a href="/emberjs/ember.js" data-pjax="#js-repo-pjax-container">ember.js</a></strong>

          <span class="page-context-loader">
            <img alt="" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </span>

        </h1>
      </div><!-- /.container -->
    </div><!-- /.repohead -->

    <div class="container">
      <div class="repository-with-sidebar repo-container new-discussion-timeline with-full-navigation ">
        <div class="repository-sidebar clearfix">
            
<nav class="sunken-menu repo-nav js-repo-nav js-sidenav-container-pjax js-octicon-loaders"
     role="navigation"
     data-pjax="#js-repo-pjax-container"
     data-issue-count-url="/emberjs/ember.js/issues/counts">
  <ul class="sunken-menu-group">
    <li class="tooltipped tooltipped-w" aria-label="Code">
      <a href="/emberjs/ember.js" aria-label="Code" class="selected js-selected-navigation-item sunken-menu-item" data-hotkey="g c" data-selected-links="repo_source repo_downloads repo_commits repo_releases repo_tags repo_branches /emberjs/ember.js">
        <span class="octicon octicon-code"></span> <span class="full-word">Code</span>
        <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>    </li>

      <li class="tooltipped tooltipped-w" aria-label="Issues">
        <a href="/emberjs/ember.js/issues" aria-label="Issues" class="js-selected-navigation-item sunken-menu-item" data-hotkey="g i" data-selected-links="repo_issues repo_labels repo_milestones /emberjs/ember.js/issues">
          <span class="octicon octicon-issue-opened"></span> <span class="full-word">Issues</span>
          <span class="js-issue-replace-counter"></span>
          <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>      </li>

    <li class="tooltipped tooltipped-w" aria-label="Pull requests">
      <a href="/emberjs/ember.js/pulls" aria-label="Pull requests" class="js-selected-navigation-item sunken-menu-item" data-hotkey="g p" data-selected-links="repo_pulls /emberjs/ember.js/pulls">
          <span class="octicon octicon-git-pull-request"></span> <span class="full-word">Pull requests</span>
          <span class="js-pull-replace-counter"></span>
          <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>    </li>

  </ul>
  <div class="sunken-menu-separator"></div>
  <ul class="sunken-menu-group">

    <li class="tooltipped tooltipped-w" aria-label="Pulse">
      <a href="/emberjs/ember.js/pulse" aria-label="Pulse" class="js-selected-navigation-item sunken-menu-item" data-selected-links="pulse /emberjs/ember.js/pulse">
        <span class="octicon octicon-pulse"></span> <span class="full-word">Pulse</span>
        <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>    </li>

    <li class="tooltipped tooltipped-w" aria-label="Graphs">
      <a href="/emberjs/ember.js/graphs" aria-label="Graphs" class="js-selected-navigation-item sunken-menu-item" data-selected-links="repo_graphs repo_contributors /emberjs/ember.js/graphs">
        <span class="octicon octicon-graph"></span> <span class="full-word">Graphs</span>
        <img alt="" class="mini-loader" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
</a>    </li>
  </ul>


</nav>

              <div class="only-with-full-nav">
                  
<div class="js-clone-url clone-url open"
  data-protocol-type="http">
  <h3><span class="text-emphasized">HTTPS</span> clone URL</h3>
  <div class="input-group js-zeroclipboard-container">
    <input type="text" class="input-mini input-monospace js-url-field js-zeroclipboard-target"
           value="https://github.com/emberjs/ember.js.git" readonly="readonly">
    <span class="input-group-button">
      <button aria-label="Copy to clipboard" class="js-zeroclipboard btn btn-sm zeroclipboard-button tooltipped tooltipped-s" data-copied-hint="Copied!" type="button"><span class="octicon octicon-clippy"></span></button>
    </span>
  </div>
</div>

  
<div class="js-clone-url clone-url "
  data-protocol-type="subversion">
  <h3><span class="text-emphasized">Subversion</span> checkout URL</h3>
  <div class="input-group js-zeroclipboard-container">
    <input type="text" class="input-mini input-monospace js-url-field js-zeroclipboard-target"
           value="https://github.com/emberjs/ember.js" readonly="readonly">
    <span class="input-group-button">
      <button aria-label="Copy to clipboard" class="js-zeroclipboard btn btn-sm zeroclipboard-button tooltipped tooltipped-s" data-copied-hint="Copied!" type="button"><span class="octicon octicon-clippy"></span></button>
    </span>
  </div>
</div>



<div class="clone-options">You can clone with
  <form accept-charset="UTF-8" action="/users/set_protocol?protocol_selector=http&amp;protocol_type=clone" class="inline-form js-clone-selector-form " data-remote="true" method="post"><div style="margin:0;padding:0;display:inline"><input name="utf8" type="hidden" value="&#x2713;" /><input name="authenticity_token" type="hidden" value="g9kWQQE/UYozwyxyqZuZzSlQOCaq/V/MP11NZ/WgIVd0O0eXyyWNNFoiqfVZoF/d3Nxrd7MFfZXwWZ/VtNx5Ow==" /></div><button class="btn-link js-clone-selector" data-protocol="http" type="submit">HTTPS</button></form> or <form accept-charset="UTF-8" action="/users/set_protocol?protocol_selector=subversion&amp;protocol_type=clone" class="inline-form js-clone-selector-form " data-remote="true" method="post"><div style="margin:0;padding:0;display:inline"><input name="utf8" type="hidden" value="&#x2713;" /><input name="authenticity_token" type="hidden" value="XdlAknh+2/Y0s6WrekcMOfgtAxHvkh+CQiYDH2lxSsrI84yKK/9I3XEOQbSvHegV4LOcup4Vt2Vi2dlDKu6Acw==" /></div><button class="btn-link js-clone-selector" data-protocol="subversion" type="submit">Subversion</button></form>.
  <a href="https://help.github.com/articles/which-remote-url-should-i-use" class="help tooltipped tooltipped-n" aria-label="Get help on which URL is right for you.">
    <span class="octicon octicon-question"></span>
  </a>
</div>




                <a href="/emberjs/ember.js/archive/master.zip"
                   class="btn btn-sm sidebar-button"
                   aria-label="Download the contents of emberjs/ember.js as a zip file"
                   title="Download the contents of emberjs/ember.js as a zip file"
                   rel="nofollow">
                  <span class="octicon octicon-cloud-download"></span>
                  Download ZIP
                </a>
              </div>
        </div><!-- /.repository-sidebar -->

        <div id="js-repo-pjax-container" class="repository-content context-loader-container" data-pjax-container>

          
<span id="js-show-full-navigation"></span>

<div class="repository-meta js-details-container ">
    <div class="repository-description">
      Ember.js - A JavaScript framework for creating ambitious web applications
    </div>

    <div class="repository-website">
      <p><a href="http://www.emberjs.com" rel="nofollow">http://www.emberjs.com</a></p>
    </div>


</div>

<div class="overall-summary overall-summary-bottomless">

  <div class="stats-switcher-viewport js-stats-switcher-viewport">
    <div class="stats-switcher-wrapper">
    <ul class="numbers-summary">
      <li class="commits">
        <a data-pjax href="/emberjs/ember.js/commits/master">
            <span class="octicon octicon-history"></span>
            <span class="num text-emphasized">
              9,841
            </span>
            commits
        </a>
      </li>
      <li>
        <a data-pjax href="/emberjs/ember.js/branches">
          <span class="octicon octicon-git-branch"></span>
          <span class="num text-emphasized">
            52
          </span>
          branches
        </a>
      </li>

      <li>
        <a data-pjax href="/emberjs/ember.js/releases">
          <span class="octicon octicon-tag"></span>
          <span class="num text-emphasized">
            119
          </span>
          releases
        </a>
      </li>

      <li>
        
  <a href="/emberjs/ember.js/graphs/contributors">
    <span class="octicon octicon-organization"></span>
    <span class="num text-emphasized">
      496
    </span>
    contributors
  </a>
      </li>
    </ul>

      <div class="repository-lang-stats">
        <ol class="repository-lang-stats-numbers">
          <li>
              <a href="/emberjs/ember.js/search?l=javascript">
                <span class="color-block language-color" style="background-color:#f1e05a;"></span>
                <span class="lang">JavaScript</span>
                <span class="percent">99.4%</span>
              </a>
          </li>
          <li>
              <span class="other">
                <span class="color-block language-color" style="background-color:#ededed;"></span>
                <span class="lang">Other</span>
                <span class="percent">0.6%</span>
              </span>
          </li>
        </ol>
      </div>
    </div>
  </div>

</div>

  <div class="repository-lang-stats-graph js-toggle-lang-stats" title="Click for language details">
    <span class="language-color" aria-label="JavaScript 99.4%" style="width:99.4%; background-color:#f1e05a;" itemprop="keywords">JavaScript</span>
    <span class="language-color" aria-label="Other 0.6%" style="width:0.6%; background-color:#ededed;" itemprop="keywords">Other</span>
  </div>

<include-fragment src="/emberjs/ember.js/show_partial?partial=tree%2Frecently_touched_branches_list"></include-fragment>

<div class="file-navigation in-mid-page">
  <a href="/emberjs/ember.js/find/master"
        class="js-show-file-finder btn btn-sm empty-icon tooltipped tooltipped-s right"
        data-pjax
        data-hotkey="t"
        aria-label="Quickly jump between files">
    <span class="octicon octicon-list-unordered"></span>
  </a>
    <a href="/emberjs/ember.js/compare" aria-label="Compare, review, create a pull request" class="btn btn-sm btn-primary tooltipped tooltipped-se left compare-button" aria-label="Compare &amp; review" data-pjax data-ga-click="Repository, go to compare view, location:repo overview; icon:git-compare">
      <span class="octicon octicon-git-compare"></span>
    </a>

  
<div class="select-menu js-menu-container js-select-menu left">
  <span class="btn btn-sm select-menu-button js-menu-target css-truncate" data-hotkey="w"
    data-ref="master"
    title="master"
    role="button" aria-label="Switch branches or tags" tabindex="0" aria-haspopup="true">
    <span class="octicon octicon-git-branch"></span>
    <i>branch:</i>
    <span class="js-select-button css-truncate-target">master</span>
  </span>

  <div class="select-menu-modal-holder js-menu-content js-navigation-container" data-pjax aria-hidden="true">

    <div class="select-menu-modal">
      <div class="select-menu-header">
        <span class="select-menu-title">Switch branches/tags</span>
        <span class="octicon octicon-x js-menu-close" role="button" aria-label="Close"></span>
      </div>

      <div class="select-menu-filters">
        <div class="select-menu-text-filter">
          <input type="text" aria-label="Filter branches/tags" id="context-commitish-filter-field" class="js-filterable-field js-navigation-enable" placeholder="Filter branches/tags">
        </div>
        <div class="select-menu-tabs">
          <ul>
            <li class="select-menu-tab">
              <a href="#" data-tab-filter="branches" data-filter-placeholder="Filter branches/tags" class="js-select-menu-tab">Branches</a>
            </li>
            <li class="select-menu-tab">
              <a href="#" data-tab-filter="tags" data-filter-placeholder="Find a tag…" class="js-select-menu-tab">Tags</a>
            </li>
          </ul>
        </div>
      </div>

      <div class="select-menu-list select-menu-tab-bucket js-select-menu-tab-bucket" data-tab-filter="branches">

        <div data-filterable-for="context-commitish-filter-field" data-filterable-type="substring">


            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/emberjs/ember.js/tree/1.7.0-with-documentation-fixes"
               data-name="1.7.0-with-documentation-fixes"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="1.7.0-with-documentation-fixes">
                1.7.0-with-documentation-fixes
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/emberjs/ember.js/tree/actions-for"
               data-name="actions-for"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="actions-for">
                actions-for
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/emberjs/ember.js/tree/allow-failures"
               data-name="allow-failures"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="allow-failures">
                allow-failures
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/emberjs/ember.js/tree/async-observers"
               data-name="async-observers"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="async-observers">
                async-observers
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/emberjs/ember.js/tree/beta"
               data-name="beta"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="beta">
                beta
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/emberjs/ember.js/tree/bound_property_view"
               data-name="bound_property_view"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="bound_property_view">
                bound_property_view
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/emberjs/ember.js/tree/child-views-maintained"
               data-name="child-views-maintained"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="child-views-maintained">
                child-views-maintained
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/emberjs/ember.js/tree/closer-to-the-metal"
               data-name="closer-to-the-metal"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="closer-to-the-metal">
                closer-to-the-metal
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/emberjs/ember.js/tree/coreview"
               data-name="coreview"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="coreview">
                coreview
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/emberjs/ember.js/tree/dashless-components"
               data-name="dashless-components"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="dashless-components">
                dashless-components
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/emberjs/ember.js/tree/default-on-error-with-stack"
               data-name="default-on-error-with-stack"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="default-on-error-with-stack">
                default-on-error-with-stack
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/emberjs/ember.js/tree/__defineNonEnumerable"
               data-name="__defineNonEnumerable"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="__defineNonEnumerable">
                __defineNonEnumerable
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/emberjs/ember.js/tree/dont-allow-undefined-container-registrations"
               data-name="dont-allow-undefined-container-registrations"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="dont-allow-undefined-container-registrations">
                dont-allow-undefined-container-registrations
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/emberjs/ember.js/tree/duplicate-object-create-polyfills"
               data-name="duplicate-object-create-polyfills"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="duplicate-object-create-polyfills">
                duplicate-object-create-polyfills
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/emberjs/ember.js/tree/each-inverse-to-template"
               data-name="each-inverse-to-template"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="each-inverse-to-template">
                each-inverse-to-template
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/emberjs/ember.js/tree/es3-keys-improvements"
               data-name="es3-keys-improvements"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="es3-keys-improvements">
                es3-keys-improvements
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/emberjs/ember.js/tree/fix-render-with-extra-context-leak"
               data-name="fix-render-with-extra-context-leak"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="fix-render-with-extra-context-leak">
                fix-render-with-extra-context-leak
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/emberjs/ember.js/tree/fixup-collection-and-each-view"
               data-name="fixup-collection-and-each-view"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="fixup-collection-and-each-view">
                fixup-collection-and-each-view
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/emberjs/ember.js/tree/guid-for-simple-handlebars-bound-view"
               data-name="guid-for-simple-handlebars-bound-view"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="guid-for-simple-handlebars-bound-view">
                guid-for-simple-handlebars-bound-view
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/emberjs/ember.js/tree/htmlbars"
               data-name="htmlbars"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="htmlbars">
                htmlbars
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/emberjs/ember.js/tree/htmlbars-collection-helper"
               data-name="htmlbars-collection-helper"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="htmlbars-collection-helper">
                htmlbars-collection-helper
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/emberjs/ember.js/tree/htmlbars-each-helper"
               data-name="htmlbars-each-helper"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="htmlbars-each-helper">
                htmlbars-each-helper
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/emberjs/ember.js/tree/htmlbars-if-helper"
               data-name="htmlbars-if-helper"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="htmlbars-if-helper">
                htmlbars-if-helper
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/emberjs/ember.js/tree/htmlbars-outlet-helper"
               data-name="htmlbars-outlet-helper"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="htmlbars-outlet-helper">
                htmlbars-outlet-helper
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/emberjs/ember.js/tree/htmlbars-unbound-helper"
               data-name="htmlbars-unbound-helper"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="htmlbars-unbound-helper">
                htmlbars-unbound-helper
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/emberjs/ember.js/tree/in-template-config"
               data-name="in-template-config"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="in-template-config">
                in-template-config
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/emberjs/ember.js/tree/inspect-null-prototype"
               data-name="inspect-null-prototype"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="inspect-null-prototype">
                inspect-null-prototype
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/emberjs/ember.js/tree/itemcontroller-wip"
               data-name="itemcontroller-wip"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="itemcontroller-wip">
                itemcontroller-wip
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/emberjs/ember.js/tree/layout-rerendering"
               data-name="layout-rerendering"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="layout-rerendering">
                layout-rerendering
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open selected"
               href="/emberjs/ember.js/tree/master"
               data-name="master"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="master">
                master
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/emberjs/ember.js/tree/mixin-rework"
               data-name="mixin-rework"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="mixin-rework">
                mixin-rework
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/emberjs/ember.js/tree/more-map-es6-stuff"
               data-name="more-map-es6-stuff"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="more-map-es6-stuff">
                more-map-es6-stuff
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/emberjs/ember.js/tree/new"
               data-name="new"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="new">
                new
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/emberjs/ember.js/tree/prev-idempotent-rerender"
               data-name="prev-idempotent-rerender"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="prev-idempotent-rerender">
                prev-idempotent-rerender
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/emberjs/ember.js/tree/prevent_dangling_promises_in_router_tests"
               data-name="prevent_dangling_promises_in_router_tests"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="prevent_dangling_promises_in_router_tests">
                prevent_dangling_promises_in_router_tests
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/emberjs/ember.js/tree/promise-proxy-swallows"
               data-name="promise-proxy-swallows"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="promise-proxy-swallows">
                promise-proxy-swallows
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/emberjs/ember.js/tree/proxies"
               data-name="proxies"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="proxies">
                proxies
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/emberjs/ember.js/tree/reactive-rerendering"
               data-name="reactive-rerendering"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="reactive-rerendering">
                reactive-rerendering
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/emberjs/ember.js/tree/routable-components"
               data-name="routable-components"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="routable-components">
                routable-components
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/emberjs/ember.js/tree/routing-service"
               data-name="routing-service"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="routing-service">
                routing-service
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/emberjs/ember.js/tree/shared-functions"
               data-name="shared-functions"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="shared-functions">
                shared-functions
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/emberjs/ember.js/tree/ssr-boot"
               data-name="ssr-boot"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="ssr-boot">
                ssr-boot
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/emberjs/ember.js/tree/ssr-wip"
               data-name="ssr-wip"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="ssr-wip">
                ssr-wip
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/emberjs/ember.js/tree/stable"
               data-name="stable"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="stable">
                stable
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/emberjs/ember.js/tree/sync_on_connect"
               data-name="sync_on_connect"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="sync_on_connect">
                sync_on_connect
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/emberjs/ember.js/tree/teardown-component"
               data-name="teardown-component"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="teardown-component">
                teardown-component
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/emberjs/ember.js/tree/tests-for"
               data-name="tests-for"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="tests-for">
                tests-for
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/emberjs/ember.js/tree/throw_if_re-registering_already_looked_up_factory"
               data-name="throw_if_re-registering_already_looked_up_factory"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="throw_if_re-registering_already_looked_up_factory">
                throw_if_re-registering_already_looked_up_factory
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/emberjs/ember.js/tree/unused-jshint-vars"
               data-name="unused-jshint-vars"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="unused-jshint-vars">
                unused-jshint-vars
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/emberjs/ember.js/tree/unwrap-controllers-plugin"
               data-name="unwrap-controllers-plugin"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="unwrap-controllers-plugin">
                unwrap-controllers-plugin
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/emberjs/ember.js/tree/update-build-tools"
               data-name="update-build-tools"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="update-build-tools">
                update-build-tools
              </span>
            </a>
            <a class="select-menu-item js-navigation-item js-navigation-open "
               href="/emberjs/ember.js/tree/viewless-component"
               data-name="viewless-component"
               data-skip-pjax="true"
               rel="nofollow">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <span class="select-menu-item-text css-truncate-target" title="viewless-component">
                viewless-component
              </span>
            </a>
        </div>

          <div class="select-menu-no-results">Nothing to show</div>
      </div>

      <div class="select-menu-list select-menu-tab-bucket js-select-menu-tab-bucket" data-tab-filter="tags">
        <div data-filterable-for="context-commitish-filter-field" data-filterable-type="substring">


            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.13.0-beta.2"
                 data-name="v1.13.0-beta.2"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.13.0-beta.2">v1.13.0-beta.2</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.13.0-beta.1"
                 data-name="v1.13.0-beta.1"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.13.0-beta.1">v1.13.0-beta.1</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.12.1"
                 data-name="v1.12.1"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.12.1">v1.12.1</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.12.0-beta.3"
                 data-name="v1.12.0-beta.3"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.12.0-beta.3">v1.12.0-beta.3</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.12.0-beta.2"
                 data-name="v1.12.0-beta.2"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.12.0-beta.2">v1.12.0-beta.2</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.12.0-beta.1"
                 data-name="v1.12.0-beta.1"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.12.0-beta.1">v1.12.0-beta.1</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.12.0"
                 data-name="v1.12.0"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.12.0">v1.12.0</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.11.3"
                 data-name="v1.11.3"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.11.3">v1.11.3</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.11.2"
                 data-name="v1.11.2"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.11.2">v1.11.2</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.11.1"
                 data-name="v1.11.1"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.11.1">v1.11.1</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.11.0-beta.5"
                 data-name="v1.11.0-beta.5"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.11.0-beta.5">v1.11.0-beta.5</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.11.0-beta.4"
                 data-name="v1.11.0-beta.4"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.11.0-beta.4">v1.11.0-beta.4</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.11.0-beta.3"
                 data-name="v1.11.0-beta.3"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.11.0-beta.3">v1.11.0-beta.3</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.11.0-beta.2"
                 data-name="v1.11.0-beta.2"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.11.0-beta.2">v1.11.0-beta.2</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.11.0-beta.1"
                 data-name="v1.11.0-beta.1"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.11.0-beta.1">v1.11.0-beta.1</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.11.0"
                 data-name="v1.11.0"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.11.0">v1.11.0</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.10.1"
                 data-name="v1.10.1"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.10.1">v1.10.1</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.10.0-beta.4"
                 data-name="v1.10.0-beta.4"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.10.0-beta.4">v1.10.0-beta.4</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.10.0-beta.3"
                 data-name="v1.10.0-beta.3"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.10.0-beta.3">v1.10.0-beta.3</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.10.0-beta.2"
                 data-name="v1.10.0-beta.2"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.10.0-beta.2">v1.10.0-beta.2</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.10.0-beta.1"
                 data-name="v1.10.0-beta.1"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.10.0-beta.1">v1.10.0-beta.1</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.10.0"
                 data-name="v1.10.0"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.10.0">v1.10.0</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.9.1"
                 data-name="v1.9.1"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.9.1">v1.9.1</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.9.0-beta.4"
                 data-name="v1.9.0-beta.4"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.9.0-beta.4">v1.9.0-beta.4</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.9.0-beta.3"
                 data-name="v1.9.0-beta.3"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.9.0-beta.3">v1.9.0-beta.3</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.9.0-beta.1"
                 data-name="v1.9.0-beta.1"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.9.0-beta.1">v1.9.0-beta.1</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.9.0-alpha"
                 data-name="v1.9.0-alpha"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.9.0-alpha">v1.9.0-alpha</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.9.0"
                 data-name="v1.9.0"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.9.0">v1.9.0</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.8.1"
                 data-name="v1.8.1"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.8.1">v1.8.1</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.8.0-beta.5"
                 data-name="v1.8.0-beta.5"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.8.0-beta.5">v1.8.0-beta.5</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.8.0-beta.4"
                 data-name="v1.8.0-beta.4"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.8.0-beta.4">v1.8.0-beta.4</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.8.0-beta.3"
                 data-name="v1.8.0-beta.3"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.8.0-beta.3">v1.8.0-beta.3</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.8.0-beta.2"
                 data-name="v1.8.0-beta.2"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.8.0-beta.2">v1.8.0-beta.2</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.8.0-beta.1"
                 data-name="v1.8.0-beta.1"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.8.0-beta.1">v1.8.0-beta.1</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.8.0"
                 data-name="v1.8.0"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.8.0">v1.8.0</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.7.1"
                 data-name="v1.7.1"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.7.1">v1.7.1</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.7.0-beta.5"
                 data-name="v1.7.0-beta.5"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.7.0-beta.5">v1.7.0-beta.5</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.7.0-beta.4"
                 data-name="v1.7.0-beta.4"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.7.0-beta.4">v1.7.0-beta.4</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.7.0-beta.3"
                 data-name="v1.7.0-beta.3"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.7.0-beta.3">v1.7.0-beta.3</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.7.0-beta.2"
                 data-name="v1.7.0-beta.2"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.7.0-beta.2">v1.7.0-beta.2</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.7.0-beta.1"
                 data-name="v1.7.0-beta.1"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.7.0-beta.1">v1.7.0-beta.1</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.7.0"
                 data-name="v1.7.0"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.7.0">v1.7.0</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.6.1"
                 data-name="v1.6.1"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.6.1">v1.6.1</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.6.0-beta.5"
                 data-name="v1.6.0-beta.5"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.6.0-beta.5">v1.6.0-beta.5</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.6.0-beta.4"
                 data-name="v1.6.0-beta.4"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.6.0-beta.4">v1.6.0-beta.4</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.6.0-beta.3"
                 data-name="v1.6.0-beta.3"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.6.0-beta.3">v1.6.0-beta.3</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.6.0-beta.2"
                 data-name="v1.6.0-beta.2"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.6.0-beta.2">v1.6.0-beta.2</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.6.0-beta.1"
                 data-name="v1.6.0-beta.1"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.6.0-beta.1">v1.6.0-beta.1</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.6.0"
                 data-name="v1.6.0"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.6.0">v1.6.0</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.5.1"
                 data-name="v1.5.1"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.5.1">v1.5.1</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.5.0-beta.4"
                 data-name="v1.5.0-beta.4"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.5.0-beta.4">v1.5.0-beta.4</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.5.0-beta.3"
                 data-name="v1.5.0-beta.3"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.5.0-beta.3">v1.5.0-beta.3</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.5.0-beta.2"
                 data-name="v1.5.0-beta.2"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.5.0-beta.2">v1.5.0-beta.2</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.5.0-beta.1"
                 data-name="v1.5.0-beta.1"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.5.0-beta.1">v1.5.0-beta.1</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.5.0"
                 data-name="v1.5.0"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.5.0">v1.5.0</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.4.0-beta.6"
                 data-name="v1.4.0-beta.6"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.4.0-beta.6">v1.4.0-beta.6</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.4.0-beta.5"
                 data-name="v1.4.0-beta.5"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.4.0-beta.5">v1.4.0-beta.5</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.4.0-beta.4"
                 data-name="v1.4.0-beta.4"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.4.0-beta.4">v1.4.0-beta.4</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.4.0-beta.3"
                 data-name="v1.4.0-beta.3"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.4.0-beta.3">v1.4.0-beta.3</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.4.0-beta.2"
                 data-name="v1.4.0-beta.2"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.4.0-beta.2">v1.4.0-beta.2</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.4.0-beta.1"
                 data-name="v1.4.0-beta.1"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.4.0-beta.1">v1.4.0-beta.1</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.4.0"
                 data-name="v1.4.0"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.4.0">v1.4.0</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.3.2"
                 data-name="v1.3.2"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.3.2">v1.3.2</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.3.1"
                 data-name="v1.3.1"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.3.1">v1.3.1</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.3.0-beta.4"
                 data-name="v1.3.0-beta.4"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.3.0-beta.4">v1.3.0-beta.4</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.3.0-beta.3"
                 data-name="v1.3.0-beta.3"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.3.0-beta.3">v1.3.0-beta.3</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.3.0-beta.2"
                 data-name="v1.3.0-beta.2"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.3.0-beta.2">v1.3.0-beta.2</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.3.0-beta.1"
                 data-name="v1.3.0-beta.1"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.3.0-beta.1">v1.3.0-beta.1</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.3.0"
                 data-name="v1.3.0"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.3.0">v1.3.0</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.2.2"
                 data-name="v1.2.2"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.2.2">v1.2.2</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.2.1"
                 data-name="v1.2.1"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.2.1">v1.2.1</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.2.0-beta.4"
                 data-name="v1.2.0-beta.4"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.2.0-beta.4">v1.2.0-beta.4</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.2.0-beta.3"
                 data-name="v1.2.0-beta.3"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.2.0-beta.3">v1.2.0-beta.3</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.2.0-beta.2"
                 data-name="v1.2.0-beta.2"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.2.0-beta.2">v1.2.0-beta.2</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.2.0-beta.1"
                 data-name="v1.2.0-beta.1"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.2.0-beta.1">v1.2.0-beta.1</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.2.0"
                 data-name="v1.2.0"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.2.0">v1.2.0</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.1.3"
                 data-name="v1.1.3"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.1.3">v1.1.3</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.1.2"
                 data-name="v1.1.2"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.1.2">v1.1.2</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.1.1"
                 data-name="v1.1.1"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.1.1">v1.1.1</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.1.0-beta.4"
                 data-name="v1.1.0-beta.4"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.1.0-beta.4">v1.1.0-beta.4</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.1.0-beta.3"
                 data-name="v1.1.0-beta.3"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.1.0-beta.3">v1.1.0-beta.3</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.1.0-beta.2"
                 data-name="v1.1.0-beta.2"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.1.0-beta.2">v1.1.0-beta.2</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.1.0-beta.1"
                 data-name="v1.1.0-beta.1"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.1.0-beta.1">v1.1.0-beta.1</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.1.0"
                 data-name="v1.1.0"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.1.0">v1.1.0</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.0.pre"
                 data-name="v1.0.pre"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.0.pre">v1.0.pre</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.0.1"
                 data-name="v1.0.1"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.0.1">v1.0.1</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.0.0-rc.8"
                 data-name="v1.0.0-rc.8"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.0.0-rc.8">v1.0.0-rc.8</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.0.0-rc.7"
                 data-name="v1.0.0-rc.7"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.0.0-rc.7">v1.0.0-rc.7</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.0.0-rc.6.1"
                 data-name="v1.0.0-rc.6.1"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.0.0-rc.6.1">v1.0.0-rc.6.1</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.0.0-rc.6"
                 data-name="v1.0.0-rc.6"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.0.0-rc.6">v1.0.0-rc.6</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.0.0-rc.5.1"
                 data-name="v1.0.0-rc.5.1"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.0.0-rc.5.1">v1.0.0-rc.5.1</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.0.0-rc.5"
                 data-name="v1.0.0-rc.5"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.0.0-rc.5">v1.0.0-rc.5</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.0.0-rc.4.1"
                 data-name="v1.0.0-rc.4.1"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.0.0-rc.4.1">v1.0.0-rc.4.1</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.0.0-rc4"
                 data-name="v1.0.0-rc4"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.0.0-rc4">v1.0.0-rc4</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.0.0-rc.4"
                 data-name="v1.0.0-rc.4"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.0.0-rc.4">v1.0.0-rc.4</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.0.0-rc.3.1"
                 data-name="v1.0.0-rc.3.1"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.0.0-rc.3.1">v1.0.0-rc.3.1</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.0.0-rc.3"
                 data-name="v1.0.0-rc.3"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.0.0-rc.3">v1.0.0-rc.3</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.0.0-rc.2.1"
                 data-name="v1.0.0-rc.2.1"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.0.0-rc.2.1">v1.0.0-rc.2.1</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.0.0-rc.2"
                 data-name="v1.0.0-rc.2"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.0.0-rc.2">v1.0.0-rc.2</a>
            </div>
            <div class="select-menu-item js-navigation-item ">
              <span class="select-menu-item-icon octicon octicon-check"></span>
              <a href="/emberjs/ember.js/tree/v1.0.0-rc.1.1"
                 data-name="v1.0.0-rc.1.1"
                 data-skip-pjax="true"
                 rel="nofollow"
                 class="js-navigation-open select-menu-item-text css-truncate-target"
                 title="v1.0.0-rc.1.1">v1.0.0-rc.1.1</a>
            </div>
        </div>

        <div class="select-menu-no-results">Nothing to show</div>
      </div>

    </div>
  </div>
</div>



  <div class="breadcrumb"><span class="repo-root js-repo-root"><span itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb"><a href="/emberjs/ember.js" class="" data-branch="master" data-pjax="true" itemscope="url"><span itemprop="title">ember.js</span></a></span></span><span class="separator">/</span>
    <a class="btn-link disabled tooltipped tooltipped-e" href="#" aria-label="You must be signed in to make or propose changes">
      <span class="octicon octicon-plus"></span>
    </a>
</div>
</div>



  
  <div class="commit commit-tease js-details-container" >
    <p class="commit-title ">
        <a href="/emberjs/ember.js/commit/78b63d1e36e0d25b5c8f1f202d27b3d36fce3fc5" class="message" data-pjax="true" title="Merge pull request #11352 from rwjblue/fix-template-lookup-from-views-as-components

[BUGFIX beta] Fix Views with templates inline as component.">Merge pull request</a> <a href="https://github.com/emberjs/ember.js/pull/11352" class="issue-link" title="[BUGFIX beta] Fix Views with templates inline as component.">#11352</a> <a href="/emberjs/ember.js/commit/78b63d1e36e0d25b5c8f1f202d27b3d36fce3fc5" class="message" data-pjax="true" title="Merge pull request #11352 from rwjblue/fix-template-lookup-from-views-as-components

[BUGFIX beta] Fix Views with templates inline as component.">from rwjblue/fix-template-lookup-from-views…</a>
        <span class="hidden-text-expander inline"><a href="#" class="js-details-target">…</a></span>
    </p>
      <div class="commit-desc"><pre>…-as-components

[BUGFIX beta] Fix Views with templates inline as component.</pre></div>
    <div class="commit-meta">
      <button aria-label="Copy SHA" class="js-zeroclipboard zeroclipboard-link tooltipped tooltipped-s" data-clipboard-text="78b63d1e36e0d25b5c8f1f202d27b3d36fce3fc5" data-copied-hint="Copied!" type="button"><span class="octicon octicon-clippy"></span></button>
      <a href="/emberjs/ember.js/commit/78b63d1e36e0d25b5c8f1f202d27b3d36fce3fc5" class="sha-block" data-pjax>latest commit <span class="sha">78b63d1e36</span></a>

      <div class="authorship">
        <img alt="@rwjblue" class="avatar" height="20" src="https://avatars3.githubusercontent.com/u/12637?v=3&amp;s=40" width="20" />
        <span class="author-name"><a href="/rwjblue" rel="contributor">rwjblue</a></span>
        authored <time class="updated" datetime="2015-06-05T11:41:43Z" is="relative-time">Jun 5, 2015</time>

      </div>
    </div>
  </div>

  
<div class="file-wrap">
  <a href="/emberjs/ember.js/tree/78b63d1e36e0d25b5c8f1f202d27b3d36fce3fc5" class="hidden js-permalink-shortcut" data-hotkey="y">Permalink</a>

  <table class="files" data-pjax>


    <tbody>
      <tr class="warning include-fragment-error">
        <td class="icon"><span class="octicon octicon-alert"></span></td>
        <td class="content" colspan="3">Failed to load latest commit information.</td>
      </tr>

        <tr>
          <td class="icon">
            <span class="octicon octicon-file-directory"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/emberjs/ember.js/tree/master/bin" class="js-directory-link" id="c1111bd512b29e821b120b86446026b8-fcd0b11e8c1c4d836e7f8a5537db6e26af22fe69" title="bin">bin</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/emberjs/ember.js/commit/f1807598c725f6d63371e45664d6504d9c94b2ff" class="message" data-pjax="true" title="prevent accidental publishing to canary/others by contributors

From the Travis CI docs:

http://docs.travis-ci.com/user/ci-environment/

For builds not triggered by a pull request this is the name of the
branch currently being built; whereas for builds triggered by a pull
request this is the name of the branch targeted by the pull request (in
many cases this will be master, which will publish to &quot;canary&quot;).

This was building for branches not intended to be published because they
were opened as a pull request against master (which set `$TAVIS_BRANCH`
to `master` when a pull request was opened). As Ember core contributors
frequently work off the main repository this is an unwanted side effect.">prevent accidental publishing to canary/others by contributors</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2015-05-25T16:52:08Z" is="time-ago">May 25, 2015</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-directory"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/emberjs/ember.js/tree/master/config" class="js-directory-link" id="2245023265ae4cf87d02c8b6ba991139-36f62c22de9369e71042c5cd66affe8123c656fd" title="config">config</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/emberjs/ember.js/commit/a233059b52fa865eac093f6076bf8736d49afe18" class="message" data-pjax="true" title="Publish Glimmer builds to S3.

Make testing apps easier...">Publish Glimmer builds to S3.</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2015-05-04T18:08:30Z" is="time-ago">May 4, 2015</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-directory"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/emberjs/ember.js/tree/master/generators" class="js-directory-link" id="49511c3cf5edacaa03c4198875f15e4e-c8fd269bc1183cc571e0644148e3369dd5aad8c3" title="generators">generators</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/emberjs/ember.js/commit/285994020375fde89751ce941716701d1fc0e7f2" class="message" data-pjax="true" title="[DOC] Update copyright year">[DOC] Update copyright year</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2015-01-12T00:21:36Z" is="time-ago">Jan 11, 2015</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-directory"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/emberjs/ember.js/tree/master/lib" class="js-directory-link" id="e8acc63b1e238f3255c900eed37254b8-3065d2c8fc15be4454f5c19adfc5af4faa7ec2e8" title="lib">lib</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/emberjs/ember.js/commit/b492d0d680c31ac3a0db99640a4543e86d31caba" class="message" data-pjax="true" title="More rigorous approach to stream stability

This commit takes a more structured, less ad hoc approach to stream
stability. In particular, the `bindSelf` hook is responsible for
creating a stable set of stream “roots” at first render. On subsequent
renders, those streams are simply updated in place, and if there are
derived “child” streams from those root streams, they will mark their
associated render nodes as dirty.

This ensures that the idempotent in-place rendering strategy can do very
little work, and also remain 100% compatible with mutation observer
patterns.

Still to do: make sure that lifecycle hooks run asynchronously, after
all rendering has completed.

This commit also introduces the concept of a “Shadow Root”, which is a
general primitive that describes how components and views in Ember
create a hierarchy of *render nodes* with a different scope hierarchy.

Each time a component’s layout is rendered for the first time, a new
“Shadow Root” is also created, which is responsible for linking the
layout into the dynamic node hierarchy, while giving the layout a
totally new scope.

When the layout `{{yield}}`s, the Shadow Root works with HTMLBars to
restore the parent scope.

The responsibility of `ShadowRoot` is primarily to encapsulate the
bookkeeping necessary to properly do an in-place re-render on subsequent
renders. Because HTMLBars already encapsulates the concept of `yield`ing
from a layout, this object is quite small.

Interestingly, because ShadowRoot is exactly the same boundary as the
Web Component’s Shadow DOM, it is also a good location to create a
DOM Shadow Root and render into that. We will likely explore this if
Shadow DOM lands in more browsers.

At the moment, Ember uses the block helper functionality from HTMLBars
to render new top-level scopes. This results in `bindSelf` being called
with the information passed from Ember. Because `bindSelf` is called
both with a user’s `self`, and through Ember internals, we have created
a few symbols that Ember can use to communicate with `bindSelf`.
However, we realize that this is not the optimal solution, and plan for
HTMLBars to expose an internal version of the `block` hook that we can
use to pass a scope through the machinery, rather than a `self` that
contains scoping information through internal symbols.

As we continue to progress, we plan to better document the various
abstraction boundaries, such as ShadowRoot.">More rigorous approach to stream stability</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2015-04-02T18:46:18Z" is="time-ago">Apr 2, 2015</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-directory"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/emberjs/ember.js/tree/master/packages" class="js-directory-link" id="2fc9e51174a78dd5bfc57e8e368590b3-5dc217730c50fb2aaf9cf77eff3aedadb084e86c" title="packages">packages</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/emberjs/ember.js/commit/78b63d1e36e0d25b5c8f1f202d27b3d36fce3fc5" class="message" data-pjax="true" title="Merge pull request #11352 from rwjblue/fix-template-lookup-from-views-as-components

[BUGFIX beta] Fix Views with templates inline as component.">Merge pull request</a> <a href="https://github.com/emberjs/ember.js/pull/11352" class="issue-link" title="[BUGFIX beta] Fix Views with templates inline as component.">#11352</a> <a href="/emberjs/ember.js/commit/78b63d1e36e0d25b5c8f1f202d27b3d36fce3fc5" class="message" data-pjax="true" title="Merge pull request #11352 from rwjblue/fix-template-lookup-from-views-as-components

[BUGFIX beta] Fix Views with templates inline as component.">from rwjblue/fix-template-lookup-from-views…</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2015-06-05T11:41:43Z" is="time-ago">Jun 5, 2015</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-directory"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/emberjs/ember.js/tree/master/scripts" class="js-directory-link" id="d6c5855a62cf32a4dadbc2831f0f295f-d0c9ce210764dcfe35467c229f7cb10a38d30920" title="scripts">scripts</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/emberjs/ember.js/commit/19929ecfb5e36d2928b07a7939fe524f71ed360d" class="message" data-pjax="true" title="Improved File Size script">Improved File Size script</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2012-04-22T01:24:26Z" is="time-ago">Apr 21, 2012</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-directory"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/emberjs/ember.js/tree/master/server" class="js-directory-link" id="cf1e8c14e54505f60aa10ceb8d5d8ab3-cf6cf79c8bca6d191969506ea36cf1524d76fbf9" title="server">server</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/emberjs/ember.js/commit/a0c7f7b4504b30b6f09f8f5360fdd9f7a2db5569" class="message" data-pjax="true" title="Allow `hidepassed` to be toggled.

Previously, `hidepassed` was forced to `true` as a way to make it the
default behavior. This had the negative result of making it pretty
difficult to actually see which assertions/tests were actually passing
(since we hardcode the value to `true` any refreshes of the page cause
it to hide the tests again).

This removes the hard-coding, but adds `?hidepassed` to the default
redirect. This should have the same general result, but still allow
unhiding tests/assertions much easier.">Allow `hidepassed` to be toggled.</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2015-04-07T00:49:11Z" is="time-ago">Apr 6, 2015</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-directory"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/emberjs/ember.js/tree/master/tests" class="js-directory-link" id="b61a6d542f9036550ba9c401c80f00ef-edf45669c4d97c6307e1661c8b6a449982c36d27" title="tests">tests</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/emberjs/ember.js/commit/2a726161dd80b3cfd5172922106037bbcc3e4d68" class="message" data-pjax="true" title="Fix basic Fastboot usage.">Fix basic Fastboot usage.</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2015-05-24T02:07:10Z" is="time-ago">May 23, 2015</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/emberjs/ember.js/blob/master/.bowerrc" class="js-directory-link" id="adba2f4daaaceb7e9889870260a0012e-69fad358018d530235f8e43c483d3ce960616a32" title=".bowerrc">.bowerrc</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/emberjs/ember.js/commit/bcc91223950ad5c464cbfdb503c49f6e8c976f36" class="message" data-pjax="true" title="Broccolify.">Broccolify.</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2014-05-13T04:42:15Z" is="time-ago">May 13, 2014</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/emberjs/ember.js/blob/master/.editorconfig" class="js-directory-link" id="1e70daafb475c0ce3fef7d2728279182-9099689136d8d17d94c8cb825e8cf4021e7ae7b8" title=".editorconfig">.editorconfig</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/emberjs/ember.js/commit/b2a24fade97e367bb7ee9365d17b1cccda0e0cb5" class="message" data-pjax="true" title="Add EditorConfig file">Add EditorConfig file</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2014-07-21T07:19:08Z" is="time-ago">Jul 21, 2014</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/emberjs/ember.js/blob/master/.gitignore" class="js-directory-link" id="a084b794bc0759e7a6b77810e01874f2-37c9f7bd638d339558a575950251c3e6095275fb" title=".gitignore">.gitignore</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/emberjs/ember.js/commit/e443d4b1f4685d99ddbddc01468d2a5b8c359508" class="message" data-pjax="true" title="Remove &#39;*.swp&#39; from .gitignore">Remove '*.swp' from .gitignore</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2015-05-13T17:03:24Z" is="time-ago">May 13, 2015</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/emberjs/ember.js/blob/master/.gitmodules" class="js-directory-link" id="8903239df476d7401cf9e76af0252622-c1b8008e852eb0d704e7f2cd8cd93d03f37b5f7c" title=".gitmodules">.gitmodules</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/emberjs/ember.js/commit/971ac729a36eb4d495e34a9ef051cf6eadeed7f5" class="message" data-pjax="true" title="Update gitsubmodules urls to public repos.">Update gitsubmodules urls to public repos.</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2013-01-07T16:05:25Z" is="time-ago">Jan 7, 2013</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/emberjs/ember.js/blob/master/.jscsrc" class="js-directory-link" id="e5b8cacefa8c329daed4f4b628f72e61-68e871b6e0f8e65d84152869e0843003136de866" title=".jscsrc">.jscsrc</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/emberjs/ember.js/commit/bb16d59b8d41efbba521acd7b0ade26cd3a3b6ee" class="message" data-pjax="true" title="Disallows spaces inside round braces when calling a function

i.e:

```javascript
// bad
foo( &#39;test&#39; );

// good
foo(&#39;test&#39;);
```">Disallows spaces inside round braces when calling a function</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2015-01-03T03:12:21Z" is="time-ago">Jan 2, 2015</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/emberjs/ember.js/blob/master/.jshintrc" class="js-directory-link" id="4d5aa81bf4f18104bb6ea53a8b5d1f43-d8c06f5176db4a98c5d1523eba780d7c0b0dbf22" title=".jshintrc">.jshintrc</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/emberjs/ember.js/commit/05ee7112c5f68181e234c18bdd2c6105df996291" class="message" data-pjax="true" title="Remove MetamorphView, salvage useful metamorph view tests">Remove MetamorphView, salvage useful metamorph view tests</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2015-04-20T23:48:23Z" is="time-ago">Apr 20, 2015</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/emberjs/ember.js/blob/master/.travis.yml" class="js-directory-link" id="354f30a63fb0907d4ad57269548329e3-e4d77442a3ee1654e30b7e09d2c32acdc01f2947" title=".travis.yml">.travis.yml</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/emberjs/ember.js/commit/54d3e16046bf6a9ae3bb2202b4b7eb7637d14bd2" class="message" data-pjax="true" title="ember-cli-sauce v1.3.0

Use the new `ember sauce:launch`
Replaced start &amp; stop with prefixed commands
Removed duplicated stop">ember-cli-sauce v1.3.0</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2015-05-16T17:19:56Z" is="time-ago">May 16, 2015</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/emberjs/ember.js/blob/master/.watchmanconfig" class="js-directory-link" id="0842d28d1bb3eda1763beb20e6ecc866-5e9462c20051c35afa19b1b75154de81e6df3d29" title=".watchmanconfig">.watchmanconfig</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/emberjs/ember.js/commit/9b70eed5f9a97cb3ba80b9343b263955b6641703" class="message" data-pjax="true" title="Add .watchmanconfig to ignore `tmp`.">Add .watchmanconfig to ignore `tmp`.</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2015-06-04T20:02:52Z" is="time-ago">Jun 4, 2015</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/emberjs/ember.js/blob/master/Brocfile.js" class="js-directory-link" id="ec6fb87583b2323d013c3e30c0a5084d-df68c5a9e2b688b6fab50bfe393747abbe3702d8" title="Brocfile.js">Brocfile.js</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/emberjs/ember.js/commit/a4d363efe2e58a82a36555cd3c077be203e4f508" class="message" data-pjax="true" title="Embed the htmlbars-runtime into the ember-template-compiler package.">Embed the htmlbars-runtime into the ember-template-compiler package.</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2015-02-12T21:04:24Z" is="time-ago">Feb 12, 2015</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/emberjs/ember.js/blob/master/CHANGELOG.md" class="js-directory-link" id="4ac32a78649ca5bdd8e0ba38b7006a1e-0c6bf1bff726322d96ef2bae7f98f85180115dd3" title="CHANGELOG.md">CHANGELOG.md</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/emberjs/ember.js/commit/0a7c0fce26f11f14f66493758d568c00815569f4" class="message" data-pjax="true" title="Update CHANGELOG for 1.12.0.">Update CHANGELOG for 1.12.0.</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2015-05-14T03:55:11Z" is="time-ago">May 13, 2015</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/emberjs/ember.js/blob/master/CONTRIBUTING.md" class="js-directory-link" id="6a3371457528722a734f3c51d9238c13-ae1d795229d8301eeff14112649e77b25cfb2bdf" title="CONTRIBUTING.md">CONTRIBUTING.md</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/emberjs/ember.js/commit/988f1c96dae3bef06fdc40cc649189dd0016e65b" class="message" data-pjax="true" title="[DOC] Corrected spelling in CONTRIBUTING.md">[DOC] Corrected spelling in CONTRIBUTING.md</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2015-05-08T01:41:56Z" is="time-ago">May 7, 2015</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/emberjs/ember.js/blob/master/FEATURES.md" class="js-directory-link" id="9fba6b0c081e791446d60a1c9abc6d10-fb0d67c5fc995cca4ad4f37b9260b27389549cda" title="FEATURES.md">FEATURES.md</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/emberjs/ember.js/commit/bd1d6084d3c918a3cab0a649701ef040c2ad7b42" class="message" data-pjax="true" title="Implement {{get}} Keyword

The Syntax: `{{get object path}}`

A new keyword/helper that can be used to allow your object and/or key
values to be dynamic.

Example: {{get person propertyName}}">Implement {{get}} Keyword</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2015-05-18T05:37:49Z" is="time-ago">May 18, 2015</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/emberjs/ember.js/blob/master/LICENSE" class="js-directory-link" id="9879d6db96fd29134fc802214163b95a-69a9c42921a1ff0bfdd38d5d9a18eb20414673d7" title="LICENSE">LICENSE</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/emberjs/ember.js/commit/22a7f4c6c8f00566b5d6a754992e0adda66d86cf" class="message" data-pjax="true" title="[DOC] Update copyright year

it’s 2015">[DOC] Update copyright year</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2015-01-31T23:28:46Z" is="time-ago">Jan 31, 2015</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/emberjs/ember.js/blob/master/README.md" class="js-directory-link" id="04c6e90faac2675aa89e2176d2eec7d8-47faf7221cad47a2bc56a07a3ec87cfa33cadfb3" title="README.md">README.md</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/emberjs/ember.js/commit/c660d4ea29cc8416bf317b497faf8d897cd09aec" class="message" data-pjax="true" title="Added SauceLabs status badge to README">Added SauceLabs status badge to README</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2015-04-03T04:00:00Z" is="time-ago">Apr 2, 2015</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/emberjs/ember.js/blob/master/Rakefile" class="js-directory-link" id="52c976fc38ed2b4e3b1192f8a8e24cff-30870514bf2285cfb4f03e49c4e50ea40c1c8431" title="Rakefile">Rakefile</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/emberjs/ember.js/commit/275b870a769c0da6f879fcbd2aaf9b64037cdbc9" class="message" data-pjax="true" title="Cleanup Rakefile

ember-dev and rake-pipeline is no longer used.">Cleanup Rakefile</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2014-12-09T18:41:23Z" is="time-ago">Dec 10, 2014</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/emberjs/ember.js/blob/master/STYLEGUIDE.md" class="js-directory-link" id="ba2dc84c4bcbe54f368b6c7d3bc1b13e-da73ad68de3aba7568e87f95728da2cdec20955a" title="STYLEGUIDE.md">STYLEGUIDE.md</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/emberjs/ember.js/commit/05532e6a0f7abf79a6179fa22364e6d9af646688" class="message" data-pjax="true" title="[DOC beta] Add destructuring to the table of contents">[DOC beta] Add destructuring to the table of contents</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2015-04-04T15:21:16Z" is="time-ago">Apr 4, 2015</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/emberjs/ember.js/blob/master/VERSION" class="js-directory-link" id="021321e8c168ba3ae39ce3a2e7b3ec87-be918a215eccb3c799f295ebe62e41fa41372d61" title="VERSION">VERSION</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/emberjs/ember.js/commit/0fe3ae595f8a0fd2c2daa38dd1a3aa0c27cc7e43" class="message" data-pjax="true" title="Post release version bump.">Post release version bump.</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2015-05-14T03:55:22Z" is="time-ago">May 13, 2015</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/emberjs/ember.js/blob/master/bower.json" class="js-directory-link" id="0a08a7565aba4405282251491979bb6b-51ab5513515fb7ca6dcc41e3664f342a0c5cff0b" title="bower.json">bower.json</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/emberjs/ember.js/commit/043d98f6c4d50b83fc7e1175e8420e0b84ab8c1f" class="message" data-pjax="true" title="[BUGFIX beta] Update router.js version.

Ensures that a no-op transition returns the currently active transition
(was previously returning a new transition which messed up the
transition state classes).">[BUGFIX beta] Update router.js version.</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2015-03-26T15:22:42Z" is="time-ago">Mar 26, 2015</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/emberjs/ember.js/blob/master/ember-source.gemspec" class="js-directory-link" id="0969804e4dce90f1303274b027aae3b6-c3c5b45e0d771bbe7f636e07d26bd7391b735281" title="ember-source.gemspec">ember-source.gemspec</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/emberjs/ember.js/commit/54be9ee022c44ccc15bfed0f0c557336c16adfdd" class="message" data-pjax="true" title="[BUGFIX beta] Remove handlebars from dependencies

It is no longer required from Ember.js.">[BUGFIX beta] Remove handlebars from dependencies</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2014-12-28T16:26:58Z" is="time-ago">Dec 29, 2014</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/emberjs/ember.js/blob/master/features.json" class="js-directory-link" id="144c2a0d940ab2adda99ccb5ca96e3be-47103f4874e08aac16773ee29f903879adce3e8b" title="features.json">features.json</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/emberjs/ember.js/commit/2bd8a29ffde19a76d230f4f70e5c4383ef950c69" class="message" data-pjax="true" title="[FEATURE ember-htmlbars-component-generation] Disabled by default.

A number of issues have been discovered for this feature that make it clear
that further consideration is needed before enabling by default.

* Cannot use angle-bracket invocation in contexts that require specific tags.
  For example: you cannot use `&lt;table&gt;&lt;custom-row model=stuff&gt;&lt;/custom-row&gt;&lt;/table&gt;` because
  in a `&lt;table&gt;` context like this, you can only use `&lt;tr&gt;`
* Cannot use angle-bracket invocation to use components in a subdirectory.
* Other things....">[FEATURE ember-htmlbars-component-generation] Disabled by default.</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2015-05-24T20:46:20Z" is="time-ago">May 24, 2015</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/emberjs/ember.js/blob/master/package.json" class="js-directory-link" id="b9cfc7f2cdf78a7f4b91a753d10865a2-7ac40e55e211a6f5067b2acc0748361e08e8b89a" title="package.json">package.json</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/emberjs/ember.js/commit/d1d993d1becc0802169790c7858e7074592adbcc" class="message" data-pjax="true" title="Make the `env` more generally consistent (JIT)

Previously, the `env` was a bag of properties, and got frequently
extended or modified (in largely predictable ways).

The consequence is that even though the environment is conceptually a
single concept, it got treated internally as a megamorphic shapeless
entity. For what it’s worth, this JIT confusion was somewhat mirrored
by a confusion when reading the code: it was never precisely clear what
the `env` would look like from the perspective of a human reader.

This commit changes the environment to be a single class. There are only
two kinds of child environments (a change in the `view` and a change to
`outletState`), and there are now methods on `env` to make that simple
and predictable.

The consequence is that all methods that take an `env` now go down a
fast path when accessing it, and human readers of the code can feel
confident about what the environment looks like.">Make the `env` more generally consistent (JIT)</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2015-06-04T00:21:31Z" is="time-ago">Jun 3, 2015</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/emberjs/ember.js/blob/master/testem.json" class="js-directory-link" id="8ee23fdeee2ec605a1e96a91991b764e-284701fe7a760e7c8ab875b61913278e0f3cefb7" title="testem.json">testem.json</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/emberjs/ember.js/commit/54d3e16046bf6a9ae3bb2202b4b7eb7637d14bd2" class="message" data-pjax="true" title="ember-cli-sauce v1.3.0

Use the new `ember sauce:launch`
Replaced start &amp; stop with prefixed commands
Removed duplicated stop">ember-cli-sauce v1.3.0</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2015-05-16T17:19:56Z" is="time-ago">May 16, 2015</time></span>
          </td>
        </tr>
        <tr>
          <td class="icon">
            <span class="octicon octicon-file-text"></span>
            <img alt="" class="spinner" height="16" src="https://assets-cdn.github.com/assets/spinners/octocat-spinner-32-e513294efa576953719e4e2de888dd9cf929b7d62ed8d05f25e731d02452ab6c.gif" width="16" />
          </td>
          <td class="content">
            <span class="css-truncate css-truncate-target"><a href="/emberjs/ember.js/blob/master/yuidoc.json" class="js-directory-link" id="b3fb1962982568042e2b262821f8017a-9a6aeb77bc523cf7c6b14792c650a5b50bf26cea" title="yuidoc.json">yuidoc.json</a></span>
          </td>
          <td class="message">
            <span class="css-truncate css-truncate-target">
              <a href="/emberjs/ember.js/commit/b12912da5200404c302b73a6e3ac7c7eeb0bcb1b" class="message" data-pjax="true" title="[DOC beta] Cleanup yuidoc.json paths. Handlebars out, HTMLBars in.">[DOC beta] Cleanup yuidoc.json paths. Handlebars out, HTMLBars in.</a>
            </span>
          </td>
          <td class="age">
            <span class="css-truncate css-truncate-target"><time datetime="2014-12-30T19:03:50Z" is="time-ago">Dec 30, 2014</time></span>
          </td>
        </tr>
    </tbody>
  </table>

</div>


  <div id="readme" class="boxed-group flush clearfix announce instapaper_body md">
    <h3>
      <span class="octicon octicon-book"></span>
      README.md
    </h3>

    <article class="markdown-body entry-content" itemprop="mainContentOfPage"><h1><a id="user-content-emberjs--" class="anchor" href="#emberjs--" aria-hidden="true"><span class="octicon octicon-link"></span></a>Ember.js <a href="http://travis-ci.org/emberjs/ember.js"><img src="https://camo.githubusercontent.com/2828e4befd1625eb9cee0f2f78a90f047f575ba4/68747470733a2f2f7365637572652e7472617669732d63692e6f72672f656d6265726a732f656d6265722e6a732e7376673f6272616e63683d6d6173746572" alt="Build Status" data-canonical-src="https://secure.travis-ci.org/emberjs/ember.js.svg?branch=master" style="max-width:100%;"></a> <a href="https://codeclimate.com/github/emberjs/ember.js"><img src="https://camo.githubusercontent.com/e047ad268c02ef08701206be812bdbb48f883fa3/68747470733a2f2f636f6465636c696d6174652e636f6d2f6769746875622f656d6265726a732f656d6265722e6a732e737667" alt="Code Climate" data-canonical-src="https://codeclimate.com/github/emberjs/ember.js.svg" style="max-width:100%;"></a></h1>

<p><a href="https://saucelabs.com/u/ember-ci"><img src="https://camo.githubusercontent.com/bf7fc0e06dcb1da584bd8b8b4ed84282d48c6cfa/68747470733a2f2f73617563656c6162732e636f6d2f62726f777365722d6d61747269782f656d6265722d63692e737667" alt="Sauce Test Status" data-canonical-src="https://saucelabs.com/browser-matrix/ember-ci.svg" style="max-width:100%;"></a></p>

<p>Ember.js is a JavaScript framework that does all of the heavy lifting
that you'd normally have to do by hand. There are tasks that are common
to every web app; Ember.js does those things for you, so you can focus
on building killer features and UI.</p>

<ul>
<li><a href="http://emberjs.com">Website</a></li>
<li><a href="http://emberjs.com/guides">Guides</a></li>
<li><a href="http://emberjs.com/api">API</a></li>
<li><a href="http://emberjs.com/community">Community</a></li>
<li><a href="http://emberjs.com/blog">Blog</a></li>
<li><a href="http://emberjs.com/builds">Builds</a></li>
</ul>

<h1><a id="user-content-building-emberjs" class="anchor" href="#building-emberjs" aria-hidden="true"><span class="octicon octicon-link"></span></a>Building Ember.js</h1>

<ol>
<li>Ensure that <a href="http://nodejs.org/">Node.js</a> is installed.</li>
<li>Run <code>npm install</code> to ensure the required dependencies are installed.</li>
<li>Run <code>npm run build</code> to build Ember.js. The builds will be placed in the <code>dist/</code> directory.</li>
</ol>

<h1><a id="user-content-contribution" class="anchor" href="#contribution" aria-hidden="true"><span class="octicon octicon-link"></span></a>Contribution</h1>

<p>See <a href="https://github.com/emberjs/ember.js/blob/master/CONTRIBUTING.md">CONTRIBUTING.md</a></p>

<h1><a id="user-content-how-to-run-unit-tests" class="anchor" href="#how-to-run-unit-tests" aria-hidden="true"><span class="octicon octicon-link"></span></a>How to Run Unit Tests</h1>

<ol>
<li><p>Follow the setup steps listed above under <a href="#building-emberjs">Building Ember.js</a>.</p></li>
<li><p>To start the development server, run <code>npm start</code>.</p></li>
<li><p>To run all tests, visit <a href="http://localhost:4200/">http://localhost:4200/</a>.</p></li>
<li><p>To test a specific package, visit <code>http://localhost:4200/tests/index.html?package=PACKAGE_NAME</code>. Replace
<code>PACKAGE_NAME</code> with the name of the package you want to test. For
example:</p>

<ul>
<li><a href="http://localhost:4200/tests/index.html?package=ember-runtime">Ember.js Runtime</a></li>
<li><a href="http://localhost:4200/tests/index.html?package=ember-views">Ember.js Views</a></li>
<li><a href="http://localhost:4200/tests/index.html?package=ember-handlebars">Ember.js Handlebars</a></li>
</ul></li>
</ol>

<p>To test multiple packages, you can separate them with commas.</p>

<p>You can also pass <code>jquery=VERSION</code> in the test URL to test different
versions of jQuery.</p>

<h2><a id="user-content-from-the-cli" class="anchor" href="#from-the-cli" aria-hidden="true"><span class="octicon octicon-link"></span></a>From the CLI</h2>

<ol>
<li><p>Install phantomjs from <a href="http://phantomjs.org">http://phantomjs.org</a>.</p></li>
<li><p>Run <code>npm test</code> to run a basic test suite or run <code>TEST_SUITE=all npm test</code> to
run a more comprehensive suite.</p></li>
</ol>
</article>
  </div>


        </div>

      </div><!-- /.repo-container -->
      <div class="modal-backdrop"></div>
    </div><!-- /.container -->
  </div><!-- /.site -->


    </div><!-- /.wrapper -->

      <div class="container">
  <div class="site-footer" role="contentinfo">
    <ul class="site-footer-links right">
        <li><a href="https://status.github.com/" data-ga-click="Footer, go to status, text:status">Status</a></li>
      <li><a href="https://developer.github.com" data-ga-click="Footer, go to api, text:api">API</a></li>
      <li><a href="https://training.github.com" data-ga-click="Footer, go to training, text:training">Training</a></li>
      <li><a href="https://shop.github.com" data-ga-click="Footer, go to shop, text:shop">Shop</a></li>
        <li><a href="https://github.com/blog" data-ga-click="Footer, go to blog, text:blog">Blog</a></li>
        <li><a href="https://github.com/about" data-ga-click="Footer, go to about, text:about">About</a></li>

    </ul>

    <a href="https://github.com" aria-label="Homepage">
      <span class="mega-octicon octicon-mark-github" title="GitHub"></span>
</a>
    <ul class="site-footer-links">
      <li>&copy; 2015 <span title="0.07386s from github-fe143-cp1-prd.iad.github.net">GitHub</span>, Inc.</li>
        <li><a href="https://github.com/site/terms" data-ga-click="Footer, go to terms, text:terms">Terms</a></li>
        <li><a href="https://github.com/site/privacy" data-ga-click="Footer, go to privacy, text:privacy">Privacy</a></li>
        <li><a href="https://github.com/security" data-ga-click="Footer, go to security, text:security">Security</a></li>
        <li><a href="https://github.com/contact" data-ga-click="Footer, go to contact, text:contact">Contact</a></li>
    </ul>
  </div>
</div>


    <div class="fullscreen-overlay js-fullscreen-overlay" id="fullscreen_overlay">
  <div class="fullscreen-container js-suggester-container">
    <div class="textarea-wrap">
      <textarea name="fullscreen-contents" id="fullscreen-contents" class="fullscreen-contents js-fullscreen-contents" placeholder=""></textarea>
      <div class="suggester-container">
        <div class="suggester fullscreen-suggester js-suggester js-navigation-container"></div>
      </div>
    </div>
  </div>
  <div class="fullscreen-sidebar">
    <a href="#" class="exit-fullscreen js-exit-fullscreen tooltipped tooltipped-w" aria-label="Exit Zen Mode">
      <span class="mega-octicon octicon-screen-normal"></span>
    </a>
    <a href="#" class="theme-switcher js-theme-switcher tooltipped tooltipped-w"
      aria-label="Switch themes">
      <span class="octicon octicon-color-mode"></span>
    </a>
  </div>
</div>



    

    <div id="ajax-error-message" class="flash flash-error">
      <span class="octicon octicon-alert"></span>
      <a href="#" class="octicon octicon-x flash-close js-ajax-error-dismiss" aria-label="Dismiss error"></a>
      Something went wrong with that request. Please try again.
    </div>


      <script crossorigin="anonymous" src="https://assets-cdn.github.com/assets/frameworks-447ce66a36506ebddc8e84b4e32a77f6062f3d3482e77dd21a77a01f0643ad98.js"></script>
      <script async="async" crossorigin="anonymous" src="https://assets-cdn.github.com/assets/github/index-273626d05f0daba1adb856ea6f9d82ff151f8b9f23a21044a761d2e2f843b354.js"></script>
      
      
  </body>
</html>

